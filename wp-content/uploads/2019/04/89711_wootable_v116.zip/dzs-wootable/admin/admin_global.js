
window.dzswtl_shortcode_receiver_input = null;
window.dzs_suspend_dependency_check = false;
// -- suspend dependency check until we are ready








function dzswtl_admin_global_local($){
    //return;
    // Create the media frame.

    setTimeout(reskin_select, 10);
    $(document).undelegate(".select-wrapper select", "change");
    $(document).delegate(".select-wrapper select", "change",  change_select);


    $(document).on('click','.quick-edit-adarray,.btn-generate-attribute-sort,.btn-generate-dzswtl-filter,.dzswtl-import-layout', handle_mouse);

    $(document).on('submit','.delete-all-settings', handle_input);


    var _feedbacker = $('.feedbacker').eq(0);

    _feedbacker.fadeOut('fast');



    setTimeout(function(){
//        console.info(jQuery(".refresh-thumbnail-yt-vim"))

        // console.info('ia', $('.dzs-dependency-field'));


        window.dzs_suspend_dependency_check = false;
        $('.dzs-dependency-field').trigger('change');
    }, 1000);





    if($.fn.dzstabsandaccordions){

        $('#tabs-mainsettings').dzstabsandaccordions({
            'design_tabsposition' : 'top'
            ,design_transition: 'fade'
            ,design_tabswidth: 'fullwidth'
            ,toggle_breakpoint : '300'
            // ,toggle_type: 'toggle'
            ,settings_appendWholeContent: true
        });
    }
    // init_dzstabsandaccordions();


    $('.wrap').eq(0).after($('.dzswtl-import-layout-con'));

    setTimeout(function(){

        // console.info('lets see selector - ',$('select.dzs-style-me'));
        // console.info('$(".color-with-spectrum") - ',$(".color-with-spectrum"));

        if(window.dzssel_startup_init){

            dzssel_init('select.dzs-style-me', {init_each: true
                ,'call_from': 'timeout admin_global'});
        }



        if($.fn.spectrum){

            $(".color-with-spectrum").spectrum({
                showAlpha: true
                ,allowEmpty: true
                // ,preferredFormat: "rgba"
            });
        }
    },50);
    function show_notice(response) {


        if(typeof response=='object'){
            if(response.status=='success'){

                _feedbacker.removeClass('is-error');
                _feedbacker.html(response.status_txt);
                _feedbacker.fadeIn('fast');

                setTimeout(function () {

                    _feedbacker.fadeOut('slow');
                }, 1500)
            }
            if(response.status=='error'){

                _feedbacker.addClass('is-error');
                _feedbacker.html(response.status_txt);
                _feedbacker.fadeIn('fast');

                setTimeout(function () {

                    _feedbacker.fadeOut('slow');
                }, 1500)
            }
        }else{
            if (response.indexOf('error -') == 0) {
                _feedbacker.addClass('is-error');
                _feedbacker.html(response.substr(7));
                _feedbacker.fadeIn('fast');

                setTimeout(function () {

                    _feedbacker.fadeOut('slow');
                }, 1500)
            }
            if (response.indexOf('success -') == 0) {
                _feedbacker.removeClass('is-error');
                _feedbacker.html(response.substr(9));
                _feedbacker.fadeIn('fast');

                setTimeout(function () {

                    _feedbacker.fadeOut('slow');
                }, 1500)
            }
        }


    }


    function handle_mouse(e) {
        var _t = $(this);


        if (e.type == 'click') {



            if(_t.hasClass('btn-generate-dzswtl-filter')){


                var _inp = _t.prev();

                // console.info('ceva');


                window.dzswtl_shortcode_receiver_input = _inp;
                var sel = _inp.val();


                var parsel ='&sel=' + encodeURIComponent(sel);
                window.open_ultibox(null,{

                    type: 'iframe'
                    ,source: dzswtl_settings.filter_generator_url + parsel
                    ,scaling: 'fill' // -- this is the under description
                    ,suggested_width: 800 // -- this is the under description
                    ,suggested_height: 600 // -- this is the under description
                    ,item: null // -- we can pass the items from here too

                })

                return false;
            }
            if(_t.hasClass('dzswtl-import-layout')){



                $.ajax({
                    async: "false"
                    ,method: "POST"
                    // ,contentType: "application/x-www-form-urlencoded; charset=UTF-8"
                    // ,type: "POST"
                    , url: ajaxurl
                    , data: {
                        action: 'dzswtl_import_layout'
                        ,postdata: _t.attr('data-layout-name')
                    }
                    ,dataType: 'html'
                    ,success: function(response){
                        // console.info(response);


                        try {

                            var cont_arr = JSON.parse(response);
                            show_notice(cont_arr);


                            if(cont_arr.status=='success'){

                                setTimeout(function(){
                                    window.location.reload();
                                },100);
                            }

                        }catch(err){
                            console.warn(err);
                        }
                    }

                    ,error: function(err){
                        console.error('error loading',err);

                    }
                })


            }
            if(_t.hasClass('btn-generate-attribute-sort')){

                $.ajax({
                    async: "false"
                    ,method: "POST"
                    // ,contentType: "application/x-www-form-urlencoded; charset=UTF-8"
                    // ,type: "POST"
                    , url: ajaxurl
                    , data: {
                        action: 'dzswtl_generate_attribute_sort'
                        ,postdata: _t.attr('data-pa-slug')
                    }
                    ,dataType: 'html'
                    ,success: function(response){
                        // console.info(response);


                        try {

                            var cont_arr = JSON.parse(response);
                            show_notice(cont_arr);

                        }catch(err){
                            console.warn(err);
                        }
                    }

                    ,error: function(err){
                        console.error('error loading',err);

                    }
                })



                return false;
            }
            if(_t.hasClass('quick-edit-adarray')){
                // console.info("ceva");
                var url3 = dzsvg_settings.ad_builder_url;


                window.ad_target_field = _t.prev();
                if(_t.prev().val()){
                    url3+='&adstart='+encodeURIComponent(_t.prev().val());
                }

                window.open_ultibox(null,{


                    type:'iframe'
                    ,source: url3
                    ,scaling:'fill' // -- this is the under description
                    ,suggested_width:'800' // -- this is the under description
                    ,suggested_height:'700' // -- this is the under description
                    ,item: null // -- we can pass the items from here too

                });


                return false;
            }
        }
    }

    function handle_input(e){
        var _t = $(this);



        if(e.type=='submit'){
            if(_t.hasClass('delete-all-settings')){


                var r = confirm("Are you sure you want to delete all video gallery data ? ");

                if(r){

                }else{
                    return false;
                }
            }
        }
    }






    // console.info('hmm - ',$('.dzsvg-wordpress-uploader'));

    $(document).off('click','.dzsvg-wordpress-uploader');
    $(document).on('click','.dzsvg-wordpress-uploader', function(e){
        var _t = $(this);
        var _targetInput = _t.prev();

        // console.info(_t);

        var searched_type = '';

        if(_targetInput.hasClass('upload-type-audio')){
            searched_type = 'audio';
        }
        if(_targetInput.hasClass('upload-type-video')){
            searched_type = 'video';
        }
        if(_targetInput.hasClass('upload-type-image')){
            searched_type = 'image';
        }


        frame = wp.media.frames.dzsp_addimage = wp.media({
            title: "Insert Media",
            library: {
                type: searched_type
            },

            // Customize the submit button.
            button: {
                // Set the text of the button.
                text: "Insert Media",
                close: true
            }
        });

        // When an image is selected, run a callback.
        frame.on( 'select', function() {
            // Grab the selected attachment.
            var attachment = frame.state().get('selection').first();

            //console.log(attachment.attributes.url);
            var arg = attachment.attributes.url;
            _targetInput.val(arg);
            _targetInput.trigger('change');
//            frame.close();
        });

        // Finally, open the modal.
        frame.open();

        e.stopPropagation();
        e.preventDefault();
        return false;
    });





    $(document).off('click','.dzs-btn-add-media-att');
    $(document).on('click','.dzs-btn-add-media-att',  function(){
        var _t = $(this);

        var args = {
            title: 'Add Item',
            button: {
                text: 'Select'
            },
            multiple: false
        };

        if(_t.attr('data-library_type')){
            args.library = {
                'type':_t.attr('data-library_type')
            }
        }

        console.info(_t);

        var item_gallery_frame = wp.media.frames.downloadable_file = wp.media(args);

        item_gallery_frame.on( 'select', function() {

            var selection = item_gallery_frame.state().get('selection');
            selection = selection.toJSON();

            var ik=0;
            for(ik=0;ik<selection.length;ik++){

                var _c = selection[ik];
                //console.info(_c);
                if(_c.id==undefined){
                    continue;
                }

                if(_t.hasClass('button-setting-input-url')){

                    _t.parent().parent().find('input').eq(0).val(_c.url);
                }else{

                    _t.parent().parent().find('input').eq(0).val(_c.id);
                }


                _t.parent().parent().find('input').eq(0).trigger('change');

            }
        });



        // Finally, open the modal.
        item_gallery_frame.open();

        return false;
    });



    function change_select(){
        var selval = ($(this).find(':selected').text());
        $(this).parent().children('span').text(selval);
    }
    function reskin_select(){
        for(i=0;i<$('select').length;i++){
            var _cache = $('select').eq(i);
            //console.log(_cache.parent().attr('class'));

            if(_cache.hasClass('styleme')==false || _cache.parent().hasClass('select_wrapper') || _cache.parent().hasClass('select-wrapper')){
                continue;
            }
            var sel = (_cache.find(':selected'));
            _cache.wrap('<div class="select-wrapper"></div>')
            _cache.parent().prepend('<span>' + sel.text() + '</span>')
        }



    }


    var aux =window.location.href;


    if(aux.indexOf('plugins.php')>-1){



//         setTimeout(function(){
//             jQuery.get( "http://zoomthe.me/cronjobs/cache/dzsvg_get_version.static.html", function( data ) {
//
// //            console.info(data);
//                 var newvrs = Number(data);
//                 if(newvrs > Number(dzsvg_settings.version)){
//                     jQuery('.version-number').append('<span class="new-version info-con" style="width: auto;"> <span class="new-version-text">/ new version '+data+'</span><div class="sidenote">Download the new version by going to your CodeCanyon accound and accessing the Downloads tab.</div></div> </span>')
//
//                     if($('#the-list > #dzs-video-gallery').next().hasClass('plugin-update-tr')==false){
//                         $('#the-list > #dzs-video-gallery').addClass('update');
//                         $('#the-list > #dzs-video-gallery').after('<tr class="plugin-update-tr"><td colspan="3" class="plugin-update colspanchange"><div class="update-message">There is a new version of DZS Video Gallery available. <form action="admin.php?page=dzsvg-autoupdater" class="mainsettings" method="post"> &nbsp; <br> <button class="button-primary" name="action" value="dzsvg_update_request">Update</button></form></td></tr>');
//                     }
//                 }
//             });
//         }, 300);
    }

    if(aux.indexOf('&dzsvg_purchase_remove_binded=on')>-1){

        aux = aux.replace('&dzsvg_purchase_remove_binded=on','');
        var stateObj = { foo: "bar" };
        if(history){

            history.pushState(stateObj, null, aux);
        }
    }


















    $('.refresh-main-thumb').bind('click', function(){
        var _t = $(this);
        var _con = _t.parent().parent();


        if(_con.hasClass('select-hidden-con')){

            if(_con.hasClass('mode_youtube')){
//            console.info(_con.find('.main-thumb').eq(0))
                if(_con.find('.main-thumb').eq(0).val()==''){
                    _con.find('.main-thumb').eq(0).val('http://img.youtube.com/vi/'+_con.find('.main-source').eq(0).val()+'/0.jpg');
                    _con.find('.main-thumb').eq(0).trigger('change');
                }
            }
            if(_con.hasClass('mode_vimeo')){
                if(_con.find('.main-thumb').eq(0).val()==''){
                    //_con.find('.main-thumb').eq(0).val('http://img.youtube.com/vi/'+_t.val()+'/0.jpg');



                    var data = {
                        action: 'get_vimeothumb',
                        postdata: _con.find('.main-source').eq(0).val()
                    };

                    jQuery.post(ajaxurl, data, function(response) {
                        //console.log(response);
                        if(window.console !=undefined ){
                            //console.log(response);
                        }
                        if(response.substr(0,6)=='error:'){
                            //console.log('ceva');
                            jQuery('.import-error').html(response.substr(7));
                            jQuery('.import-error').fadeIn('fast').delay(5000).fadeOut('slow');
                            return false;
                        }
                        _con.find('.main-thumb').eq(0).val(response);
                        _con.find('.main-thumb').eq(0).trigger('change');
                    });
                }
            };
        }else{
            console.info(_con, 'does not have class select-hidden-con')
        }

        return false;
    })





    function con_generate_buttons(){
        $('#generate-upload-page').bind('click', function(){
            var _t = $(this);

            _t.css('opacity',0.5);



            var data = {
                action: 'dzsvp_insert_upload_page'
                ,postdata: '1'
            };
            $.post(ajaxurl, data, function(response) {
                if(window.console != undefined){
                    console.log('Got this from the server: ' + response);
                }

                $('select[name=dzsvp_page_upload]').prepend('<optgroup label="Generated Pages"><option value="'+response+'">Upload</option></optgroup>')

                $('select[name=dzsvp_page_upload]').find('option').eq(0).prop('selected',true);
                $('select[name=dzsvp_page_upload]').trigger('change');

                _t.parent().parent().remove();

            });

            return false;
        })
    }

    con_generate_buttons();
    extra_skin_hiddenselect();


}




jQuery(document).ready(function($){
});





function extra_skin_hiddenselect(){
    for(i=0;i<jQuery('.select-hidden-metastyle').length;i++){
        var _t = jQuery('.select-hidden-metastyle').eq(i);
        if(_t.hasClass('inited')){
            continue;
        }
        //console.log(_t);
        _t.addClass('inited');
        _t.children('select').eq(0).bind('change', change_selecthidden);
        change_selecthidden(null, _t.children('select').eq(0));
        _t.find('.an-option').bind('click', click_anoption);
    }
    function change_selecthidden(e, arg){
        var _c = jQuery(this);
        if(arg!=undefined){
            _c = arg;
        }
        var _con = _c.parent();
        var selind = _c.children().index(_c.children(':selected'));
        var _slidercon = _con.parent().parent();
        //console.log(selind);
        _con.find('.an-option').removeClass('active');
        _con.find('.an-option').eq(selind).addClass('active');
        //console.log(_con);
        do_changemainsliderclass(_slidercon, selind);
    }
    function click_anoption(e){
        var _c = jQuery(this);
        var ind = _c.parent().children().index(_c);
        var _con = _c.parent().parent();
        var _slidercon = _con.parent().parent();
        _c.parent().children().removeClass('active');
        _c.addClass('active');
        _con.children('select').eq(0).children().removeAttr('selected');
        _con.children('select').eq(0).children().eq(ind).attr('selected', 'selected');
        do_changemainsliderclass(_slidercon, ind);
        //console.log(_c, ind, _con, _slidercon);
    }
    function do_changemainsliderclass(arg, argval){
        //extra function - handmade
        //console.log(arg, argval, arg.find('.mainsetting').eq(0).children().eq(argval).val());

        if(arg.hasClass('select-hidden-con')){
            arg.removeClass('mode_thumb'); arg.removeClass('mode_gallery');  arg.removeClass('mode_audio'); arg.removeClass('mode_video'); arg.removeClass('mode_youtube'); arg.removeClass('mode_vimeo'); arg.removeClass('mode_link'); arg.removeClass('mode_testimonial'); arg.removeClass('mode_link'); arg.removeClass('mode_twitter');

            arg.addClass('mode_' + arg.find('.mainsetting').eq(0).children().eq(argval).val());

        }
        if(arg.hasClass('item-settings-con')){
            arg.removeClass('type_youtube'); arg.removeClass('type_normal'); arg.removeClass('type_vimeo'); arg.removeClass('type_audio'); arg.removeClass('type_image'); arg.removeClass('type_link');

            if(argval==0){
                arg.addClass('mode_youtube')
            }
            if(argval==1){
                arg.addClass('mode_normal')
            }
            if(argval==2){
                arg.addClass('mode_vimeo')
            }
            if(argval==3){
                arg.addClass('mode_audio')
            }
            if(argval==4){
                arg.addClass('mode_image')
            }
            if(argval==5){
                arg.addClass('mode_link')
            }
        }
    }

}






jQuery(document).ready(function($){

    var inter_check_dp_settings = 0;

    // console.info("this is hier");

    $(document).on('change.dzsdepe', '.dzs-dependency-field,*[name="0-settings-vpconfig"]',handle_change);
    function handle_change(e) {

        //console.info(e);

        var _t = $(this);
        if (_t.hasClass('dzs-dependency-field')) {
            // console.info("ceva");
            check_dependency_settings_pre();
        }

    }


    function check_dependency_settings_pre(){


        clearTimeout(inter_check_dp_settings);
        inter_check_dp_settings = setTimeout(function(){
            check_dependency_settings()
        },100);

    }








    function check_dependency_settings(pargs){



        var margs = {
            target_attribute: 'name'
        }



        if(pargs){

            margs = $.extend(margs,pargs);
        }

        if(window.dzs_suspend_dependency_check){
            return false;
        }

        console.info("%c THIS DEPENDENCY CHECK",'color: #00aaff;',$('*[data-dependency]'));


        $('*[data-dependency]').each(function(){
            var _t = $(this);


            //console.info(_t, _t.attr('data-dependency'));

            var str_dependency = _t.attr('data-dependency');
            str_dependency = str_dependency.replace(/{{quot}}/g, '"');

            // console.info('_t.attr(\'data-dependency\') -' , _t.attr('data-dependency'));


            // -- todo: we treat this bug "{[dada,"dada"]}"

            if(str_dependency.indexOf('"')==0){
                str_dependency = str_dependency.substr(1,str_dependency.length-2);
            }
            var dep_arr = []


            try{
                dep_arr = JSON.parse(str_dependency);

                //console.warn(dep_arr);

                if(dep_arr[0]){
                    var _c = null;



                    var target_attribute = margs.target_attribute;

                    var target_con = $(document);


                    if(_t.hasClass('check-label')){
                        target_attribute = 'data-label';
                    }
                    if(_t.hasClass('check-parent1')){
                        target_con = _t.parent();
                    }
                    if(_t.hasClass('check-parent2')){
                        target_con = _t.parent().parent();
                    }
                    if(_t.hasClass('check-parent3')){
                        target_con = _t.parent().parent().parent();
                    }






                    // console.warn('target_con - ',target_con);
                    // console.warn('target_attribute - ',target_attribute);


                    if(dep_arr[0].lab){
                        _c = target_con.find('*['+target_attribute+'="'+dep_arr[0].lab+'"]:not(.fake-input)').eq(0);

                        if(_c.length==0){
                            _c = target_con.find('*[name="0-settings-'+dep_arr[0].lab+'"]:not(.fake-input)').eq(0);
                            // console.log('%c selector - ','color: #00ffdd;','*[name="'+dep_arr[0].lab+'"]:not(.fake-input)');
                        }
                        console.info('_c - ',_c, dep_arr[0].label, dep_arr,str_dependency,'%c selector','color: #ff00dd;',dep_arr[0].lab);
                    }
                    if(dep_arr[0].label){
                        _c = target_con.find('*['+target_attribute+'="'+dep_arr[0].label+'"]:not(.fake-input)').eq(0);


                        if(_c.length==0){
                            _c = target_con.find('*[name="0-settings-'+dep_arr[0].lab+'"]:not(.fake-input)').eq(0);
                            // console.log('%c selector - ','color: #00ffdd;','*[name="'+dep_arr[0].lab+'"]:not(.fake-input)');
                        }
                    }
                    if(dep_arr[0].element){
                        _c = target_con.find('*['+target_attribute+'="'+dep_arr[0].element+'"]:not(.fake-input)').eq(0);
                    }





                    if(_c){

                        var cval = _c.val();

                        console.info('_c.val() - ', _c.val(), dep_arr[0].val);

                        var sw_show = false;


                        if(dep_arr[0].val){

                            for(var i3 in dep_arr[0].val) {
                                if (_c.val() == dep_arr[0].val[i3]) {
                                    sw_show = true;

                                    console.error('sw_Show - ',sw_show);
                                    break;

                                }
                            }
                        }



                        if(dep_arr.relation){



                            // console.error(dep_arr.relation);

                            for(var i in dep_arr){
                                if(i=='relation'){
                                    continue;
                                }


                                if(dep_arr[i].value){
                                    if(dep_arr.relation=='AND'){
                                        sw_show=false;
                                    }



                                    if(dep_arr[0].element){
                                        _c = target_con.find('*['+target_attribute+'="'+dep_arr[i].element+'"]:not(.fake-input)').eq(0);
                                    }


                                    for(var i3 in dep_arr[i].value) {


                                        // console.info('_c.val() -  ',_c.val(), dep_arr[i].value[i3]);
                                        if (_c.val() == dep_arr[i].value[i3]) {


                                            if(_c.attr('type')=='checkbox'){
                                                if(_c.val() == dep_arr[i].value[i3] && _c.prop('checked')){

                                                    sw_show = true;
                                                }
                                            }else{

                                                sw_show = true;
                                            }

                                            break;

                                        }


                                        if(dep_arr[i].value[i3]=='anything_but_blank' && cval){

                                            sw_show=true;
                                            break;
                                        }
                                    }

                                    // console.info('sw_show - ',sw_show);
                                }

                            }

                        }else{

                            if(dep_arr[0].value){

                                var breaker = 500;
                                for(var i3 in dep_arr[0].value) {
                                    if (_c.val() == dep_arr[0].value[i3]) {


                                        if(_c.attr('type')=='checkbox'){
                                            if(_c.val() == dep_arr[0].value[i3] && _c.prop('checked')){

                                                sw_show = true;
                                            }
                                        }else{

                                            sw_show = true;
                                        }

                                        break;

                                    }


                                    if(dep_arr[0].value[i3]=='anything_but_blank' && cval){

                                        sw_show=true;
                                        break;
                                    }

                                    breaker--;

                                    if(breaker<0){
                                        return false;
                                    }
                                }
                            }
                        }


                        if(sw_show){
                            // console.info('%c lets show it _t - ','color: #ff0022;',_t);
                            _t.show();
                        }else{
                            _t.hide();
                        }
                    }


                }
            }catch(err){
                console.error('json dependency error - ',str_dependency);
                console.error(err);
            }
        })
    }
});



if(window.jQuery){

    jQuery(document).ready(function($){
        dzswtl_admin_global_local($)
    });
}else{

    document.addEventListener("DOMContentLoaded", function(event) {
        dzswtl_admin_global_local(window.jQuery);
    });
}