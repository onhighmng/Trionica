
var sliderIndex = 0;
var itemIndex = [0];
var currSlider_nr=-1;
var currSlider;
var targetInput;
var global_items = 0;



function dzswtl_admin_js_local($){
    //    return;

    $('.saveconfirmer').fadeOut('slow');


    if(window.dzswtl_settings && window.dzswtl_settings.post_type && window.dzswtl_settings.post_type=='dzswtl_list_layout'){


        // console.info("DISABLE STARTUP INIT FOR DZSSEL ( VERY SLOW )")
        window.dzssel_startup_init = false;
        console.info("LETS SUSPEND window.dzs_suspend_dependency_check");
        window.dzs_suspend_dependency_check = true;


        setTimeout(function(){

            dzssel_init('select.dzs-style-me', {init_each: true
                ,'call_from': 'timeout admin'});

        },5000);
        // return false;
    }



    $(document).on('widget-updated', function(){
        dzssel_init('select.dzs-style-me', {
            init_each: true
            ,'call_from': 'widget-updated'
        });
    })

    $(document).on('click','.dzswtl-save-quick', function(){

        var _t = $(this);
        setTimeout(function(_t){

            // $('#submitdiv').trigger('submit');
            // $('input[name=save]').trigger('click');



            _t.addClass('disabled');


            $( window ).off( 'beforeunload')
            // $( window ).off( 'onbeforeunload')
            //
            //
            // window.removeEventListener("beforeunload");

            $.ajax({
                method: "POST"
                , url: ajaxurl
                , data: {
                    action: 'dzswtl_quick_save_layout'
                    ,postdata: window.dzswtl_last_output
                    ,post_id: $('input[name="post_ID"]').eq(0).val()
                }
                ,success: function(response){
                    // console.info(response);





                    _t.removeClass('disabled');

                }

            });

            return false;

        },200,_t)

        return false;
    })



    $(document).on('click','.btn-show-classic-editor', function(){
        $('#postdivrich').show();
        $('#wp-content-media-buttons').hide();
        $('#ed_toolbar').hide();
        $('.wp-editor-area').css('margin-top',0);
        $('head').append('<style>.wp-editor-area { margin-top: 0 !important;;} </style>');
        return false;
    })




    // console.info('window.dzswtl_settings - ',window.dzswtl_settings);
    if(window.dzswtl_settings && window.dzswtl_settings.post_type && window.dzswtl_settings.post_type=='dzswtl_list_layout'){


        console.info("HMM");
        // $("#postdivrich").dzspgb({
        //         mode:"Row"
        //         ,append_after_cthis: "on"
        //         ,is_wp: "on"
        //         ,init_first_content: window.wp_read_tinymce()
        //         ,edit_in_zoombox: "off"
        //     }
        // );



        if($.fn.dzslistbuilder) {

            $("#postdivrich").hide();
            $("#postdivrich").before('<p><button class="button-secondary btn-show-classic-editor">' + 'Show Classic Editor' + '</button></p>');

            var _c = $('#listbuilder-con').eq(0);
            $("#postdivrich").after(_c);
        }



        setTimeout(function(){


            // console.info(_c);

            if($.fn.dzslistbuilder){


                // -- todo: here we init builder
                _c.dzslistbuilder({

                });
            }else{
                console.warn('list builder not found')
            }


        },50)



        if($.fn.dzslistbuilder) {
            var _c2 = $('#postbox-container-1').eq(0);

            _c2.wrap('<div class="dzstooltip-con hover-on-tooltip-con-too placeitright wrap-update-btn"><div class="dzstooltip talign-end arrow-top style-rounded color-light-dark  dims-set transition-scaleup " style="width: 310px;"><div class="dzstooltip--inner"></div></div></div>')


            $('.wrap-update-btn').prepend('<span class="button tooltip-indicator button-primary dzswtl-save-quick">Save</span> ');

        }



    }








}

if(window.jQuery){

    jQuery(document).ready(function($){
        dzswtl_admin_js_local($)
    });
}else{

    document.addEventListener("DOMContentLoaded", function(event) {
        dzswtl_admin_js_local(window.jQuery);
    });
}

