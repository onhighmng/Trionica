<?php


add_action('widgets_init', array('dzswtl_widget', 'register_this_widget'));

if(!class_exists('dzswtl_widget')) {
    class dzswtl_widget extends WP_Widget
    {
        public $name = "WooTable Filter";
        public $control_options = array();

        function __construct(){
            $wdesc = '';

            $this->name = "WooTable ".__("Filter");
            if (isset($this->widget_desc)) $wdesc = $this->widget_desc;
            $widget_options = array(
                'classname' => __CLASS__,
                'description' => $wdesc,
            );
            parent::__construct(__CLASS__, $this->name, $widget_options, $this->control_options);
        }

        //!!! Static Functions
        static function register_this_widget()
        {
            register_widget(__CLASS__);
        }

        function form($instance)
        {

            $defaults = array(
                'zs1id' => '1',
                'feed_from' => 'title',
                'shortcode' => '',
                'title' => $this->name,
            );
            $instance = wp_parse_args((array)$instance, $defaults);


            $lab = 'title';
            ?>

            <div class="setting">
                <h5 for="widget-q_latestworks-5-title"><?php echo __("Title"); ?></h5>
                <input type="text" name="<?php echo $this->get_field_name('title') ?>" id="<?php echo $this->get_field_id('title') ?>" value="<?php echo $instance['title'] ?>" size="20">
            </div>


            <?php

	        $lab = 'shortcode';
	        ?>

            <div class="setting">
                <h5 for="widget-q_latestworks-5-title"><?php echo __("Shortcode"); ?></h5>
                <div class="dzs-wrap-input-button"><textarea type="text" name="<?php echo $this->get_field_name($lab) ?>" id="<?php echo $this->get_field_id($lab) ?>"  rows="3"><?php echo $instance[$lab] ?></textarea> <button class="button-secondary btn-generate-dzswtl-filter"><?php echo esc_html__('generate','dzswtl'); ?></button></div>
            </div><?php



        }

        function widget($args, $instance=array()){
            global $dzswtl;
            extract($args);

            $dzswtl->index_filter++;


            $index_filter = $dzswtl->index_filter;



            $margs = array(

                    'title'=>$this->name,
                    'feed_from'=>'categories',
                    'type'=>'detect',
                    'slider_min'=>'0',
                    'slider_max'=>'300',
                    'custom_meta_values'=>'',
                    'index_filter'=>'',

            );

            $margs = array_merge($margs, $instance);



            $title = $margs['title'];
            //$title = $instance['zs1id'];


            $fout = '';

            $fout.= $before_widget;
            $fout.= $before_title;
            $fout.= $title;
            $fout.= $after_title;


            //do_shortcode('[phoenixgallery]');

//            $arr = array("id" => $instance['zs1id']);
//            echo $dzswtl->show_shortcode($arr);





//            $fout.=print_rrr($margs);


            if(isset($_GET) && is_array($_GET) && count($_GET)>0){
//                print_rr($_GET);
            }

            if($margs['shortcode']){
                $fout.=do_shortcode($margs['shortcode']);
            }else{

	            $fout.=$dzswtl->shortcode_woo_filter($margs);
            }









            $fout.= $after_widget;

            echo $fout;
        }

    }
}



