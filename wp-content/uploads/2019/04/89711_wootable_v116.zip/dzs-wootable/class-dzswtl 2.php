<?php

class DZSWooTable {


	public $thepath;
	public $base_url;
	public $base_path;
	public $indexnr = 0;
	public $shortcode = 'pricingtable';
	public $pluginmode = "plugin";
	public $alwaysembed = 'on';
	public $mode = 'plugin';
	public $adminpagename_mainoptions = 'dzswtl_menu';
	public $adminpagename_mainoptions_settings = 'dzswtl_menu_settings';
	public $admin_capability = 'manage_options';
	private $fe_colinner_not_set_yet = true;
	private $sw_enable_multisharer = true;


	public $footer_extra_html = '';

	public $db_mainoptions = array();
	public $dbname_mainoptions = 'dzswtl_mo';

	public $admin_tax = 'category'; // -- the post taxonomy can be changed from $_GET
	public $admin_post_type = 'post'; // -- the post type we are trying to

	public $options_for_each_theme = array();

	public $capability_admin = 'manage_options';


	public $debug_mode = false; // -- set this to "true" for preview mode
	public $is_preview = false; // -- set this to "true" for preview mode
	public $plugin_justactivated = false; // -- set this to "true" for preview mode



	public $options_array_player = array();
	public $options_array_playlist = array();
	public $notifications = array();

	private $call_index = 50; // -- only allow 50 calls of the main shortcode function to prevent stack overflow
	public $index_filter = 0; // -- only allow 50 calls of the main shortcode function to prevent stack overflow

	public $options_item_meta = array();


	public $args_curr_wootable = array();
	private $term_metas = array();
	public $sanitized_get = array();
	public $attribute_extra_types = array();
	public $generate_layout_item_default_margs = array();


	public $allowed_tags = array(
		'p'=>array(
			'class'=>array(),
			'style' => array(),
		),
		'strong'=>array(),
		'em'=>array(),
		'br'=>array(),
		'a'=>array(
			'href' => array(),
			'target' => array(),
			'style' => array(),
		),
	);

	function __construct() {




		if ($this->pluginmode == 'theme') {
			$this->thepath = THEME_URL . 'plugins/dzs-preview/';
		} else {
			$this->thepath = plugins_url('', __FILE__) . '/';
		}


		$this->base_path = dirname(__FILE__) . '/';
		$this->base_url = $this->thepath;



		$this->generate_layout_item_default_margs = array(
			'position_type' => 'relative',
			'display_type' => '',
			'index' => '0',
			'width' => 'auto',
			'max_width' => '',
			'height' => 'auto',
			'top' => 'auto',
			'right' => 'auto',
			'bottom' => 'auto',
			'left' => 'auto',
			'margin_top' => '0',
			'margin_right' => '0',
			'margin_bottom' => '0',
			'margin_left' => '0',
			'padding_top' => '0',
			'padding_right' => '0',
			'padding_bottom' => '0',
			'padding_left' => '0',
			'border_radius' => '0',
			'border_width' => '0',
			'border_color' => 'transparent',
			'color' => '',
			'background_color' => 'transparent',
			'background_image' => '',
			'type' => 'rect',
			'animation_brake' => '',

			'font_size' => '',
			'flex_mode' => '',
			'flex_stretch' => '',


			'text_align' => 'left',
			'font_weight' => '',
			'opacity' => '',
			'text' => '',
			'custom_acf_name' => '',
			'attr_link_to' => '',
			'thumbnail_size' => '',
			'thumbnail_height' => '',
			'attr_style' => '',
			'link_to' => '',
			'custom_attr_name' => '',
			'custom_meta_name' => '',
			'feed_from_ratings_style' => 'default',


			'extra_classes' => '',
			'zoomsounds_play_in_footer' => '',
			'zoomsounds_vpconfig' => '',
			'zoomsounds_mode' => 'full-player',
			'feed_from_price_style' => '',
			'extra_html'=>'',
			'extra_html_before'=>'',
			'desc_count'=>'',
			'show_sort_button' => 'default',

			'overflow' => '',
			'button_type' => 'add-to-cart',
			'button_style' => 'default',
			'button_functionality' => 'default',
			'button_custom_text' => '',
			'table_header_title' => '',


		);
//        return;

//        header('X-Frame-Options: GOFORIT');
		if (isset($_GET['tax'])) {
			$this->admin_tax = $_GET['tax'];
		}
		if (isset($_GET['post_type'])) {
			$this->admin_post_type = $_GET['post_type'];
		}
		if (isset($_GET['debug_mode']) && $_GET['debug_mode']=='on') {
			$this->debug_mode = true;
		}
		if (defined('DZSWTL_DEBUG_MODE') && DZSWTL_DEBUG_MODE=='on') {
			$this->debug_mode = true;
		}

		$this->attribute_extra_types = array(
			'color' => esc_html__( 'Color', 'wcvs' ),
		);

		$defaultOpts = array(
			'enable_ajax' => 'on',
			'zoomsounds_play_in_footer' => 'off',
			'style_widget' => 'off',
			'filter_check_availability' => 'off',
			'scripts_reinit_document_ready' => 'on',
			'jquery_ui_theme' => 'base',
			'convert_search_field_from_theme' => '',
			'replace_woocommerce_category_page_shortcode' => '',

		);
		$this->db_mainoptions = get_option($this->dbname_mainoptions);

		//==== default opts / inject into db
		if ($this->db_mainoptions == '') {
			$this->db_mainoptions = $defaultOpts;
			update_option($this->dbname_mainoptions, $this->db_mainoptions);
		} else {

			$this->db_mainoptions = array_merge($defaultOpts, $this->db_mainoptions);
		}


		$this->base_url = plugins_url('', __FILE__) . '/';
		$this->base_path = dirname(__FILE__) . '/';


//        print_r($this->db_mainoptions);


		if ($this->db_mainoptions['scripts_reinit_document_ready'] == 'on') {

//            add_filter('body_class', array($this, 'browser_body_class'));
		}




		$this->term_metas = array(
			array(
				'name'=>'icon',
				'title'=>__('Icon'),
				'description'=>__('main icon of the category'),
				'type'=>'iconselector',
			),
			array(
				'name'=>'color',
				'title'=>__('Tag Color'),
				'description'=>__('for tag color '),
				'type'=>'color',
			),
			array(
				'name'=>'image',
				'title'=>__('Image'),
				'description'=>__('image'),
				'type'=>'media-upload',
			),
		);





		include_once("widget.php");
		include_once("class_parts/generate-layer-item.php");




		add_action('wp_ajax_dzswtl_ajax_mo', array($this, 'post_save_mo'));
		add_action('wp_ajax_dzswtl_prev_array', array($this, 'ajax_dzswtl_prev_array'));
		add_action('wp_ajax_dzswtl_quick_save_layout', array($this, 'ajax_quick_save_layout'));
		add_action('wp_ajax_dzswtl_generate_attribute_sort', array($this, 'ajax_generate_attribute_sort'));
		add_action('wp_ajax_dzswtl_con_generator_preview_shortcode', array($this, 'ajax_con_generator_preview_shortcode'));
		add_action('wp_ajax_dzswtl_import_layout', array($this, 'ajax_import_layout'));


		add_action('wp_ajax_dzswtl_add_to_wishlist', array($this, 'ajax_add_to_wishlist'));
		add_action('wp_ajax_nopriv_dzswtl_add_to_wishlist', array($this, 'ajax_add_to_wishlist'));


        add_action('add_meta_boxes',array($this,'handle_add_meta_boxes'));


		add_action('current_screen', array($this, 'handle_current_screen'));
		add_action('edit_post', array($this, 'handle_edit_post'));
		add_action('save_post', array($this, 'handle_edit_post'));
		add_action('init', array($this, 'handle_init'));
		add_action('init', array($this, 'handle_init_end'),999);


        add_action('wp_head', array($this, 'handle_wp_head'));
		add_action('wp_footer', array($this, 'handle_wp_footer'));

		add_action('admin_head', array($this, 'handle_admin_head'));
		add_action('admin_footer', array($this, 'handle_admin_footer'));
		add_action('admin_menu', array($this, 'handle_admin_menu'));






//		add_filter( 'login_enqueue_scripts', array($this, 'login_enqueue_scripts') );


		add_action( 'save_post', array($this,'handle_save_post') );
//		add_action( 'edit_post', array($this,'handle_save_post') );


		add_shortcode('dzs_woo_filter_con', array($this, 'shortcode_woo_filter_con'));

		add_shortcode('dzs_woo_searcher', array($this, 'shortcode_woo_searcher'));
		add_shortcode('dzs_woo_filter', array($this, 'shortcode_woo_filter'));
		add_shortcode('dzs_woo_table_sorter', array($this, 'shortcode_woo_sorter'));
		add_shortcode('dzs_woo_table', array($this, 'shortcode_woo_table'));
		add_shortcode('dzs_woo_table_hr', array($this, 'shortcode_woo_table_hr'));
		add_shortcode('dzs_woo_layout_chooser', array($this, 'shortcode_layout_chooser'));
		add_shortcode('dzs_woo_submit_changes_button', array($this, 'shortcode_submit_changes_button'));
		add_shortcode('dzswtl_tabs_content', array($this, 'shortcode_tabs_content'));

		add_shortcode('directory_tag_display', array($this, 'shortcode_directory_tag_display'));



		// -- deprecated
		add_shortcode('dzs_woo_table_searcher', array($this, 'shortcode_woo_searcher'));



	}

	function shortcode_tabs_content($margs, $content = ''){




	    $fout = '';
		$fout.='<div class="dzswtl-tabs-content">';
		$fout.=do_shortcode($content);
		$fout.='</div>';


		return $fout;




	}

	function generate_style_for_flex($margs){



	    $fout = '';
		if(isset($margs['flex_prop']) && $margs['flex_prop']){


			$flex_prop = '';

			if($margs['flex_prop']=='auto'){

				$flex_prop = '0 0 auto';
			}
			if($margs['flex_prop']=='1000'){
				$flex_prop = $margs['flex_prop'];
			}

			if($flex_prop){

				$fout.='flex: '.$flex_prop;
				$fout.=';';
			}

			$fout.='max-width: none';
			$fout.=';';
		}

		if(isset($margs['margin_left']) && $margs['margin_left']){


			$fout.='margin-left: '.$margs['margin_left'];
			$fout.=';';
		}
		if(isset($margs['margin_right']) && $margs['margin_right']){

			$fout.='margin-right: '.$margs['margin_right'];
			$fout.=';';
		}

		return $fout;
    }


	function sanitize_get_arr() {
	    // -- let us sanitize get input

        $this->sanitized_get = array_merge(array(),$_GET);

//        print_rr($this->sanitized_get);


        foreach ($this->sanitized_get as $lab=>$val){
            if(strpos($val,'wtn-wtn')!==false){
                $arr = explode('wtn-wtn',$val);


                if(isset($this->sanitized_get[$lab.'dzswoomin'])==false){
	                $this->sanitized_get[$lab.'dzswoomin'] = $arr[0];
                }
                if(isset($this->sanitized_get[$lab.'dzswoomax'])==false){

                    if($arr[1]=='infinite'){
                        $arr[1] = '99999999';
                    }
	                $this->sanitized_get[$lab.'dzswoomax'] = $arr[1];
                }

//                print_rr($arr);
            }
        }
	}
	function shortcode_directory_tag_display($pargs, $content='') {


		$margs = array(
			'display'  => 'default', // -- default or round-white-bg
			'style'  => 'default', // -- default or round-white-bg
			'per_row'  => '6', // -- default or round-white-bg
			'cat'  => 'parent_tags', // -- default or round-white-bg
			'classes'  => '', // -- default or round-white-bg
			'scroller_type'  => '', // -- default or round-white-bg
			'page_url'  => '', // -- go to filter a page or keep current page
			'scroller_image_height'  => '80%', // -- go to filter a page or keep current page
		);


		if ( is_array( $pargs ) ) {
			$margs = array_merge( $margs, $pargs );
		}



		$fout = '';
		$fout.='<div class="dzsdtf-tags-con-display tags-display-'.$margs['display'].' style-'.$margs['style'].' '.$margs['classes'].'">';




		$taxonomy = 'product_cat';


		$main_tag_name = 'product_cat';

		if($margs['page_url']==''){
		    $margs['page_url']=dzs_curr_url();
		}
		if($margs['cat']=='parent_tags'){




			$terms = get_terms( $taxonomy, array(
				'hide_empty' => false,
				'parent' => 0,
			) );


//		    print_rr($terms);

		}else{




			$term_id = $this->sanitize_term_slug_to_id($margs['cat'], $taxonomy);



			$terms = get_terms( $taxonomy, array(
				'hide_empty' => false,
				'parent' => $term_id,
			) );

		}




		// -- start display


		if($margs['display']=='default'){

			$fout.='<div class="dzs-row">';
		}
		if($margs['display']=='scroller'){




			$fout.='<div class="contentscroller scroller-type-'.$margs['scroller_type'].' auto-init bullets-none animate-height " data-margin="30" style="; height: auto;" data-options=\'{
    "settings_direction": "horizontal"
    ,"settings_onlyone": "off"
    ,"settings_autoHeight": "on"
    ,"per_row": "'.$margs['per_row'].'"
    ,"outer_thumbs": "#cs2"
}\'>

                    <div class="arrowsCon arrow-skin-bare" style="text-align: right;">
                        <div class="arrow-left">
                            <div class="arrow-con">
                                <i class="the-icon fa fa-long-arrow-left"></i>
                            </div>
                        </div>
                        <div class="arrow-right">

                            <div class="arrow-con">
                                <i class="the-icon fa fa-long-arrow-right"></i>
                            </div>
                        </div>
                    </div>
                    <div class="items">';
		}

		// -- display

		foreach ($terms as $term){


		    if(isset($term->slug)==false){
		        continue;
            }
		    if($term->slug=='uncategorized'){
		        continue;
            }



            $getlab = 'customtax_'.$main_tag_name;


		    if($getlab=='customtax_product_cat'){
		        $getlab = 'cat';
            }


//	        print_rr($margs);
			$link = add_query_arg(array(
				$getlab=>$term->slug,
			),$margs['page_url']);
			$t_id = $term->term_id;
			$term_meta = get_option("taxonomy_$t_id");

			$parent_term_icon = '';
			if(isset($term_meta['icon'])){
				$parent_term_icon = $term_meta['icon'];
			}

			$label = $term->name;




			if($margs['display']=='default'){

				$fout.='<a href="'.$link.'" class="dzs-col-md-4 tag-display';



				if(isset($_GET[$getlab]) && $_GET[$getlab]==$term->slug){


					$fout.=' active';

				}

				$fout.='">';
				$fout.='<div class=" tag-display--inner">';




				if($parent_term_icon){

					$fout.='<i class=" the-icon-con">';
					$fout.='<i class=" the-icon fa fa-'.$parent_term_icon.'" style="';

					if(isset($term_meta['color'])){
						$fout.='color: '.$term_meta['color'].'';
					}

					$fout.='">';
					$fout.='</i>';
					$fout.='</i>';
				}

				if($parent_term_icon){
					$fout.='<span class=" the-label" >';

					$fout.=$label;
					$fout.='</span>';
				}



				$fout.='</div>';
				$fout.='</a>';
			}
			if($margs['display']=='scroller'){


				// -- scroller display

				$fout.='<a href="'.$link.'" class="csc-item ';



//				print_rr($term_meta);

//				echo 'image_src - '.$this->sanitize_id_to_src($term_meta['image']);

				$image_src = $this->sanitize_id_to_src($term_meta['image']);



				if(isset($_GET['tag_'.$main_tag_name]) && $_GET['tag_'.$main_tag_name]==$term->slug){


					$fout.=' active';

				}

				$fout.='" style="text-align: center">
';
				$fout.='<div class="csc-item--inner--inner">';

				if($margs['scroller_type']=='image'){

					$fout.='<div class="the-img-con">';

					if(isset($term_meta['image'])){
						$fout.='<div class="the-img divimage" style="padding-top: '.$margs['scroller_image_height'].'; background-image:url('.$image_src.')">';
						$fout.='</div>';

					}
					$fout.='</div>';
					$fout.='<h6 class="the-label-title">'.$label.'</h6>';
				}else{

					$fout.='<div class="the-bg" style=""></div>';




					$fout.='<div class="flex-abs-container">';

					if($parent_term_icon){


						$fout.='<i class=" the-icon-con">';
						$fout.='<i class=" the-icon fa fa-'.$parent_term_icon.'" style="';

						if(isset($term_meta['color'])){
//				        $fout.='color: '.$term_meta['color'].'';
						}

						$fout.='">';
						$fout.='</i>';
						$fout.='</i>';
					}




					$fout.='<h6 class="the-label-title">'.$label.'</h6>';
					$fout.='
</div>';
				}

				$fout.='
</div>';
				$fout.='
</a>';
			}
		}



		if($margs['display']=='default'){
			$fout.='
                </div>';
		}


		if($margs['display']=='scroller'){
			$fout.='
                    </div>


                </div>';
			wp_enqueue_script('contentscroller',$this->base_url.'libs/contentscroller/contentscroller.js');
			wp_enqueue_style('contentscroller',$this->base_url.'libs/contentscroller/contentscroller.css');
		}

		$fout.='
                </div>';


		wp_enqueue_style('dzswtl', $this->base_url . "libs/dzswootable/dzswootable.css");
		wp_enqueue_script('dzswtl', $this->base_url . "libs/dzswootable/dzswootable.js");






		$fontawesomelink = $this->base_url . 'libs/fontawesome/font-awesome.min.css';
		if(defined("DZSWTL_USE_FONTAWESOME_FROM_CDN") && DZSWTL_USE_FONTAWESOME_FROM_CDN=="ON"){
			$fontawesomelink = 'https://'.'maxcdn'.'bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css';
		}

		wp_enqueue_style( 'fontawesome', $fontawesomelink);




		return $fout;


	}

	function search_pre_get_posts($query){

//		error_log('dzswtl query is_search - '.print_r($query->is_search(),true));
//		error_log('dzswtl query - pre_get_posts - '.print_r($query,true));


    }


	function __search_by_title_only( $search, $wp_query ){
		if ( ! empty( $search ) && ! empty( $wp_query->query_vars['search_terms'] ) ) {
			global $wpdb;

			$q = $wp_query->query_vars;

//            print_rr($q);
			$n = ! empty( $q['exact'] ) ? '' : '%';

			$search = array();

			foreach ( ( array ) $q['search_terms'] as $term )
				$search[] = $wpdb->prepare( "$wpdb->posts.post_title LIKE %s", $n . $wpdb->esc_like( $term ) . $n );

			if ( ! is_user_logged_in() )
				$search[] = "$wpdb->posts.post_password = ''";

			$search = ' AND ' . implode( ' AND ', $search );
		}

		return $search;
	}




	function import_demo_insert_post_complete($pargs = array()) {






		$margs = array(

			'post_title'=>'',

			'post_content'=>'',
			'post_type'=>'dzswtl_list_layout',
			'post_status'=>'publish',
			'post_name'=>'',
			'img_url'=>'',
			'img_path'=>'',
			'term'=>'',
			'taxonomy'=>'',
			'attach_id'=>'',


		);

		$margs = array_merge($margs, $pargs);



		if($margs['post_name']){


			$the_slug = $margs['post_name'];
			$args = array(
				'name'        => $the_slug,
				'post_type'   => $margs['post_type'],
				'post_status' => 'publish',
				'numberposts' => 1
			);
			$my_posts = get_posts($args);


//            print_rr($my_posts);


			if ($my_posts) {

				if($margs['term']){

					if(is_object($margs['term']) && isset($margs['term']->term_id)){
						$term = $margs['term']->term_id;
					}else{

						if(is_array($margs['term']) && isset($margs['term']['term_id'])){
							$term = $margs['term']['term_id'];
						}
					}
//	                error_log('term for import - '.print_rr($term,true));
					wp_set_post_terms($my_posts[0]->ID, $term, $margs['taxonomy']);
				}
				return $my_posts[0];


//                print_r($my_posts);
			}
		}

		$args = array(
			'post_type' => $margs['post_type'],
			'post_title' => $margs['post_title'],

			'post_content' => $margs['post_content'],
			'post_status'=>$margs['post_status'],



			/*other default parameters you want to set*/
		);

		if($margs['post_name']){
//            $args['name']=$margs['post_name'];
			$args['post_name']=$margs['post_name'];
		}


		if($margs['term']){

			$term = $margs['term'];
		}
		$taxonomy = $margs['taxonomy'];

		if($margs['img_url']){

			$img_url = $margs['img_url'];
		}
		$img_path = $margs['img_path'];



//        print_rr($margs);



//	    error_log(' item import - '.print_rr($margs,true).print_rr($args,true));
		$port_id = $this->import_demo_create_portfolio_item($args);

		if($margs['term']) {
			$term = $margs['term'];



			if(is_object($margs['term']) && isset($margs['term']->term_id)){
				$term = $margs['term']->term_id;
			}
			wp_set_post_terms($port_id, $term, $taxonomy);
		}



		foreach ($margs as $lab => $val){
			if(strpos($lab,'dzswtl_meta')===0){

				update_post_meta($port_id,$lab,$val);
			}
		}






//        update_post_meta($port_id,'q_meta_post_media',$img_url);







		if($margs['attach_id']){

			set_post_thumbnail( $port_id, $margs['attach_id'] );
		}else{

			if($margs['img_url']) {
				$attach_id = $this->import_demo_create_attachment($img_url, $port_id, $img_path);
				set_post_thumbnail($port_id, $attach_id);

				$this->import_demo_last_attach_id = $attach_id;
			}

		}





		return $port_id;



	}


	function import_demo_create_term_if_it_does_not_exist($pargs = array()) {


		$margs = array(

			'term_name' => '',
			'slug' => '',
			'taxonomy' => '',
			'description' => '',
			'parent' => '',
		);

		$margs = array_merge($margs, $pargs);

		$term = get_term_by('slug', $margs['slug'], $margs['taxonomy']);


		if ($term) {

		} else {


			$args = array(
				'description' => $margs['description'],
				'slug' => $margs['slug'],


			);

			if ($margs['parent']) {
				$args['parent'] = $margs['parent'];
			}

			$term = wp_insert_term($margs['term_name'], $margs['taxonomy'], $args);

		}
		return $term;

	}



	function import_demo_create_attachment($img_url, $port_id, $img_path){






		$attachment = array(
			'guid'           => $img_url,
			'post_mime_type' => 'image/jpeg',
			'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $img_url ) ),
			'post_content'   => '',
			'post_status'    => 'inherit'
		);

// Insert the attachment.
		$attach_id = wp_insert_attachment( $attachment, $img_url, $port_id );


		require_once( ABSPATH . 'wp-admin/includes/image.php' );

// Generate the metadata for the attachment, and update the database record.
		$attach_data = wp_generate_attachment_metadata( $attach_id, $img_path );
//        die();
		wp_update_attachment_metadata( $attach_id, $attach_data );

		return $attach_id;
	}


	function import_demo_create_portfolio_item($pargs = array()) {






		$margs = array(

			'post_title'=>'',
			'post_content'=>'',
			'post_status'=>'',
			'post_type'=>'product',
		);

		$margs = array_merge($margs, $pargs);



		$args = array(
			'post_type' => $margs['post_type'],
			'post_title' => $margs['post_title'],
			'post_content' => $margs['post_content'],
			'post_status'=>$margs['post_status'],



			/*other default parameters you want to set*/
		);



		$post_id = wp_insert_post($args);

		return $post_id;


	}


	function post_save_mo() {

		$auxarray_defs = array('disable_api_caching' => 'off', 'disable_fontawesome' => 'off', 'tinymce_enable_preview_shortcodes' => 'off', 'force_file_get_contents' => 'off', 'debug_mode' => 'off', 'settings_trigger_resize' => 'off', 'replace_wpvideo' => 'off',
		                       'usewordpressuploader' => 'on',
		                       'dzsvp_enable_visitorupload' => 'off',
		                       'dzsvp_enable_ratings' => 'off',
		                       'dzsvp_enable_ratingscount' => 'off',
		);
		$auxarray = array();
		//parsing post data
		parse_str($_POST['postdata'], $auxarray);
//        print_r($auxarray);


//        print_r($_POST);
//        print_r($auxarray);

		$auxarray = array_merge($auxarray_defs, $auxarray);






		$lab = 'dzsvp_enable_user_upload_capability';



//        echo $auxarray['track_views'].'|||| '.

		$auxarray = array_merge($this->db_mainoptions, $auxarray);
		print_r($auxarray);;

		update_option($this->dbname_mainoptions, $auxarray);
		die();
	}

	function shortcode_woo_searcher($pargs = array()){




		$margs = array(

			'style_float'=>'',
			'flex_align'=>'',
			'flex_prop'=>'',
			'link'=>'',


		);





		if(is_array($pargs)){

			$margs = array_merge($margs, $pargs);
		}



		$fout = '';

		$lab = 'woo_search';


		$fout.='<div class="woo-table-searcher" style="';



		if($margs['style_float']){
			$fout.=' float: '.$margs['style_float'].';';
		}




		$fout.=$this->generate_style_for_flex($margs);

		$fout.='">';


		if($margs['link']){
		    $fout.='<form action="'.$margs['link'].'" method="GET">';
		    $lab = 'search';
        }

		$val = '';

		if(isset($_GET['search'])){
			$val = $_GET['search'];
		}


		$fout.=DZSHelpers::generate_input_text($lab, array(
			'class'=>'dzs-field ',
			'seekval'=>$val,
			'extraattr'=>' placeholder="'.__("Search").'... "',
			//                'class'=>'dzs-field ',

		));
		if($margs['link']){
			$fout.='</form>';
		}

		$fout.='</div>';



		return $fout;
	}


	function shortcode_submit_changes_button($pargs){

		$fout = '';
		$margs = array(

			'btn_text'=>"Submit",
			'style'=>"default",

		);

		if(is_array($pargs)==false){
			$pargs = array();
		}
		$margs = array_merge($margs, $pargs);


		$fout.='<button class="dzs-wtl-submit-changes-btn btn-style-'.$margs['style'].'">'.$margs['btn_text'].'</button>';
	    return $fout;
	}
	function shortcode_woo_table_hr($pargs){

		$margs = array(

			'background-color'=>"",

		);

		if(is_array($pargs)==false){
			$pargs = array();
		}
		$margs = array_merge($margs, $pargs);



		$fout = '';

		$fout.='<div class="clear"></div>';
		$fout.='<hr class="dzswtl-hr" style="';

		if($margs['background-color']){
		    $fout.=' background-color: '.$margs['background-color'];
        }

		$fout.='">';
		return $fout;
	}

	function sanitize_term_slug_to_id($arg,$taxonomy_name=''){


		if($taxonomy_name==''){
			$taxonomy_name= $this->name_port_item_cat;
		}

		if(is_numeric($arg)){

		}else{

			$term = get_term_by('slug', $arg, $taxonomy_name);

//			echo 'sanitize_term_slug_to_id() - $term - '; print_rr($term);

			if($term){
				$arg = $term->term_id;
			}

		}


		return $arg;
	}



	function generate_style($pargs = array(), $pargs_for_parent = array()){




		$margs = array_merge($this->generate_layout_item_default_margs, $pargs);


		$default_margs = $this->generate_layout_item_default_margs;


		if($margs['width']=='default'){

			if($margs['type']=='circ'){
				$margs['width']='100%';
			}
			if($margs['type']=='rect'){
				$margs['width']='{{perc}}';
			}
		}
		if($margs['width']=='default') {
			$margs['width'] = 'auto';
		}
		if($margs['height']=='default') {
			if($margs['type']=='container'){
				$margs['height']='auto';
			}
			if($margs['type']=='rect'){
				$margs['height']='40';
			}
		}



		$lab = 'width';



		$fout = '';



		$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
			'sanitize_to_css_size'=>true,
		));




		$lab = 'max_width';



		$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
			'sanitize_to_css_size'=>true,
		));


		$lab = 'flex_stretch';


		$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
			'sanitize_to_css_size'=>false,
		));


		$lab = 'position_type';


		$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
			'sanitize_to_css_size'=>false,
		));



		$lab = 'margin_left';

		$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
			'sanitize_to_css_size'=>true,
		));



		$lab = 'margin_right';

		$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
			'sanitize_to_css_size'=>true,
		));

		// -- we need no height for header_item and other args
		if( !(isset($pargs_for_parent['call_from']) && $pargs_for_parent['call_from']=='header_item') ){

			// -- not header item

			$lab = 'height';



			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>true,
			));




//		print_rr($margs);
			$lab = 'color';



			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>false,
			));



			$lab = 'background_color';



			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>false,
			));





			$lab = 'left';


			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>true,
			));

			$lab = 'right';



			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>true,
			));



			$lab = 'bottom';



			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>true,
			));



			$lab = 'top';




			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>true,
			));



			$lab = 'margin_top';

			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>true,
			));


			$lab = 'margin_bottom';

			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>true,
			));


			$lab = 'padding_top';

			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>true,
			));




			$lab = 'padding_bottom';

			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>true,
			));





			$lab = 'padding_left';

			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>true,
			));





			$lab = 'padding_right';

			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>true,
			));

			$lab = 'text_align';

			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>false,
			));

			$lab = 'font_size';

			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>true,
			));

			$lab = 'font_weight';

			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>false,
			));


			$lab = 'flex_mode';

			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>false,
			));
			$lab = 'display_type';

			$fout.=$this->generate_style_prop($margs,$lab,$default_margs, array(
				'sanitize_to_css_size'=>false,
			));

		}











//        print_rr($margs);



		return $fout;



	}


	function generate_style_prop($margs,$lab,$default_margs, $args=array()){


		$margs_func = array(
			'sanitize_to_css_size'=>false,
		);

		$margs_func = array_merge($margs_func, $args);


		if(isset($margs[$lab]) && $margs[$lab]!=='' && (isset($default_margs[$lab])==false || $margs[$lab]!=$default_margs[$lab] ) ){



			$css_lab = $lab;

			if($lab=='background_color'
			   || $lab=='max_width'
			   || $lab=='margin_top'
			   || $lab=='text_align'
			   || $lab=='font_size'
			   || $lab=='font_weight'
			   || strpos($lab,'padding_')===0
			   || strpos($lab,'margin_')===0
			){
				$css_lab = str_replace('_','-',$lab);
			}

			if($lab=='position_type'){
				$css_lab = 'position';
			}

			if($lab=='flex_stretch'){
				$css_lab = 'flex';
			}


			$css_val = ($margs[$lab]);



			if($margs_func['sanitize_to_css_size']){

				$css_val =  dzs_sanitize_to_css_size($margs[$lab]);
			}

			if($lab=='flex_mode'){

			    if($margs[$lab]=='flex'){


				    $css_lab = 'display';
                }
			}
			if($lab=='display_type'){

			    if($margs[$lab]=='inline-block'){


				    $css_lab = 'display';
                }
			}




            return $css_lab. ': '.$css_val.'; ';
		}

		return '';






	}






	public function handle_plugin_activate() {
		$this->plugin_justactivated = "on";
//        echo 'ceva';

//        error_log('activation_hook');


	}

	function sanitize_id_to_src($arg){

//        echo ' arg - '.$arg;
		if(is_numeric($arg)){

			$imgsrc = wp_get_attachment_image_src($arg, 'full');
//            print_r($imgsrc);
//            echo ' $imgsrc - '.$imgsrc;
			return $imgsrc[0];
		}else{
			return $arg;
		}


	}






	function shortcode_layout_chooser($pargs = array(), $content=''){


	    global $post;


		$margs = array(

			'layout_link'=>'',
			'extra_classes'=>' ',


		);



//		echo '$content filter_con - ';print_rr($content);


		if(is_array($pargs)){

			$margs = array_merge($margs, $pargs);
		}

	    $fout = '';





		$layout = '';







		if($post && $post->ID){
//		    print_rr($_COOKIE);

            $po_content = $post->post_content;


			preg_match("/layout=\"(.*?)\"/", $po_content, $output_array);

//			print_rr($output_array);

            if(isset($output_array[1])){
                $layout = $output_array[1];
            }


			if(isset($_COOKIE['dzswtl_layout_'.$post->ID])){
				$layout = $_COOKIE['dzswtl_layout_'.$post->ID];
			}
			if(isset($_GET['layout'])){
				$layout = $_GET['layout'];
			}


		}




		$fout.='<a class="layout-chooser-a ';


		if($layout == $margs['layout_link']){
            $fout.=' active';
		}

		$fout.='" style="" href="?layout='.$margs['layout_link'].'&cookie_set_layout=on">';


		$content = str_replace('{{icon_list}}','<svg  version="1.1"  x="0px" y="0px" viewBox="0 0 384 384" style="enable-background:new 0 0 384 384;" xml:space="preserve" width="24px" height="20px"> <g> <g> <g> <rect x="0" y="170.667" width="42.667" height="42.667" fill="#474747"/> <rect x="0" y="85.333" width="42.667" height="42.667" fill="#474747"/> <rect x="0" y="256" width="42.667" height="42.667" fill="#474747"/> <rect x="85.333" y="85.333" width="298.667" height="42.667" fill="#474747"/> <rect x="85.333" y="170.667" width="298.667" height="42.667" fill="#474747"/> <rect x="85.333" y="256" width="298.667" height="42.667" fill="#474747"/> </g> </g> </g></svg>',$content);


		$content = str_replace('{{icon_grid}}','<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="32px" height="18px" viewBox="0 0 433.5 433.5" style="enable-background:new 0 0 433.5 433.5;" xml:space="preserve"> <g> <g id="view-module"> <path d="M0,204h127.5V51H0V204z M0,382.5h127.5v-153H0V382.5z M153,382.5h127.5v-153H153V382.5z M306,382.5h127.5v-153H306V382.5z M153,204h127.5V51H153V204z M306,51v153h127.5V51H306z" fill="#363636"/> </g></svg>',$content);



		$fout.=$content;

		$fout.='</a>';

	    return $fout;
	}
	function shortcode_woo_filter_con($pargs = array(), $content=''){




		$margs = array(

			'extra_classes'=>' ',


		);



//		echo '$content filter_con - ';print_rr($content);


		if(is_array($pargs)){

			$margs = array_merge($margs, $pargs);
		}


		$fout = '';


		$fout.='<div class="woo-filter-con '.$margs['extra_classes'].'">';
		$fout.=do_shortcode($content);
		$fout.='</div><!-- end woo-filter-con-->';




		return $fout;


	}



	function shortcode_woo_sorter($pargs=array()){




		$fout = '';


		include "class_parts/sorter.php";
		return $fout;
	}



	function shortcode_woo_filter($pargs = array(), $content=''){

		$fout = '';


//		echo '$content - '.$content;
//		echo 'pargs -'; print_rr($pargs);


        include "class_parts/filters.php";
		return $fout;


	}
	function sanitize_from_get_to_margs(&$margs){

//	    echo 'margs - '; print_rr($margs);

	    $lab = 'orderby';
	    if(isset($_GET[$lab])){
	        $margs[$lab] = $_GET[$lab];
        }


//        print_rr($_GET);
        if(is_array($_GET) && count($_GET)){

	        foreach ($_GET as $lab=>$val){






	            // -- we do not need this for now


//	            if(strpos($val,'wtn-wtn')!==false){
//	                $margs['meta_value_metapa_'.$lab]=$val;
//
//
//		            unset($_GET[$lab]);
//
//		            if(isset($margs[$lab])){
//			            unset($margs[$lab]);
//		            }
//                }


                // -- let us remove this since we do not want to filter by attribute, but we need to sort by meta
	        }
        }

	}
	function shortcode_woo_table($pargs = array()){

	    global $post;
		$fout = '';


		$margs = array(
			'layout' => '',
			'layout_mode' => 'default',
			'post_type' => 'product',
			'posts_per_page' => '3',

			'page_url' => '',
			'feed_from' => '', // -- normal or wishlist


			'randomize' => 'off',
			'search' => 'default',

			'custom_attr_name' => '',
			'custom_meta_name' => '',
			'custom_meta_values' => '',
			'pagination_skin' => 'default',
			'per_row' => '', // -- just input 4,8,12 if you want per row selection



			'product_attributes' => 'default',


			'hard_meta_query' => '', // -- a json , meta query will overwite all
			'extra_classes' => '',
			'button_style' => 'default',
			'recalculate_attribute_data' => 'off', // -- recalculate attribute data to adjust filters , TODO: in the future, only consider cat and other hardmeta
			'show_filtered_by' => 'off', // -- get the preview 2 items
			'get_preview_data' => 'off', // -- get the preview 2 items
			'return_only_items' => 'off', // -- return only items "on" for ajax

		);

		// TODO: maybe place overwritable parameters that will be added in allcheck ( allcheck_cat ) then overwritten by $_GET then overwritten by margs

		// -- removed from default margs - cat,subcat,price,term_id,search,order,orderby,ids

        // -- if these will be set they will be hard set

		if(is_array($pargs)){

			$margs = array_merge($margs, $pargs);
        }





        $layout = $margs['layout'];




		$posts_per_page = $margs['posts_per_page'];



		if($post && $post->ID){
//		    print_rr($_COOKIE);

			if(isset($_COOKIE['dzswtl_layout_'.$post->ID])){
				$layout = $_COOKIE['dzswtl_layout_'.$post->ID];
			}
			if(isset($_GET['layout'])){
				$layout = $_GET['layout'];
			}

			if(isset($_COOKIE['dzswtl_posts_per_page_'.$post->ID])){
				$posts_per_page = $_COOKIE['dzswtl_posts_per_page_'.$post->ID];
			}
		}




//		echo 'layout - '.$layout;
//		echo '$pargs - '; print_rr($pargs);
//		echo 'margs - '; print_rr($margs);


		$layout_data = array();


		if(is_array($layout)){

			$layout_data = $layout;
		}else{


			$layout_post = get_page_by_path($layout,OBJECT,'dzswtl_list_layout');


//        $fout.=print_rr($queried_post, array('echo'=>false));


            if($layout_post){

	            parse_str($layout_post->post_content, $layout_data);
            }
		}




		$total_attribute_data = array();


		$temp_ranges_arr = array();

		$paged = 1;




		$product_attributes = array();
		$tax_query = array();
		$arr_filter_by = array();
		$meta_query = array();


		$ids = null;


//		echo '$_COOKIE - '; print_rr($_COOKIE);



		if(isset($_GET['table_paged'])){

			if(isset($margs['paged']) == false || $margs['paged']=='default'){
				$margs['paged']=$_GET['table_paged'];
			}
		}

		if(isset($_GET['price'])){

			if(isset($margs['price']) == false || $margs['price']==''){
				$margs['price']=$_GET['price'];
			}
		}

		if(isset($_GET['order'])){

			if($margs['order']=='default'){
				$margs['order']=$_GET['order'];
			}
		}

		if(isset($_GET['order'])){

			if($margs['order']=='default'){
				$margs['order']=$_GET['order'];
			}
		}
		if(isset($_GET['search'])){

			if($margs['search']=='default'){
				$margs['search']=$_GET['search'];
			}
		}

//        echo 'margs - '; print_rr($margs);

		if($margs['hard_meta_query']){
			$margs['hard_meta_query'] = str_replace('{{braceopen}}','[',$margs['hard_meta_query']);
			$margs['hard_meta_query'] = str_replace('{{braceclose}}',']',$margs['hard_meta_query']);
			$margs['hard_meta_query'] = str_replace('{{escape}}','\\',$margs['hard_meta_query']);
			$arr = json_decode($margs['hard_meta_query'],true);

//            print_rr($meta_query);

//            echo $margs['hard_meta_query'];
//            print_rr($arr);
			foreach ($arr as $arrc){
				array_push($meta_query, $arrc);
			}

		}



		if(isset($_GET) && is_array($_GET)){
			foreach ($_GET as $lab=>$val){
				if(strpos($lab,'meta_value_')){
					$margs[$lab]=$_GET[$lab];
				}
			}
		}



//        echo 'cat - '.$margs['cat'].'<br>';




//        print_r($_GET);
//        echo 'margs -4 '; print_rr($margs);


		$all_checks = $margs; // -- all checks for product attributes
		if(isset($_GET)){

		    // -- margs are shortcode attributes .. hard set
			$all_checks = array_merge($_GET, $margs);


			$this->sanitize_from_get_to_margs($margs);
		}


		// -- margs default will overwrite $_GET so let s overwrite again ..
		$lab = 'cat';
		if(isset($_GET[$lab]) && $_GET[$lab]){

			if(isset($margs[$lab])==false || $margs[$lab]=='default' || $margs[$lab]=='' ){
				$margs[$lab]=str_replace('%25252C', ',', $_GET[$lab]);
				$margs[$lab]=str_replace('%252C', ',', $_GET[$lab]);
				$margs[$lab]=str_replace('%2C', ',', $_GET[$lab]);
			}
		}


		$lab = 'subcat';
		if(isset($_GET[$lab]) && $_GET[$lab]){
		    $all_checks[$lab] = $_GET[$lab];
		}



		// -- we have setup margs


		$lab_sanitized = '';



//		echo 'all_checks - '; print_rr($all_checks, array('background_color'=>'rgba(0,200,0,0.3)',    ));
		// -- all checks include pa
		foreach ($all_checks as $lab=>$val){


		    // -- destroy wrong vals
			if(strpos($lab,'meta_value_metapa_meta_value_metapa')===0){
				// -- obviously wrong


				$wrong_lab = $lab;
				$lab = str_replace('meta_value_metapa_meta_value_metapa','meta_value_metapa',$lab);

				$margs[$lab] = $val;
				$all_checks[$lab] = $val;

				unset($margs[$wrong_lab]);
				unset($all_checks[$wrong_lab]);

			}




			if(strpos($lab,'pa_')===0){

//                print_rr($margs);



                $lab_without_pa = str_replace('pa_','',$lab);

				if($margs['product_attributes']=='default'){


					// -- if values has wtn-wtn then clearly it has nothing to do in filtering, since we filter by interval

                    if(strpos($val,'wtn-wtn')===false){

	                    if(is_array($product_attributes) ){
		                    $product_attributes[$lab] = $val;
	                    }

	                    $aux_filtered_by = array(
		                    'lab_full'=>$lab,
		                    'label'=>$lab_without_pa,
		                    'value'=>$val,
	                    );
	                    $arr_filter_by[$lab] = $aux_filtered_by;
                    }


				}

//                print_rr($product_attributes);
			}


			// -- if we have get meta value it is okay ;)
			if(strpos($lab,'meta_value_')===0){

				$fulllab = $lab;
				$fullval = $all_checks[$fulllab];

			    if(strpos($lab,'dzswoomin')!==false){

			        // -- woomin

				    $lab = str_replace('dzswoomin','',$fulllab);
//				    $margs[$lab] = $all_checks[$fulllab];


//				    echo '$all_checks[$lab] -4 '.print_rr($fullval,true).'<br>';

				    if(isset($temp_ranges_arr[$lab]) && isset($temp_ranges_arr[$lab]['max'])){

				        $margs[$lab] = $fullval.'wtn-wtn'.$temp_ranges_arr[$lab]['max'];
                    }else{
					    $temp_ranges_arr[$lab] = array(
					            'min'=>$fullval,
					            'max'=>'',
                        );


					    $margs[$lab] = $fullval.'wtn-wtninfinite';
                    }

                    unset($all_checks[$fulllab]);




                }elseif(strpos($lab,'dzswoomax')!==false){

				    // -- woomax


					    $lab = str_replace('dzswoomax','',$lab);
//					    $margs[$lab] = $all_checks[$lab];

					    if(isset($temp_ranges_arr[$lab]) && isset($temp_ranges_arr[$lab]['max'])){

						    $margs[$lab] = $temp_ranges_arr[$lab]['min'].'wtn-wtn'.$all_checks[$fulllab];
					    }else{
						    $temp_ranges_arr[$lab] = array(
							    'max'=>$fullval,
							    'min'=>'',
						    );
						    $margs[$lab] = '0'.'wtn-wtn'.$fullval;
					    }

				    unset($all_checks[$fulllab]);

                }else{

			        // -- final else

				    $margs[$lab] = $fullval;
			    }
//			    print_rr('$lab - ',$lab);
			}





			if($lab=='subcat'){
			    $margs[$lab]=$val;
			}
			if(strpos($lab,'customtax_')===0){


			    // -- if it is custom tax

//                echo 'yes it is';
				$lab_sanitized = str_replace('customtax_','',$lab);

				$term_taxonomy = $lab_sanitized;

				$term_slug = $val;
				$term_id = $term_slug;



				$term_slug=explode(',', $term_slug);


//		    echo '$lab - '; echo $lab; print_rr($val);

					foreach ( $term_slug as $lab2 => $val2 ) {

//				echo 'val - '; print_rr($val);
						$term = get_term_by( 'slug', $val2, $term_taxonomy );

						if ( $term && isset( $term->term_id ) ) {
							$term_id = $term->term_id;
						}
//				print_rr($term);
					}




				if($val&& is_array($tax_query) ){
					$aux = array(
						'taxonomy' => $lab_sanitized,
						'field' => 'id',
						'terms' => $term_id,
					);

					array_push($tax_query,$aux);
				}

				if($margs['show_filtered_by']=='on'){





//                    print_rr($term);



					if($val){

						$term = get_term($val, $lab_sanitized);

						if($term && isset($term->name)){

							$aux_filtered_by = array(
								'lab_full'=>$lab,
								'label'=>$term->name,
								'value'=>$val,
							);

							array_push($arr_filter_by,$aux_filtered_by);
                        }
					}

				}



				$margs[$lab] = $val;


//                echo 'lab - '.$lab.' val - '.$val;

			}
		}



//		echo 'all_checks - '; print_rr($all_checks);
//		echo 'margs after all checks - '; print_rr($margs);
//		echo '$temp_ranges_arr - '; print_rr($temp_ranges_arr);
//		echo '<br><br><br><br><br><br><br><br><br><br><br><br>';

		//attributes parse




//        echo 'cat - '.$margs['cat'];

//        echo 'margsi - '; print_rr($margs);


		if(isset($margs['paged']) == false || $margs['paged']=='default'){
			$margs['paged']='1';
		}
		if(isset($margs['orderby']) == false || $margs['orderby']=='default'){
			$margs['orderby']='';
		}
		if(isset($margs['order']) == false || $margs['order']=='default'){
			$margs['order']='';
		}
		if(isset($margs['search']) == false || $margs['search']=='default'){

			$margs['search']='';
		}



		if(isset($margs['cat'])){

        }
		if(isset($margs['cat']) == false || $margs['cat']=='default'){
			$margs['cat']='';
		}


		$margs['cat']=str_replace('%25252C', ',', $margs['cat']);
		$margs['cat']=str_replace('%252C', ',', $margs['cat']);
		$margs['cat']=str_replace('%2C', ',', $margs['cat']);


		foreach ($product_attributes as $lab => $val){

			$product_attributes[$lab]=str_replace('%25252C', ',', $product_attributes[$lab]);
			$product_attributes[$lab]=str_replace('%252C', ',', $product_attributes[$lab]);
			$product_attributes[$lab]=str_replace('%2C', ',', $product_attributes[$lab]);
		}


//        print_r($margs);
//        $fout.=print_rrr($margs);


		$skin = '';
		$pagination_skin = '';

		$is_zfolio = false;
		$is_scroller = false;

		if(isset($layout_data['bars']['mainsettings']['skin'])){
			$skin = $layout_data['bars']['mainsettings']['skin'];
		}


		if($margs['pagination_skin']=='default'){
		    $pagination_skin =' pagination-'.$skin;
        }else{
		    $pagination_skin = 'pagination-'.$margs['pagination_skin'];
        }

		$pagination_method = '';
		$layout_mode_grid_cols = '';

		if(isset($layout_data['bars']['mainsettings']['pagination_method'])){
			$pagination_method = $layout_data['bars']['mainsettings']['pagination_method'];
		}

		if(isset($layout_data['bars']['mainsettings']['layout_mode_grid_cols'])){
			$layout_mode_grid_cols = $layout_data['bars']['mainsettings']['layout_mode_grid_cols'];
		}



		if(isset($layout_data['bars']['mainsettings']['grid_mode'])){
			if($layout_data['bars']['mainsettings']['grid_mode']=='masonry' || $layout_data['bars']['mainsettings']['grid_mode']=='scroller'){
			    $is_zfolio = true;
            }

            if($layout_data['bars']['mainsettings']['grid_mode']=='scroller'){

	            $is_scroller = true;
            }

		}


		$exo_skeleton = '';

		foreach ($layout_data as $ld){

		}





		$wpqargs = array(
			'post_type' => $margs['post_type'],
			'posts_per_page' => $posts_per_page,
			'orderby' => 'date',
			'order' => 'DESC',
		);

		$cats = array();
		if (isset($margs['cat']) && $margs['cat']) {
//                $wpqargs['cat'] = $margs['cat'];

			$cats = explode(',', $margs['cat']);

//                foreach($cats_aux as $val){
//                    array_push($cats, $val);
//                }

		}


//		print_rr($cats);

		foreach ($cats as $lab=>$val){
		    $cats[$lab]=$this->sanitize_term_slug_to_id($val,'product_cat');
        }



//		echo '$product_attributes - '; print_rr($product_attributes);

		foreach ($product_attributes as $lab => $val){


			if($product_attributes[$lab]){




				$product_attributes[$lab]=explode(',', $product_attributes[$lab]);
			}else{

			    // -- does not do anything
				unset($product_attributes[$lab]);
			}
		}
//		echo '$product_attributes2 - '; print_rr($product_attributes);
		// -- let us try to turn to ids
		foreach ($product_attributes as $termlab => $val){
//		    echo '$lab - '; echo $lab; print_rr($val);

			foreach ($val as $lab2 => $val2){

//				echo 'val - '; print_rr($val);
				$term = get_term_by('slug',$val2,$termlab);

				if($term && isset($term->term_id)){
				    $product_attributes[$termlab][$lab2] = $term->term_id;
                }
//				print_rr($term);
			}



//		    print_rr($term);
		}


//        print_r($product_attributes);


		$this->args_curr_wootable = array_merge(array(), $margs);

		$cats = array_values($cats);

//                print_rr($cats);


		$wpqargs['paged']=$margs['paged'];

		if(isset($margs['ids']) && $margs['ids']){
			$wpqargs['post__in']= explode(',',$margs['ids']);
		}

		$taxonomy = 'product_cat';

//        $wpqargs['tax_query'] = array();

//        print_rr($margs);

        // -- here we already took data from $_GET
		if($margs['cat']) {




			if ($wpqargs['post_type'] == 'dzsvideo'){

				$taxonomy = 'dzsvideo_category';
			}



			if ($wpqargs['post_type'] == 'dzsap_items'){

				$taxonomy = 'dzsap_category';
			}




			if(isset($margs['subcat']) && $margs['subcat']) {
			    // -- subcat will overwrite cat



                $margs['subcat_slug'] = $margs['subcat'];
                $margs['subcat'] = $this->sanitize_term_slug_to_id($margs['subcat'],$taxonomy);

                $cats = array($margs['subcat']);


			}



			if(is_array($tax_query) ){
				$aux = array(
					'taxonomy' => $taxonomy,
					'field' => 'id',
					'terms' => $cats,
				);

				array_push($tax_query,$aux);
			}


		}



		if(count($product_attributes)>0){
//            print_rr($product_attributes);

			foreach ($product_attributes as $lab => $val){

				if(isset($wpqargs['tax_query'])){

				}else{

				}


				// -- taxonomy filtering..


                // -- if values has wtn-wtn then clearly it has nothing to do in filtering, since we filter by interval


				array_push($tax_query,array(
					array(
						'taxonomy' => $lab,
						'field' => 'id',
						'terms' => $val,
					)
				));
			}
		}


//		echo 'tax_query - '; print_rr($tax_query);

//        print_rr($wpqargs);


        if(is_array($tax_query)){

		    if($wpqargs['post_type']=='product'){

			    array_push($tax_query,
				    array(
					    'taxonomy' => 'product_visibility',
					    'field'    => 'name',
					    'terms'    => 'exclude-from-catalog',
					    'operator' => 'NOT IN',
				    )
                    );
            }
        }



		if(is_array($tax_query) && count($tax_query)){
			$wpqargs['tax_query'] = $tax_query;
		}




		if(isset($margs['rating']) && $margs['rating']) {


			if($margs['rating'] == '1') {
				array_push($meta_query,array(
					'key' => '_wc_average_rating',
					'value' => array( 0.1, 1.49 ),
					'type' => 'numeric',
					'compare' => 'BETWEEN'
				));
			}


			if($margs['rating'] == '2') {
				array_push($meta_query,array(
					'key' => '_wc_average_rating',
					'value' => array( 1.5, 2.49 ),
					'type' => 'numeric',
					'compare' => 'BETWEEN'
				));
			}


			if($margs['rating'] == '3') {
				array_push($meta_query,array(
					'key' => '_wc_average_rating',
					'value' => array( 2.5, 3.49 ),
					'type' => 'numeric',
					'compare' => 'BETWEEN'
				));
			}


			if($margs['rating'] == '4') {
				array_push($meta_query,array(
					'key' => '_wc_average_rating',
					'value' => array( 3.5, 4.49 ),
					'type' => 'numeric',
					'compare' => 'BETWEEN'
				));
			}


			if($margs['rating'] == '5') {
				array_push($meta_query,array(
					'key' => '_wc_average_rating',
					'value' => array( 4.5, 5 ),
					'type' => 'numeric',
					'compare' => 'BETWEEN'
				));
			}



		}
		if(isset($margs['price']) && $margs['price']) {

			$price_range = explode('wtn-wtn',$margs['price']);


			if(is_array($price_range)&&count($price_range)>1){

				array_push($meta_query,array(
					'key' => '_price',
					'value' => array( $price_range[0],$price_range[1] ),
					'type' => 'numeric',
					'compare' => 'BETWEEN'
				));
			}





		}

//        echo 'margs hier -3'; print_rr($margs);

		foreach ($margs as $lab=>$val){
			if(strpos($lab,'meta_value_')===0){
//                print_r($val);



				$meta_value_name = str_replace('meta_value_','',$lab);


				if(strpos($val, 'wtn-wtn')!==false){

				    // -- range


					$price_range = explode('wtn-wtn',$val);

//                    print_r($price_range);


                    error_log('meta key - '.$meta_value_name);

					if(is_array($price_range)&&count($price_range)>1){

					    // -- meta value between


                        if($price_range[0] || $price_range[1]){


                            if($price_range[0]===''){
                                $price_range[0] = '0';
                            }
                            if($price_range[1]=='' || $price_range[1]=='infinite'){
                                $price_range[1] = '100000000000';
                            }

	                        array_push($meta_query,array(
		                        'key' => $meta_value_name,
		                        'value' => array( $price_range[0],$price_range[1] ),
		                        'type' => 'numeric',
		                        'compare' => 'BETWEEN'
	                        ));
                        }
					}
				}else{





				    if(strpos($meta_value_name,'dzswoomin')!==false && strpos($meta_value_name,'dzswoomax')!==false){

					    $price_range = explode(',',$val);


					    if(isset($price_range[0]) && $price_range[0]==''){

					    }else{
						    array_push($meta_query,array(
								    'key' => $meta_value_name,
								    'value' => $price_range,
								    'compare' => 'IN'
							    )
						    )
						    ;
					    }
                    }


//                    array_push($meta_query,array(
//                        'key' => $meta_value_name,
//                        'value' => array( $price_range[0],$price_range[1] ),
//                        'type' => 'numeric',
//                        'compare' => 'BETWEEN'
//                    ));
				}
			}
		}


//		print_rr($_GET);
//		print_rr($margs);
		if($margs['orderby']){
			if($margs['orderby']=='price'){
				$wpqargs['orderby']='meta_value_num';
				$wpqargs['meta_key']='_price';
			}
			if(strpos($margs['orderby'],'pa')===0){
				$wpqargs['orderby']='meta_value_num';
				$wpqargs['meta_key']='metapa_'.$margs['orderby'];
			}
			if($margs['orderby']=='zoomsounds_plays'){
				$wpqargs['orderby']='meta_value_num';
				$wpqargs['meta_key']='_dzsap_views';
			}
			if($margs['orderby']=='zoomsounds_likes'){
				$wpqargs['orderby']='meta_value_num';
				$wpqargs['meta_key']='_dzsap_likes';
			}



			if($margs['orderby']=='ratings_score'){
				$wpqargs['orderby']='meta_value_num';

				$key = '_dzsap_rate_index';
				$wpqargs['meta_query']= array(
					'relation' => 'OR',
					array(
						'key'     => $key,
						'compare' => 'EXISTS',
					),
					array(
						'key'     => $key,
						'compare' => 'NOT EXISTS'
					)
				);
				$wpqargs['meta_type']='NUMERIC';
				$wpqargs['order']='DESC';

			}
		}

		if($margs['order']){
			$wpqargs['order'] = $margs['order'];
		}


		if($margs['search']){
			$wpqargs['s'] = $margs['search'];
		}

		if(isset($wpqargs['s']) && $wpqargs['s']){
			$margs['search'] = $wpqargs['s'];
		}





		if(class_exists('WC_Admin_Settings')){

			$setting_hide_out_of_stock = WC_Admin_Settings::get_option( 'woocommerce_hide_out_of_stock_items', 'off' );

			if($setting_hide_out_of_stock=='yes'){


			    if($wpqargs['post_type']=='product'){

				    $meta_query[] = array(
					    'key'       => '_stock_status',
					    'value'     => 'outofstock',
					    'compare'   => 'NOT IN'
				    );
                }

			}
		}

		if(is_array($meta_query) && count($meta_query)){
			$meta_query['relation']='AND';
			$wpqargs['meta_query'] = $meta_query;
		}


//        echo 'args - '; print_r($wpqargs);





		if($margs['get_preview_data']=='on'){





			$the_slug = 'preview-post-1';
			$the_slug2 = 'preview-post-2';
			$wpqargs = array(
//                'post_name'        => $the_slug,
'post_type'   => 'product',
'post_status'   => 'dzs_preview',
'post_name__in'  => array($the_slug,$the_slug2),
'numberposts' => 2,
			);

		}


		if($margs['get_preview_data']!='on') {
			$wpqargs['post_status'] = 'publish';
		}

//        print_rr($wpqargs);
//        error_log(print_rrr($wpqargs));





		if($margs['randomize']=='on'){
			$wpqargs['posts_per_page']='-1';
			$wpqargs['orderby']='rand';
		}



		$query = null;
		$pos = null;




		if($margs['search'] && isset($wpqargs['s']) && $wpqargs['s']){


		    // todo: why ?
			try{
//				add_filter( 'posts_search', array(&$this,'__search_by_title_only'), 500, 2 );
//                @add_filter( 'posts_search', 'wpse_11826_search_by_title', 10, 2 );
			}catch(Exception $e){

			}


		}


//		print_rr($wpqargs);




		if($margs['return_only_items']=='on'){


//		    if(function_exists('error_clear_last')){
//
//			    error_clear_last();
//            }
//		    error_log('wpqargs - '.print_r($wpqargs,true));
		}






		if(isset($margs['type']) && $margs['type']=='wishlist') {
//		    echo '$margs[\'ids\'] - '.$margs['ids'];

//		    $margs['ids'] = '337,124';


			$arr_wishlist = $this->get_wishlist();


//		    echo 'arr_wishlist - '; print_rr($arr_wishlist);


			$fout = '';



			$ids = '';

            if(is_array($arr_wishlist) && count($arr_wishlist)){

                foreach ( $arr_wishlist as $pl ) {

                    if($ids){
                        $ids.=',';
                    }

                    $ids.=$pl;


                }

                $margs['ids']=$ids;
            }else{
                return 'no items in wishlist';
            }


		}


//		echo 'margs - '; print_rr($margs);
		if(isset($margs['type']) && $margs['type']=='featured') {
//		    echo '$margs[\'ids\'] - '.$margs['ids'];



            if(function_exists('WC')){

	            $meta_query  = WC()->query->get_meta_query();
	            $tax_query   = WC()->query->get_tax_query();
	            $tax_query[] = array(
		            'taxonomy' => 'product_visibility',
		            'field'    => 'name',
		            'terms'    => 'featured',
		            'operator' => 'IN',
	            );

	            $args = array(
		            'post_type'           => 'product',
		            'post_status'         => 'publish',

		            'posts_per_page'      => '-1',
		            'orderby'             => $margs['orderby'],
		            'order'               => $margs['order'],
		            'meta_query'          => $meta_query,
		            'tax_query'           => $tax_query,
	            );
	            $loop = new WP_Query( $args );


	            $ids = '';
	            foreach ($loop->posts as $po){

		            if($ids){
			            $ids.=',';
		            }

		            $ids.=$po->ID;
                }
	            $margs['ids']=$ids;
            }


		}




		if(isset($margs['ids']) && $margs['ids']){


		    // -- we have ids , we later process
			$ids = explode(',',$margs['ids']);


		}else{

			$query = new WP_Query($wpqargs);
		}


//		echo '$query -> ';   print_rr($query);




//        echo ' $mixed - '; print_rr($mixed);
//        echo ' wp query - '; print_rr($query);


		// -- if it is big page
		if($query && $query->post_count==0 && intval($margs['paged']) > 1){
			$wpqargs['paged']='1';
			$margs['paged']='1';
			$query = new WP_Query($wpqargs);
		}





		if($margs['search'] && isset($wpqargs['s']) && $wpqargs['s']){


			try{

			    // -- todo: why ?
//				remove_filter( 'posts_search', array($this,'__search_by_title_only'), 500 );



			}catch(Exception $e){

			}
		}


		$max_num_pages = 1;
		if($query){

			$pos = $query->posts;

			$max_num_pages = $query->max_num_pages;
		}


		$called_from_load_new_content = false;

		if(isset($_GET['dzswtl_action']) && $_GET['dzswtl_action']=='load_new_content'){
			$called_from_load_new_content = true;
		}

		if($called_from_load_new_content==false && $this->debug_mode==true){

			print_rr($query);
		}


//        $fout.=print_rrr($pos);


		$layout_mode = 'list';
		if($margs['layout_mode']=='default'){

			if(isset($layout_data['bars']['mainsettings']['layout_mode']) && $layout_data['bars']['mainsettings']['layout_mode'] ){
				$margs['layout_mode']=$layout_data['bars']['mainsettings']['layout_mode'];
			}
		}



		if($margs['layout_mode']=='default'){
			$margs['layout_mode']='list';
		}
		$layout_mode = $margs['layout_mode'];









//        $fout.=print_rrr($layout_data);
		$fout.='<div class="dzs-woo-table layout-'.$layout_mode.' '.$skin.' '.$pagination_skin;



		if($layout_mode=='grid'){
			$fout.=' dzs-layout';
			$fout.=' '.$layout_mode_grid_cols;
		}

		$fout.=' '.$margs['extra_classes'];

		if($is_zfolio){
		    $fout.=' woo-table-is-zfolio';
        }

		$fout.='"';




		if(isset($layout_data['bars']['mainsettings']['theme']) && $layout_data['bars']['mainsettings']['theme']){
		    $fout.=' '.$layout_data['bars']['mainsettings']['theme'];
		}

		if($layout_mode=='grid'){


//		    print_rr($margs);
		    if(isset($layout_data['bars']['mainsettings']['layout_mode_grid_cols_gap']) && $layout_data['bars']['mainsettings']['layout_mode_grid_cols_gap']){

			    $fout.=' data-margin="'.$layout_data['bars']['mainsettings']['layout_mode_grid_cols_gap'].'"';
            }
		}




		if($post && $post->ID){
		    $fout.=' data-post-id="'.$post->ID.'"';
        }
		if($margs['randomize']=='on'){
			$fout.=' data-random-posts="';

			if($pos){
				if(is_array($pos)){
					$sw = false;
					$str_pos = '';
					foreach ($pos as $po){


						if($sw){
							$str_pos.=',';
						}

						$str_pos.=$po->ID;
						$sw=true;



					}



					if($str_pos){
						$fout.=$str_pos;



						$max_num_pages = 1;
						$ids = explode(',',$str_pos);
						if(count($ids)>intval($posts_per_page)){
							$max_num_pages = ceil(count($ids)/intval($posts_per_page));
						}


//                        echo 'count($ids) - '.count($ids);
//                        echo '$margs[\'posts_per_page\'] - '.$margs['posts_per_page'];



						if(count($ids)>intval($posts_per_page)){
							$ids = array_slice($ids, 0, intval($posts_per_page));

						}

					}
				}
			}

			$fout.='"';
		}

		$fout.=' data-pagination-method="'.$pagination_method.'"';
		$fout.=' data-max_num_pages="'.$max_num_pages.'"';
		$fout.=' data-curr_paged="'.$paged.'"';
		$fout.=' data-recalculate_attribute_data="'.$margs['recalculate_attribute_data'].'"';


		$fout.=' style="opacity:0; "';

		$fout.='>';




		if($margs['show_filtered_by']=='on'){

		    if($margs['return_only_items']!='on'){
//			    print_rr($arr_filter_by);

		    }




			$fout.='<div class="filtered-by-con ';


			if(count($arr_filter_by)==0){
				$fout.=' no-filters';
			}


			$fout.='">';
			$fout.='<span class="filtered-by-label">'.__("Filtering by");
			$fout.='</span>';

			foreach ($arr_filter_by as $filt){

				$fout.='<span class="filtered-by-filter" data-lab_full="'.$filt['lab_full'].'"><span class="the-label">'.$filt['label'].'</span>';

				$fout.='<span class="the-close delete-filter"  data-lab_full="'.$filt['lab_full'].'">'.'<i class="fa fa-window-close"></i>'.'</span>';
				$fout.='</span>';

			}


			$fout.='</div><!-- .filtered-by-con -->';






			$fontawesomelink = $this->base_url . 'libs/fontawesome/font-awesome.min.css';
			if(defined("DZSWTL_USE_FONTAWESOME_FROM_CDN") && DZSWTL_USE_FONTAWESOME_FROM_CDN=="ON"){
				$fontawesomelink = 'https://'.'maxcdn'.'bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css';
			}

			wp_enqueue_style( 'fontawesome', $fontawesomelink);



		}






		if($is_zfolio){

			$fout.='<div class=" zfolio skin-custom auto-init delay-effects '.$layout_mode_grid_cols.'';


			$fout.='" data-options=\'';




			$arr = array(

            );


			if($is_scroller){
			    $arr['settings_mode']='scroller';
            }

			$fout.= json_encode($arr);




			$fout.='\'>';




			wp_enqueue_style('dzszfl', $this->base_url . "libs/zfolio/zfolio.css");
			wp_enqueue_script('dzszfl', $this->base_url . "libs/zfolio/zfolio.js");

			if($is_scroller){

				wp_enqueue_style('dzscsc', $this->base_url . "libs/contentscroller/contentscroller.css");
				wp_enqueue_script('dzscsc', $this->base_url . "libs/contentscroller/contentscroller.js");
            }


		}



		$class_main_inner = 'dzs-woo-table--inner ';





		if($is_zfolio){

			$class_main_inner = 'dzswtl-ajax-container items';
		}

		$fout.='<div class="'.$class_main_inner.' ';

		if($layout_mode=='grid'){
//            $fout.=' items';
		}

		$fout.='">';



		if($is_zfolio){

//			$fout.='<div class="'.'items'.' "></div>';
		}


//        print_rr($layout_data);



		if($layout_mode!='grid') {

		    // -- list header

			$sw_has_any_title = false;



			if(isset($layout_data['bars']) && is_array($layout_data['bars'])){

				foreach ($layout_data['bars'] as $lab => $ld) {

					if ($lab === 'mainsettings') {
						continue;
					}


					if($ld['table_header_title']){
						$sw_has_any_title = true;
					}
				}
			}




			if($sw_has_any_title){

				$fout .= '<div class="wootable-row table--header ';


				$fout .= '">';



				$fout .= '<div class="table-item--inner ';


				$fout .= '">';


				foreach ($layout_data['bars'] as $lab => $ld) {
//				    print_rr($ld);

					if ($lab === 'mainsettings') {
						continue;
					}


					if($ld['type']=='container'){
						$ld['feed_from']='none';
					}



					$args_for_parent = array_merge($margs, array(
					        'call_from'=>'header_item',
                    ));

					$fout .= '<div class="' . $layout_mode . '-col " style="' . $this->generate_style($ld, $args_for_parent) . '">';


					$fout .= '<div class="table--header--item ">';


//                print_rr($ld);

					if ($ld['table_header_title']) {
						$fout .= '<span class="table-header--item-label">';
						$fout .= $ld['table_header_title'];
						$fout .= '</span>';


						if (isset($ld['show_sort_button']) && $ld['show_sort_button'] == 'on') {

							$fout .= '<span class="sort-controls';


							if ($margs['orderby'] == $ld['feed_from']) {
								$fout .= ' sorting-' . $margs['order'];
							}

							$sort_lab = $ld['feed_from'];


							if($sort_lab=='custom-attribute'){
//							    print_rr($ld);

								$ld['custom_attr_name'] = str_replace('pa_','',$ld['custom_attr_name']);
							    $sort_lab = 'meta_value_metapa_'.$ld['custom_attr_name'];
							    $sort_lab = 'pa_'.$ld['custom_attr_name'];
                            }


							$fout .= '">';
							$fout .= '<span class="sort-asc dzs-woo-table-sort-input" data-sort-lab="' . $sort_lab . '">';

							$fout .= '<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="12px" height="12px" viewBox="90.867 89.983 430.25 612.015"
	 enable-background="new 90.867 89.983 430.25 612.015" xml:space="preserve">
<path fill="#4D4E4A" d="M97.34,502.354c-8.628-8.628-8.628-22.211,0-30.839c8.336-8.336,22.211-8.336,30.527,0L284.24,627.888
	l0-516.005c0-12.029,9.561-21.9,21.589-21.9s21.9,9.871,21.9,21.9v516.005l156.08-156.372c8.628-8.336,22.521-8.336,30.839,0
	c8.628,8.628,8.628,22.211,0,30.839L321.258,695.745c-8.336,8.336-22.21,8.336-30.528,0L97.34,502.354z"/>
</svg>';

							$fout .= '</span>';
							$fout .= '<span class="sort-desc dzs-woo-table-sort-input" data-sort-lab="' . $sort_lab . '">';

							$fout .= '<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="12px" height="12px" viewBox="90.867 89.983 430.25 612.015"
	 enable-background="new 90.867 89.983 430.25 612.015" xml:space="preserve">
<path fill="#4D4E4A" d="M514.646,289.625c8.628,8.628,8.628,22.211,0,30.839c-8.336,8.336-22.211,8.336-30.527,0L327.747,164.093
	v516.005c0,12.029-9.561,21.9-21.589,21.9c-12.028,0-21.9-9.871-21.9-21.9V164.093l-156.08,156.372
	c-8.628,8.336-22.521,8.336-30.839,0c-8.628-8.628-8.628-22.211,0-30.839l193.391-193.39c8.336-8.336,22.21-8.336,30.528,0
	L514.646,289.625z"/>
</svg>';

							$fout .= '</span>';
							$fout .= '</span>';


						}

					}

					$fout .= '</div>';
					$fout .= '</div>';


				}


				$fout .= '</div>';
				$fout .= '</div>';
			}

		}




//        $fout.='<div class="table--content ">';

		$iout = '';







//        $fout.=print_rrr($layout_data);


//            $fout.='$ld -5 <pre>'.print_rrr($ld).'</pre>';


		$ind_nr = 1;

		if(intval($margs['paged'])>1){

			$ind_nr = ( intval($margs['paged']) - 1 ) * intval($posts_per_page) + 1;
		}



		if($is_zfolio){

        }else{

			$fout.='<div class="dzswtl-ajax-container dzs-woo-table--inner-rows ';


			if($layout_mode=='grid'){
				$fout.=' items';
			}




			$fout.='">';
        }

		if(is_array($ids) && count($ids)){
			$wpqargs = array(
				'post_type' => 'any',
				'post__in'      => $ids,
				'paged'      => $margs['paged'],
				'orderby'      => 'post__in',
				'posts_per_page'      => $posts_per_page,
			);


//            error_log(print_rr($wpqargs,array('echo'=>false)));

			$query = new WP_Query( $wpqargs );
			$pos = $query->posts;
		}



		foreach ($pos as $po){

		    // -- start item



//            $fout.=print_rrr($po);


			$old_price = '';
			$price = get_post_meta( $po->ID, '_regular_price', true);
			$sale = get_post_meta( $po->ID, '_sale_price', true);




			$price_html = '';


			if(get_post_meta( $po->ID, '_price', true)){
				$price = get_post_meta( $po->ID, '_price', true);
				$old_price = get_post_meta( $po->ID, '_regular_price', true);
			}

			$product = null;
			if(function_exists('wc_get_product')){

				$product = wc_get_product( $po->ID );

				if($product){

					$price_html =  $product->get_price_html();
//					$price_html =  wc_price($product->get_price(), array(
//						'ex_tax_label'       => false,
//						'currency'           => '',
//						'decimal_separator'  => wc_get_price_decimal_separator(),
//						'thousand_separator' => wc_get_price_thousand_separator(),
//						'decimals'           => wc_get_price_decimals(),
//						'price_format'       => get_woocommerce_price_format(),
//					));



                    if($margs['recalculate_attribute_data']=='on'){
//                        echo 'ceva';

//                        print_rr($product);
//                        print_rr($product->get_attributes());

//	                    echo '<hr> new product '.$po->post_title.'<br><br>';
                        foreach ($product->get_attributes() as $atlab => $atval){
//                            echo ' '.$atlab.' - '; print_rr($atval); print_rr($atval->get_options());

                            foreach ($atval->get_options() as $oplab => $opval){

//	                            print_rr($opval, array( 'background_color'=>'rgba(200,50,50,0.3)' ));
//                                print_rr($total_attribute_data);
                                if(isset($total_attribute_data[$opval])){
	                                $total_attribute_data[$opval]++;
                                }else{
	                                $total_attribute_data[$opval] = 1;
                                }
//	                            print_rr($total_attribute_data, array( 'background_color'=>'rgba(0,200,50,0.3)' ));
                            }
                        }
                    }

                }
			}


			// -- content


            // -- inside pos
//            print_rr($layout_data['bars']);
			$iout.='<div class="wootable-row ';

			if($is_zfolio){
			    $iout.=' zfolio-item';
            }


			if($layout_mode=='grid'){
				$iout.=' dzs-layout-item';
			}

			if(isset($layout_data['bars']['mainsettings']['item_align']) && $layout_data['bars']['mainsettings']['item_align']){
				$iout.=' align-'.$layout_data['bars']['mainsettings']['item_align'];
			}

            $availability = null;



			if($product){

				$availability = $product->get_availability();
            }

//			print_rr($availability);
			if ( $availability && isset($availability['availability']) && $availability['availability'] == 'Out of stock') {
				$iout.=' out-of-stock';
			}

			$iout.='"';

			$iout.=' data-post-id="'.$po->ID.'"';
			$iout.=' style="';


//			print_rr($layout_data['bars']['mainsettings']);
			if(isset($layout_data['bars']['mainsettings']['item_text_align']) && $layout_data['bars']['mainsettings']['item_text_align']){
				$iout.=' text-align: '.$layout_data['bars']['mainsettings']['item_text_align'];
			}

			$iout.='"';

			$iout.='>';



			$iout .= '<div class="table-item--inner ';


			$iout .= '">';





//            $iout.=print_rrr($margs);
//            $iout.=print_rrr($layout_data);
			if(isset($layout_data['bars']) && is_array($layout_data['bars'])){

				$args = array_merge(array(), $margs);

				$args['ind_nr']=$ind_nr;
				$args['layout_mode']=$layout_mode;
				$args['price_html']='';
				$args['sale']=$sale;

				if($price_html){
					$args['price_html']=$price_html;
				}

				if(function_exists('get_woocommerce_currency_symbol')){

					$currency = get_woocommerce_currency_symbol();
                }

				$args['product'] = null;
				$args['taxonomy'] = $taxonomy;
				$args['price'] = $price;
				$args['old_price'] = $old_price;
				$args['currency'] = $currency;
				if($product){
					$args['product']=$product;
				}

//                $iout.='ceva';
				$this->generate_layer_item($layout_data['bars'],$args, $po, $iout);

			}




			$iout.='</div>';
			$iout.='</div><!-- end wootable-row -->';


			$ind_nr++;
		}




		$fout.=$iout;

		if($is_zfolio) {
		}else{

			$fout .= '</div><!-- end. dzs-woo-table--inner-rows -->';
        }


		if($is_zfolio){

//			$fout.='</div><!-- end items zfolio-->';
		}
		$fout.='</div><!-- end main ajax container-->';


		if($margs['return_only_items']=='on'){


		    foreach ($margs as $lab=>$val){



		        // -- filter returned history pushState vars
		        if($val=='wtn-wtn' || strpos($lab,'dzswoomin')!==false || strpos($lab,'dzswoomax')!==false){
		            unset($margs[$lab]);
                }
            }

			$output = array(
				'paged'=>$margs['paged'],
				'max_pages'=>$max_num_pages,
				'margs'=>json_encode($margs),
				'max_num_pages'=>$max_num_pages,
				'output'=>$iout,
			);


			if(isset($margs['ids']) && $margs['ids']){
//                unset($output['max_num_pages']);
//                unset($output['max_pages']);
			}


			if($margs['show_filtered_by']=='on'){
				$output['filtered_by']=$arr_filter_by;
			}


			if($margs['recalculate_attribute_data']){

			    $output['total_attribute_data']=($total_attribute_data);
			}




			return json_encode($output);
		}









//        $fout.='</div>';





        



		if($pagination_method=='scroll'){
			$fout.='<div class="wheel-loader">
                                    <div class="wheel-loader--wrap">
                                        <div class="bar1"></div>
                                        <div class="bar2"></div>
                                        <div class="bar3"></div>
                                        <div class="bar4"></div>
                                        <div class="bar5"></div>
                                        <div class="bar6"></div>
                                        <div class="bar7"></div>
                                        <div class="bar8"></div>
                                        <div class="bar7"></div>
                                        <div class="bar8"></div>
                                        <div class="bar9"></div>
                                        <div class="bar10"></div>
                                    </div>
                                </div>';
		}


		$fout.='<div class="clear clearboth"></div>';
		$fout.='<div class="pagination-and-per-row-con">';


		if($pagination_method=='' || $pagination_method=='pages'){

			$fout.=dzs_pagination($max_num_pages, 3,array(

				'container_class' => 'dzs-pagination woo-table-pagination',
				'include_raquo' => true,
				'extraattr' => ' data-max_num_pages="'.$max_num_pages.'"',
				'style' => 'div',
				'paged' => $margs['paged'],
				'link_style' => 'table_paged',
				'make_main_div_regardles_of_nr_pages' => 'on',
				'a_class'=>'dzs-woo-ajax pagination-link',
			));
		}

		if($margs['per_row']){
		    $fout.='<div class="per-row dzs-pagination dzs-pagination--per-row">';

		    $per_rows = explode(',',$margs['per_row']);

//		    print_rr($per_rows);

//            echo '$posts_per_page - '.$posts_per_page;

		    foreach ($per_rows as $lab=>$per_rowi){

		        $link = add_query_arg(array(
		                'posts_per_page'=>$per_rowi,
		                'cookie_set_posts_per_page'=>'on',
                ),dzs_curr_url());

			    $fout.='<a href="'.$link.'" data-per-row="'.$per_rowi.'" class="dzs-woo-ajax pagination-link pagination-link--per-row ';


			    if($posts_per_page==$per_rowi){
				    $fout.=' current';
			    }

			    $fout.='"><span class="the-pagination-number--inner">'.$per_rowi.'</span></a>';
            }


		    $fout.='</div>';
        }

		$fout.='</div><!--end .pagination-and-per-row-con-->';


		$fout.='</div><!--end .dzs-woo-table-->';

		if($margs['recalculate_attribute_data']){


		    $fout.='<i class="feed-dzswtl feed-dzswtl-total-attribute-data" data-attdata=\''.json_encode($total_attribute_data).'\'></i>';
        }



		wp_enqueue_style('dzswtl', $this->base_url . "libs/dzswootable/dzswootable.css");
		wp_enqueue_script('dzswtl', $this->base_url . "libs/dzswootable/dzswootable.js");


		return $fout;
	}




	function is_plugin_active( $plugin ) {

//        print_r(get_option( 'active_plugins', array() ));



		return in_array( $plugin, (array) get_option( 'active_plugins', array() ) ) || is_plugin_active_for_network( $plugin );
	}

	function get_product_images($pid,$w = 300){

		global $product;



		$arr = array();


		$product = null;
		if(function_exists('wc_get_product')) {

			$product = wc_get_product( $pid );

			if ( $product ) {



				$attachment_ids = $product->get_gallery_image_ids();

				foreach( $attachment_ids as $attachment_id ) {




				    $im_sizes = array(
					    $w,0
                    );

//				    echo '$im_sizes - '; print_rr($im_sizes);

					$img_arr = wp_get_attachment_image_src( $attachment_id, $im_sizes );


					$img_src = '';

					if(isset($img_arr[0])){

						$img_src = $img_arr[0];
					}

					$aux = array(
						'id'=>$attachment_id,
						'url'=>$img_src,
					);





					array_push($arr,$aux);
				}
			}
		}


//		echo 'arr - '; print_rr($arr);
		if(count($arr)==0){
			$arr = array(array(
				'id'=>'0',
				'url'=>$this->get_thumbnail_src(get_post($pid)),
			)
            );
		}

		return $arr;
	}


	function get_thumbnail_src($po,$im_size='full'){



	    $image = '';


//				    echo '$im_size - '; print_rr($im_size);

		$image = wp_get_attachment_image_src( get_post_thumbnail_id( $po->ID ), $im_size,false );





		if(isset($image[0])){
            $image = $image[0];
        }


        if($image==''){
		    if($po->post_type=='dzsap_items'){
		        $image = get_post_meta($po->ID,'dzsap_meta_item_thumb',true);
            }
        }

		return $image ;
	}
	function generate_layer_item($bars, $margs, $po, &$iout){




	    // -- generate front end layer item





		foreach ($bars as $lab => $ld){

		    if(is_array($ld)){

			    $ld = array_merge($this->generate_layout_item_default_margs, $ld);
            }else{
		        $ld = array_merge(array(),$this->generate_layout_item_default_margs);
            }

			$ld['added_extra_html'] = '';


			if($lab==='mainsettings' || is_numeric($lab)==false){
				continue;
			}





			$attr_data_str = '';


			if($ld['type']=='container'){
				$ld['feed_from']='none';




				// data-postid="'.$po->ID.'"

				$iout.='<div class="table--content--item dzs-woo-table-container ' . $margs['layout_mode'] . '-col';



				if(isset($ld['extra_classes'])){

					$iout.=' '.$ld['extra_classes'].' ';
				}

				$iout.='"  style="'.$this->generate_style($ld).'" >';


				$this->generate_layer_item($ld,$margs,$po,$iout);

				$iout.='</div>';

				continue;

			}



			$inside_anchor = false;


			$table_content_item_tag = 'div';
			$table_content_item_tag_extraattr = '';




//			print_rr($ld);

			if(isset($ld['link_to']) && $ld['link_to']=='item'){

//			    echo 'cevaa';

                $link =get_permalink( $po->ID );

                if(get_post_meta($po->ID,'dzswtl_replace_item_link',true)){
                    $link = get_post_meta($po->ID,'dzswtl_replace_item_link',true);
                }
				if($ld['feed_from']!='title3') {

//				    echo 'nana batman';
					$table_content_item_tag           = 'a';
					$table_content_item_tag_extraattr = ' href="' . $link . '"';
				}

				$inside_anchor=  true;
            }





			if($ld['feed_from']=='custom-attribute') {
//                        $iout.=print_rrr(get_post_meta_all($po->ID));


//				print_rr($ld);
//                        $tax_name = 'pa_color';
				$tax_name = $ld['custom_attr_name'];

//				print_rr($ld);
//				echo '$tax_name - '.$tax_name.'|';
				$data = ( get_post_meta( $po->ID, '_product_attributes', true ) );
//                        $data = (get_post_meta($po->ID, '_default_attributes',true));


//                        $iout.=get_post_meta($po->ID, '_product_attributes',true);


//                        $data.=print_rrr(get_post_meta($po->ID, '_product_attributes',true));
				if ( is_array( $data ) ) {


//                            $iout.='ceva';

//                    print_rr($data);
//                            $iout.= print_rrr($data);
				}


//                        $iout.=' terms - ';
//                        $iout.=print_rrr(wc_get_product_terms($po->ID,'pa_bpm'));


				if ( $tax_name == 'product_cat' || $tax_name == 'product_tag' || $tax_name == 'product_attributes' ) {

					$final_taxonomy_name = '' . $tax_name;
				} else {

					$final_taxonomy_name = 'pa_' . $tax_name;
				}
				$terms = wc_get_product_terms( $po->ID, $final_taxonomy_name );


//				print_rr($terms);

				// -- custom attribute

				foreach ( $terms as $te ) {


//                            $iout.=print_rrr($te);


					// -- put ,
					if ( isset( $ld['attr_style'] ) && ( $ld['attr_style'] == 'cosco' ) ) {

					} else {

						if ( $attr_data_str ) {

							$attr_data_str .= ', ';
						} else {
							$attr_data_str = '';
						}
					}


					$tag  = 'span';
					$link = '#';

					if ( isset( $ld['attr_link_to'] ) && ( $ld['attr_link_to'] == 'filter' ) ) {

						if ( $inside_anchor == false ) {

							$tag = 'a';
						}
					}

					if ( isset( $ld['attr_link_to'] ) && ( $ld['attr_link_to'] == 'filter' ) ) {


						$link_taxonomy_name = $final_taxonomy_name;


						// -- we need customtax_
						if ( strpos( 'pa_', $link_taxonomy_name ) === 0 ) {

						} else {
							$link_taxonomy_name = 'customtax_' . $link_taxonomy_name;
						}


						$link = add_query_arg( array(
							$link_taxonomy_name => $te->slug
						), dzs_curr_url() );
					}
					$attr_data_str .= '<' . $tag;

//					print_rr($te);


					$attr_data_str .= ' href="' . $link . '"';
					$attr_data_str .= ' class="custom-attr-label';
					if ( isset( $ld['attr_link_to'] ) && ( $ld['attr_link_to'] == 'filter' ) ) {
						$attr_data_str .= ' dzs-woo-ajax';
					}

					if ( isset( $ld['attr_style'] ) ) {
						$attr_data_str .= ' style-' . $ld['attr_style'];
					}
					$attr_data_str .= '"';


					$attr_data_str .= '>';
					if ( isset( $te->name ) ) {

						$attr_data_str .= $te->name;
					} else {

						$attr_data_str .= $te;
					}
					$attr_data_str .= '</' . $tag . '>';


				}
			}











			$iout.='<'.$table_content_item_tag.' '.$table_content_item_tag_extraattr.' class="table--content--item ' . $margs['layout_mode'] . '-col col-feed-from-'.$ld['feed_from'];


			if($ld['feed_from']=='price'){
				$iout.=' feed-from-price-style-'.$ld['feed_from_price_style'];
			}


			if($ld['feed_from']=='zoomsounds-player'){
			    $iout.=' zoomsounds-mode-'.$ld['zoomsounds_mode'];
            }

			if($margs['layout_mode']=='grid'){

			    // -- todo: why on table--content--item ?
//				$iout.=' dzs-layout-item';
			}

			if(isset($ld['feed_from']) && $ld['feed_from']=='custom-attribute'){
			    if($attr_data_str==''){
			        $iout.=' feed-is-empty';
                }
			}

			if(isset($ld['extra_classes'])){

				$iout.=' '.$ld['extra_classes'].' ';
            }

            $iout.='"';



			if(isset($ld['custom_attr_name']) && $ld['custom_attr_name']){
				$ld['custom_attr_name'] = str_replace('pa_','',$ld['custom_attr_name']);
            }
			if(isset($ld['feed_from']) && $ld['feed_from']=='custom-attribute'){
				$iout.=' data-custom_attr_name="'.$ld['custom_attr_name'].'"';
            }






			$iout.=' style="'.$this->generate_style($ld).'" data-header="'.$ld['table_header_title'].'';




			$iout.='">';

			// -- start it



            if(isset($ld['extra_html_before']) && $ld['extra_html_before']){

	            $extra_html_before = $ld['extra_html_before'];

	            $extra_html_before =$this->generate_extra_html($extra_html_before,null, $po);

	            $iout.=$extra_html_before;
            }


			$product = null;

			if($margs['product']){
				$product = $margs['product'];
			}




			$link = '';
			$link_class = '';


			if(isset($ld['link_to']) && $ld['link_to']){


			}else{


				if(isset($ld['feed_from']) && $ld['feed_from']=='title'){

					$ld['link_to']='item';

				}
			}

//			print_rr($ld);

			if(isset($ld['link_to']) && $ld['link_to']=='item'){


				if($inside_anchor==false) {
					$link = get_permalink( $po->ID );
				}
            }
			if(isset($ld['link_to']) && $ld['link_to']=='none'){
			    $link = '';
            }

//            print_rr($ld);

			if($ld['feed_from']=='title'){

			    $args = array_merge(array(), $ld);

			    foreach ($args as $lab => $val){
			        if($lab!=='color' && $lab!=='font_weight'){

			            unset($args[$lab]);
                    }
                }

                $tag = 'span';

			    if($link){
			        $tag = 'a';
                }


                $title = $po->post_title;

			    if(isset($ld['desc_count']) && $ld['desc_count']){



					    $maxlen = $ld['desc_count'];

				    $title=dzs_get_excerpt(-1,array(
						    'maxlen' => $maxlen
						    , 'content' => $title
						    , 'striptags' => true
						    , 'stripshortcodes' => true
						    , 'forceexcerpt' => false //if set to true will ignore the manual post excerpt
						    , 'try_to_close_unclosed_tags' => false // -- this will try to close unclosed tags
						    , 'readmore' => 'auto'
						    , 'readmore_markup' => ' ...'
						    , 'call_from' => 'default'
					    )
				    );
                }

//                echo 'args - '; print_rr($args);

				$iout.='<'.$tag.' class="title-feed-a '.$link_class.'" href="'.$link.'" style="'.$this->generate_style($args).'">';
				$iout.=$title;
				$iout.='</'.$tag.'>';
			}




			if($ld['feed_from']=='author-name'){

				$url = dzs_curr_url();

				$url = DZSHelpers::add_query_arg($url,'author',$po->post_author);
//                        $iout.=print_rr($po);
				$author = get_user_by('id',$po->post_author);

//                        $iout.=print_rr($author);
//                        print_r($author);

				$iout.='<a class="author-name" href="'.$url.'">';
				$iout.=$author->data->user_nicename;
				$iout.='</a>';
			}
			if($ld['feed_from']=='id'){
				$iout.=$po->ID;
			}
			if($ld['feed_from']=='number'){
				$iout.=$margs['ind_nr'];
			}
			if($ld['feed_from']=='price'){


			    $price_real_number = $margs['price'];

			    $old_price = '';




			    $price_before_decimal = $price_real_number;
			    $price_after_decimal = '';
				if(strpos($price_real_number,'.')===false){
				    if(isset($ld['feed_from_price_style']) && $ld['feed_from_price_style']=='cosmo'){
				        $price_real_number.='.00';
                    }
				}

			    if(strpos($price_real_number,'.')!==false){
			        $arr = explode('.',$price_real_number);

			        $price_before_decimal = $arr[0];
			        $price_after_decimal = $arr[1];


                }




				if(isset($ld['feed_from_price_style']) && $ld['feed_from_price_style']=='default'  || $ld['feed_from_price_style']==''){
					if($margs['price_html']){
						$iout.=$margs['price_html'];
					}
					if($margs['sale']){

					}
				}
				if(isset($ld['feed_from_price_style']) && $ld['feed_from_price_style']=='show-only-true'){

//                    print_rr($ld);

					if($price_real_number){

						$iout.='<span class="price-show-only-true">';
						$iout.='<span class="price-show-only-true--currency">';
						$iout.=$margs['currency'];
						$iout.='</span>';
						$iout.='';
						$iout.='<span class="price-show-only-true--price">';

						$iout.=$price_real_number;
						$iout.='</span>';
						$iout.='</span>';
					}else{

						if($margs['price_html']){
							$iout.=$margs['price_html'];
						}
					}
				}
				if(isset($ld['feed_from_price_style']) && $ld['feed_from_price_style']=='cosmo'){

					$iout.='<span class="price-show-only-true">';
					$iout.='<span class="price-show-only-true--currency">';
					$iout.=$margs['currency'];
					$iout.='</span>';
					$iout.='';
					$iout.='<span class="price-show-only-true--price">';

					$iout.='<span class="price-before-decimal">';
					$iout.=$price_before_decimal;
					$iout.='</span>';

					if($price_after_decimal){

						$iout.='<span class="price-after-decimal">';
						$iout.='.'.$price_after_decimal;
						$iout.='</span>';
                    }

                    if($margs['old_price'] && $margs['old_price']!=$margs['price']){



	                    $old_price_real_number = $margs['old_price'];

	                    $old_price_before_decimal = $old_price_real_number;
	                    $old_price_after_decimal = '';
	                    if(strpos($old_price_real_number,'.')===false){
		                    if($ld['feed_from_price_style']=='cosmo'){
			                    $old_price_real_number.='.00';
		                    }
	                    }

	                    if(strpos($old_price_real_number,'.')!==false){
		                    $arr = explode('.',$old_price_real_number);

		                    $old_price_before_decimal = $arr[0];
		                    $old_price_after_decimal = $arr[1];


	                    }



	                    $iout.='<span class="old-price-show-only-true--price">';
	                    $iout.='<span class="old-price-before-decimal">';
	                    $iout.=$old_price_before_decimal;
	                    $iout.='</span>';

	                    if($old_price_after_decimal){

		                    $iout.='<span class="old-price-after-decimal">';
		                    $iout.='.'.$old_price_after_decimal;
		                    $iout.='</span>';
	                    }

	                    $iout.='</span>';
                    }


					$iout.='</span>';
					$iout.='</span>';
				}


			}
			if($ld['feed_from']=='sale-percent'){


				if($margs['old_price'] && $margs['sale']){

					$margs['old_price']=floatval($margs['old_price']);
					$margs['sale']=floatval($margs['sale']);

					$perc_discount = ( 1 - $margs['sale'] / $margs['old_price'] ) * 100;

					$perc_discount = intval($perc_discount);


					$args = array_merge(array(), $margs);
					unset($args['product']);
//                    print_rr($args);

//                    echo 'perc_discount - '.$perc_discount;




					$iout.='<div class="perc-discount-bubble">';
					$iout.='<div class="perc-discount-number">-'.$perc_discount.'%';
					$iout.='</div>';
					$iout.='</div>';
				}


			}
			if($ld['feed_from']=='stock') {

				if ($product && $product->get_stock_quantity()) { // if manage stock is enabled
					if (number_format($product->get_stock_quantity(), 0, '', '') < 3) { // if stock is low
						$iout.= '<div class="remaining">Only ' . number_format($product->get_stock_quantity(), 0, '', '') . ' left in stock!</div>';
					} else {
						$iout.= '<div class="remaining">' . number_format($product->get_stock_quantity(), 0, '', '') . ' left in stock</div>';
					}
				}
			}
			if($ld['feed_from']=='custom-attribute'){
//                        $iout.=print_rrr(get_post_meta_all($po->ID));



//                        $iout.=print_rrr($tax);

				$iout.=$attr_data_str;






			}










			if($ld['feed_from']=='custom-meta'){


				$iout.='<div class="the-custom-meta">';
			    // -- custom meta

				$custom_meta_name = $ld['custom_meta_name'];
				$meta = get_post_meta($po->ID,$custom_meta_name,true);




				if($custom_meta_name=='artistname'){
				    // -- we also accept author name

//                    echo 'lets see artistname'; print_rr($po);



                    if(get_post_meta($po->ID,$custom_meta_name,true)){
                        $meta =get_post_meta($po->ID,$custom_meta_name,true);
                    }

                    if(get_post_meta($po->ID,'dzsap_meta_replace_'.$custom_meta_name,true)){
                        $meta =get_post_meta($po->ID,'dzsap_meta_replace_'.$custom_meta_name,true);
                    }

                    if(!($meta)){

	                    $recent_author = get_user_by( 'ID', $po->post_author );

//	                    print_rr($recent_author);

                        if(isset($recent_author->display_name)){

	                        $meta = $recent_author->display_name;
                        }
                    }
				}












				if($custom_meta_name=='zoomsounds_length'){

//                    $iout.='ceva';
					$iout.= $this->format_to_time($meta);


				}else{
				}


				if($meta){
					$iout.=$meta;

				}



				$iout.='</div>';





			}

			if($ld['feed_from']=='categories'){

				// -- this is inside layer item
				$term_list = wp_get_post_terms($po->ID, $margs['taxonomy'], array("fields" => "all"));


//                    $iout.=print_rrr($term_list);

				$ind = 0;
				foreach ($term_list as $tli){






					if($ind){
						$iout.=', ';
					}


					$tag = 'span';








					if($attr_data_str){

						$attr_data_str .=', ';
					}else{

						$attr_data_str = '';
					}


					$tag = 'span';
					$link = '#';


//					echo 'ld - '; print_rr($ld);
					if(isset($ld['attr_link_to']) && ($ld['attr_link_to']=='filter')){


						if($inside_anchor==false) {
							$tag = 'a';
						}
					}

					if(isset($ld['attr_link_to']) && ($ld['attr_link_to']=='filter')){



						$link = get_term_link($tli->term_id,$margs['taxonomy']);
					}
					$attr_data_str.='<'.$tag;

//					print_rr($te);


                    if($link){

	                    $attr_data_str.=' href="'.$link.'"';
                    }
					$attr_data_str.=' class="custom-attr-label';
					if(isset($ld['attr_link_to']) && ($ld['attr_link_to']=='filter')){
						$attr_data_str .= ' dzs-woo-ajax';
					}

					if(isset($ld['attr_style'])){
						$attr_data_str.=' style-'.$ld['attr_style'];
					}
					$attr_data_str.='"';


					$attr_data_str.='>';



					$iout.=$tli->name;
					$iout.='</'.$tag.'>';


					$ind++;


				}
			}

			if($ld['feed_from']=='short-description'){


			    $maxlen = 400;


				if(isset($ld['desc_count']) && $ld['desc_count']){
				    $maxlen = $ld['desc_count'];
				}

				$iout.=dzs_get_excerpt($po->ID,array(
						'maxlen' => $maxlen
						, 'striptags' => true
						, 'stripshortcodes' => true
						, 'forceexcerpt' => false //if set to true will ignore the manual post excerpt
						, 'try_to_close_unclosed_tags' => false // -- this will try to close unclosed tags
						, 'readmore' => 'auto'
						, 'readmore_markup' => ' <a href="{{permalinktopo}}">read more &rarr;</a>'
						, 'content' => ''
						, 'call_from' => 'default'
					)
				);


			}



			$im_width = 500;
			$im_height = 500;

//			print_rr($ld);


			$im_size = 'full';
			if(isset($ld['thumbnail_size']) && $ld['thumbnail_size']){


			    if(strpos($ld['thumbnail_size'],',')!==false){

				    $szs = explode(',',$ld['thumbnail_size']);


				    $im_width = $szs[0];
				    $im_height = $szs[1];

				    $im_size = array($im_width,$im_height);
                }else{

			        if(is_numeric($ld['thumbnail_size'])){

				        $im_size = array($ld['thumbnail_size']);
                    }else{

				        $im_size = $ld['thumbnail_size'];
                    }
                }
            }





            global $content_width;
			$content_width = 2000;
//			print_rr( get_intermediate_image_sizes() );
//            echo '$im_width - '.$im_width.' | $im_height - '.$im_height. '|';




			$image = $this->get_thumbnail_src($po,$im_size);

			if($ld['feed_from']=='product-image'){



//                    $iout.=print_rrr($image);

				if(isset($image[0])){
					$iout.='<div class="fullwidth-image divimage" data-thumbnail-height="';

					if(isset($ld['thumbnail_height']) && $ld['thumbnail_height']){
						$iout.=$ld['thumbnail_height'];
					}


					$iout.='" style="background-image:url('.$image.'); ';





					if(isset($ld['thumbnail_height']) && $ld['thumbnail_height']){
						$iout.='padding-top: '.(floatval($ld['thumbnail_height'])*100).'%';
					}

					$iout.='"></div>';

				}


			}
			if($ld['feed_from']=='ratings'){

				$average = '';

				if($margs['post_type']=='product'){

					$_pf = new WC_Product_Factory();
					$product = $_pf->get_product($po->ID);
                }
				if($margs['post_type']=='dzsap_items'){


				    $average = get_post_meta($po->ID, '_dzsap_rate_index',true);

                }


//                echo '$average - '.$average;
//                echo '$po->ID - '.$po->ID;


				if($product){


					$average = $product->get_average_rating();
//					print_rr($product);

//                    echo 'average - '.$average;



//                    echo 'perc - '.$perc;


				}
				$perc = ( ( floatval($average) / 5 ) * 100 );



				if($ld['feed_from_ratings_style']=='default'){


					$iout.= '<div class="star-rating"><span style="width:'.( ( $average / 5 ) * 100 ) . '%"><strong itemprop="ratingValue" class="rating">'.$average.'</strong> '.__( 'out of 5', 'woocommerce' ).'</span></div>';
				}

				if($ld['feed_from_ratings_style']=='wootable-stars'){

					$iout.= '<div class="star-rating-con">';

//					echo 'whyy?';
					$iout.='<span class="rating-bg"><span class="rating-inner">{{starssvg}}</span></span>
                                    <span class="rating-prog" style="width: '.$perc.'%;"><span class="rating-inner">{{starssvg}}</span></span>
                                    ';
					$iout.='</div>';
				}


			}


			if($ld['feed_from']=='add-to-cart'){

			    // -- deprecated
				$ld['feed_from']='button';
				$ld['button_type']='add-to-cart';

			}
			if($ld['feed_from']=='button'){



//			    print_rr($ld);
				$iout.=$this->generate_layer_button($margs,$ld,$po);

			}



			if($ld['feed_from']=='acf'){







				if($this->is_plugin_active('advanced-custom-fields/acf.php') || $this->is_plugin_active('advanced-custom-fields-pro/acf.php')){





					$value = get_field( $ld['custom_acf_name'], $po->ID );

//                    error_log('value - '.print_rrr($value));
//                    error_log('$po->ID - '.$po->ID);

					if(is_array($value) && isset($value[0])){
						$iout.='<a href="'.get_permalink($value[0]->ID).'">'.$value[0]->post_title.'</a>';
					}


				}


			}
			if($ld['feed_from']=='zoomsounds-player'){




				if(defined('DZSAP_VERSION')){
					global $dzsap;


					$playerdid = $po->ID;
					$arr = array();






					if($dzsap->get_track_source($po->ID, $playerdid, $arr)){


						wp_enqueue_script('dzsap', $dzsap->base_url . "audioplayer/audioplayer.js");
						wp_enqueue_style('dzsap', $dzsap->base_url . 'audioplayer/audioplayer.css');





						$wave_mode_canvas_mode = 'reflecto';


//						echo 'ld - '; print_rr($ld);
						if(isset($ld['zoomsounds_wave_mode_canvas_mode']) && $ld['zoomsounds_wave_mode_canvas_mode']){
							$wave_mode_canvas_mode = $ld['zoomsounds_wave_mode_canvas_mode'];
						}




						$default_config = array(
							'id' => 'custom-skin-wave-mode-small',
							'skin_ap' => 'skin-wave',
							'settings_backup_type' => 'full',
							'skinwave_dynamicwaves' => 'off',
							'skinwave_enablespectrum' => 'off',
							'skinwave_enablereflect' => 'on',
							'skinwave_comments_enable' => 'off',
							'disable_volume' => 'on',
							'playfrom' => 'default',
							'enable_embed_button' => 'off',
							'loop' => 'off',
							'soundcloud_track_id' => '',
							'soundcloud_secret_token' => '',
							'button_aspect' => 'button-aspect-noir',
							'skinwave_wave_mode_canvas_mode' => $wave_mode_canvas_mode,
							'skinwave_mode' => 'small',
						);


						if(isset($ld['zoomsounds_vpconfig']) && $ld['zoomsounds_vpconfig']){
							$default_config = $ld['zoomsounds_vpconfig'];
						}


						$args = array(
							'source'=>$po->ID,
							'extra_classes'=>' ap-for-'.$po->ID,
							'extra_init_settings'=>'',
							'extra_html'=>'',
							'config'=>$default_config,
						);

//                        print_rr($ld);
						if($ld['zoomsounds_mode']=='just-player'){

						}
						if($ld['zoomsounds_mode']=='just-play-button'){

							$args['extra_classes'].=' disable-all-but-play-btn';


//                            print_rr($bars);
//                            print_rr($ld);
//                            echo 'extra_html - '.$ld['extra_html'];

							foreach ($bars as $ld2){
								if(isset($ld2['feed_from']) && $ld2['feed_from']=='button' &&  (isset($ld2['button_type']) && $ld2['button_type']=='add-to-cart') ){




									$args3 = array_merge(array(), $margs);

									// -- take from here
									$add_to_cart_html = $this->generate_layer_button($margs,$ld2, $po);

									if($add_to_cart_html){
										$args['extra_html'].='<div class="feed-dzsap feed-dzsap-for-extra-html-right"><div class="has-player-full-height">'.$add_to_cart_html.'</div></div>';
									}

									/*
									if(isset($ld2['extra_html']) && $ld2['extra_html']){
										$extra_html = $ld2['extra_html'];
										$_pf = new WC_Product_Factory();
										$product = $_pf->get_product($po->ID);
										$extra_html=$this->generate_extra_html($extra_html,$_pf, $po);



										if(strpos($extra_html,'just-icon-icon')!==false){

											$args['extra_html'].='<div class="feed-dzsap feed-dzsap-for-extra-html-right"><div class="has-player-full-height">'.do_shortcode($extra_html).'</div></div>';
											$args['extra_html'].= '<div class="feed-dzsap feed-dzsap-for-extra-html-right"><div class="has-player-full-height">'.$this->generate_add_to_cart($margs,$ld,$po).'</div></div>';
										}
									}

//                                    print_rr($ld2);
									*/
								}
							}


							$args['extra_init_settings'].=',controls_external_scrubbar:\'.zoomsounds-external-scrubbar-for-'.$po->ID.'\'';
							$args['thumb']=$image;
						}

//                        print_rr($args);
						if($ld['zoomsounds_mode']=='just-player' || $ld['zoomsounds_mode']=='just-play-button'){




						}
						if($ld['zoomsounds_mode']=='full-player'){






						}

						if($ld['zoomsounds_mode']=='just-player' || $ld['zoomsounds_mode']=='just-play-button' || $ld['zoomsounds_mode']=='full-player'){

							if(strpos($ld['extra_classes'],'theme-light')!==false){

								$args['extra_classes'].='  theme-light';
							}
							if(strpos($ld['extra_classes'],'center-it')!==false){
								$args['extra_classes'].='  button-aspect-noir--filled';
//                                $args['button_aspect'].=' ';

								// theme-light
							}

							if($this->db_mainoptions['zoomsounds_play_in_footer']=='on' || (isset($ld['zoomsounds_play_in_footer']) && $ld['zoomsounds_play_in_footer']=='on') ){
								$args['play_target'] = 'footer';
								$args['faketarget'] = '.dzsap_footer';
							}
							$args['autoplay']='off';
							$args['playerid']=$po->ID;


							$iout.= $dzsap->shortcode_player($args);
						}



						if($ld['zoomsounds_mode']=='just-waveform'){

							$iout.='<div class="skin-wave zoomsounds-external-scrubbar-for-'.$po->ID.' zoomsounds-external-scrubbar">
                            <div class="   scrubbar">

                                <div class="scrub-bg"></div>
                                <div class="scrub-buffer"></div>
                                <div class="scrub-prog" style="width: 0.193319px;">
                                    </div>
                                <div class="scrubBox"></div>
                                <div class="scrubBox-prog"></div>
                                <div class="scrubBox-hover"></div>
                            </div>
                        </div>';
						}


					}

//                            $iout.='ceva';
				}

			}




			$iout.='</'.$table_content_item_tag.'>';

		}


	}


	function generate_extra_html($extra_html,$_pf=null,$po=null){



		if(strpos($extra_html,'[ti_wishlists_addtowishlist')!==false){
			global $product;

			if($_pf){

				$product = $_pf->get_product($po->ID);
			}
		}

		$extra_html=str_replace('{{theid}}',$po->ID,$extra_html);


		$icon_wishlist = 'fa-star-o';



//		        print_rr($arr_wishlist);

//        echo '$extra_html - '.$extra_html;
        if(strpos($extra_html,'wishlist_star_toggler_icon')!==false){

	        $arr_wishlist= $this->get_wishlist();


//	        echo '$arr_wishlist - '; print_rr($arr_wishlist);
	        if(in_array($po->ID,$arr_wishlist)){
		        $icon_wishlist = str_replace('fa-star-o','fa-star',$icon_wishlist);
	        }
	        $extra_html=str_replace('{{wishlist_star_toggler_icon}}',$icon_wishlist,$extra_html);
        }



//		        print_rr($arr_wishlist);

//        echo '$extra_html - '.$extra_html;
        $icon_wishlist = 'fa-heart-o';
        if(strpos($extra_html,'{{audio_love_toggler_icon}}')!==false){

//	        $arr_wishlist= $this->get_wishlist();



            global $dzsap;

//            print_rr($dzsap);
            if($dzsap && $dzsap->check_if_user_liked_track($po->ID)){
                $icon_wishlist = str_replace('fa-heart-o','fa-heart',$icon_wishlist);
            }


//	        echo '$arr_wishlist - '; print_rr($arr_wishlist);
//	        if(in_array($po->ID,$arr_wishlist)){
//	        }
	        $extra_html=str_replace('{{audio_love_toggler_icon}}',$icon_wishlist,$extra_html);
        }



		$extra_html=str_replace('{{hearts_svg}}','<svg xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" version="1.0" width="15" height="15"  viewBox="0 0 645 700" id="svg2"> <defs id="defs4" /> <g id="layer1"> <path d="M 297.29747,550.86823 C 283.52243,535.43191 249.1268,505.33855 220.86277,483.99412 C 137.11867,420.75228 125.72108,411.5999 91.719238,380.29088 C 29.03471,322.57071 2.413622,264.58086 2.5048478,185.95124 C 2.5493594,147.56739 5.1656152,132.77929 15.914734,110.15398 C 34.151433,71.768267 61.014996,43.244667 95.360052,25.799457 C 119.68545,13.443675 131.6827,7.9542046 172.30448,7.7296236 C 214.79777,7.4947896 223.74311,12.449347 248.73919,26.181459 C 279.1637,42.895777 310.47909,78.617167 316.95242,103.99205 L 320.95052,119.66445 L 330.81015,98.079942 C 386.52632,-23.892986 564.40851,-22.06811 626.31244,101.11153 C 645.95011,140.18758 648.10608,223.6247 630.69256,270.6244 C 607.97729,331.93377 565.31255,378.67493 466.68622,450.30098 C 402.0054,497.27462 328.80148,568.34684 323.70555,578.32901 C 317.79007,589.91654 323.42339,580.14491 297.29747,550.86823 z" id="path2417" style="" /> <g transform="translate(129.28571,-64.285714)" id="g2221" /> </g> </svg>',$extra_html);
		$extra_html=str_replace('{{site_url}}',site_url(),$extra_html);
		$extra_html=str_replace('{{itempermalink}}',get_permalink($po->ID),$extra_html);

		return $extra_html;
	}



	function format_to_time($seconds){


		return date('i:s',$seconds);
//        return gmdate("H:i:s", $seconds);

	}





	function ajax_import_layout(){





	    $lab = $_POST['postdata'];

	    $title = 'new layout';
	    if($lab=='e-auto-trading'){
	        $title = 'Auto trading';
        }
	    if($lab=='e-chairs'){
	        $title = 'Furniture listing';
        }
	    if($lab=='e-list-shop'){
	        $title = 'Electronic list';
        }
	    if($lab=='e-electric-laptops'){
	        $title = 'Electric laptops';
        }
	    if($lab=='e-fashion-shop'){
	        $title = 'Fashion shop';
        }
	    if($lab=='e-listar'){
	        $title = 'Simple list';
        }
	    if($lab=='e-pro-sounds'){
	        $title = 'Pro sounds';
        }
	    if($lab=='e-real-estate'){
	        $title = 'Real estate';
        }
	    if($lab=='e-charts'){
	        $title = 'Charts';
        }


        $path = "sampledata/".$lab.'.txt';


	    error_log(' path - '.$path);
	    if(file_exists(dirname(__FILE__).'/'.$path)){

		    $content = file_get_contents($path, true);



		    if($lab=='e-pro-sounds') {
			    $path2 = 'sampledata/dzsap-slider-pro-sounds.txt';
			    $content2 = file_get_contents($path2, true);



			    global $dzsap;

			    if($dzsap){

				    $sw_import = true;
				    $slider = unserialize($content2);

				    foreach ($dzsap->mainitems_configs as $mainitem){


					    if($slider['settings']['id']===$mainitem['settings']['id']){

						    //                            echo '$slider[\'settings\'][\'id\'] - '.$slider['settings']['id'].' - $mainitem[\'settings\'][\'id\'] - '.$mainitem['settings']['id'];
						    $sw_import=false;
					    }
				    }




				    if($sw_import){






					    array_push($dzsap->mainitems_configs, $slider);



					    error_log('mainitems_configs - '.print_r($dzsap->mainitems_configs,true));
					    update_option($dzsap->dbname_mainitems_configs, $dzsap->mainitems_configs);
				    }
			    }



		    }

		    $this->import_demo_insert_post_complete(array(
			    'post_content'=>$content,
			    'post_title'=>$title,
		    ));

		    $response = array(
			    'status_txt' => esc_html__('Imported layout','dzswtl'),
			    'status' => 'success',
		    ) ;
        }else{

		    $response = array(
			    'status_txt' => esc_html__('Layout not found','dzswtl'),
			    'status' => 'error',
		    ) ;
        }



//				print_rr($terms);

		echo json_encode($response);

	    die();
	}
	function ajax_con_generator_preview_shortcode(){



//	    echo '$_POST[\'postdata\'] - '.$_POST['postdata'].'<br>';

	    echo do_shortcode(stripslashes($_POST['postdata']));
	    die();


	}




	function get_wishlist(){


		$arr_wishlist = array();


		$arr_wishlist_str = '';
		if(get_current_user_id()){

			if(get_user_meta(get_current_user_id(),'dzswtl_wishlist',true) && get_user_meta(get_current_user_id(),'dzswtl_wishlist',true)!='null'){

			    $arr_wishlist_str = get_user_meta(get_current_user_id(),'dzswtl_wishlist',true);
			}
        }else{
//		    print_rr($_COOKIE);

//            error_log('$_COOKIE - '.print_r($_COOKIE,true));

            if(isset($_COOKIE['dzswtl_wishlist'])){
                $arr_wishlist_str = stripslashes($_COOKIE['dzswtl_wishlist']);
            }
        }

//        echo '$arr_wishlist_str - '.$arr_wishlist_str;

        if($arr_wishlist_str){

	        try{

		        $arr_wishlist = json_decode($arr_wishlist_str,true);
	        }catch(Exception $e){

	        }
        }

//        echo '$arr_wishlist - '; print_rr($arr_wishlist);


		return $arr_wishlist;
	}

	function ajax_add_to_wishlist(){


		$arr_wishlist = $this->get_wishlist();






		if($_POST['wishlist_action']=='add'){
//	        echo 'addd';

            if(in_array($_POST['playerid'], $arr_wishlist)==false){

	            array_push($arr_wishlist,$_POST['playerid']);
            }

//	        echo '$arr_wishlist 1 - '; print_rr($arr_wishlist);
		}else{

			foreach ($arr_wishlist  as $lab=>$val){
				if($val==$_POST['playerid']){
					unset($arr_wishlist[$lab]);
				}
			}
		}

//        echo '$_POST - '; print_rr($_POST);
//        echo 'playerid - '; print_rr($_POST['playerid']);
//        echo '$arr_wishlist - '; print_rr($arr_wishlist);


        if(get_current_user_id()){

	        update_user_meta(get_current_user_id(),'dzswtl_wishlist',json_encode($arr_wishlist));
        }else{


	        @setcookie( 'dzswtl_wishlist', json_encode($arr_wishlist), time() + (30 * 24 * 3600), COOKIEPATH, COOKIE_DOMAIN );
	        error_log('json_encode($arr_wishlist) - '.print_r(json_encode($arr_wishlist),true));
        }




		die();
	}











	function ajax_generate_attribute_sort(){



	    $args = array(
	            'post_type'=>'product',
	            'posts_per_page'=>-1,
        );

		$query = new WP_Query($args);

//		print_rr($query);

		$pos = $query->posts;

		$pa_slug =$_POST['postdata'];
		$taxonomy = $pa_slug;





//		$tax_obj = get_taxonomy($taxonomy);
//
//		// -- todo: find the order in which to order ? default by number value
//		print_rr($tax_obj);

		if(is_array($pos) && count($pos)){
		    foreach ($pos as $po){
//		        print_rr($po);



                $po_terms = wp_get_post_terms($po->ID,$taxonomy);

//                print_rr($po_terms);



			    if(is_array($po_terms) && count($po_terms)) {
				    update_post_meta( $po->ID, 'metapa_' . $taxonomy, $po_terms[0]->name );
			    }

            }
        }


		die();
	}
	function ajax_quick_save_layout(){



		// Update post 37
		$my_post = array(
			'ID'           => $_POST['post_id'],
			'post_content' => $_POST['postdata'],
		);



		wp_update_post( $my_post );


		die();

	}
	function ajax_dzswtl_prev_array(){



//        print_r($_POST);


//        echo $_POST['postdata'] . ' -- ';
		parse_str($_POST['postdata'], $arr_data);

//        print_r($arr_data);
//        echo unserialize($_POST['postdata']);



		echo $this->shortcode_woo_table(array(
			'layout'=>$arr_data,
			'get_preview_data'=>'on',
		));




		die();

	}

	function generate_tag_for_child($margs,$ld,$po){

	    $link = '';
	    $tag = 'div';
	    $class = 'inner-tag';
	    $extraattr = ' ';


	    $fout_arr = array(

        );

		$_pf = null;
		if(class_exists('WC_Product_Factory')){
			$_pf = new WC_Product_Factory();
			$product = $_pf->get_product($po->ID);





			if($product){






//			    print_rr($product);






				if( isset($ld['button_functionality'])==false || (isset($ld['button_functionality']) &&  ($ld['button_functionality']=='default' || $ld['button_functionality']=='') )){

					if(isset($ld['button_type']) && $ld['button_type']=='add-to-cart'){

						$ld['button_functionality'] = 'link';
                    }else{

						$ld['button_functionality'] = 'direct_link';
                    }

				}

				// -- settled button_functionality



                $class.=' button-functionality-'.$ld['button_functionality'];

//				print_rr($ld);
//				print_rr($margs);


				if(isset($ld['button_type']) && $ld['button_type']=='wishlist'){

				    $class.=' dzswtl-wishlist-but';
				    $extraattr.=' data-post_id="'.($po->ID).'"';
				}

				$link = dzs_curr_url();

				if(isset($margs['page_url']) && $margs['page_url']){
					$link = $margs['page_url'];
				}

//				print_rr($ld);

				if(isset($ld['button_type']) && $ld['button_type']=='add-to-cart' && isset($ld['button_functionality']) && $ld['button_functionality']=='link') {
					$link = DZSHelpers::remove_query_arg( $link, 'dzswtl_action' );
					$link = DZSHelpers::add_query_arg( $link, 'add-to-cart', $po->ID );
				}


				if(isset($ld['button_type']) && $ld['button_type']=='add-to-cart' && isset($ld['button_functionality']) && $ld['button_functionality']=='link') {
					if ( $product->is_type( 'variable' ) || $product->is_type( 'grouped' ) ) {
						$link = get_permalink( $po->ID );
					}
				}

				if(isset($ld['button_functionality']) && $ld['button_functionality']=='purchase_lightbox') {


				    $link = '#';

				    $class .= ' ultibox-item-delegated';

				    $extraattr.='  data-source="#purchase-lightbox-'.$po->ID.'" data-box-bg="#FFFFFF" data-audio-thumb="img/rm2.jpg"  data-biggallery="ulti2" data-inline-move="on"';

				}

				if( isset($ld['button_functionality']) && $ld['button_functionality']=='direct_link') {

					$link = get_permalink( $po->ID );
				}





				$link = esc_url($link);






				if($product){

					$price = $product->get_price();
                }



//				print_rr()
				if($price==0){

					if($product->is_downloadable()){

						$downloads = $product->get_downloads();

//							print_rr($downloads);


						foreach( $downloads as $key => $each_download ) {
							$link = $each_download['file'];



							$link = site_url().'?action=dzswtl_download&id='.($po->ID);

//							echo 'link - '.$link;
						}
					}
				}




				}

		}
		if( isset($ld['button_functionality']) && $ld['button_functionality']=='none') {
			$link = '';

//			echo 'none';
		}


		if($link){
		    $tag = 'a';
        }else{
		    $tag = 'span';
        }



		$fout_arr['link']=$link;
		$fout_arr['tag']=$tag;
		$fout_arr['class']=$class;
		$fout_arr['extraattr']=$extraattr;



		return $fout_arr;

    }

	function generate_layer_button($margs,&$ld,$po){

		$iout = '';



		$iout.='<div class="dzswtl-table-item-button ';
		$iout.=' dzswtl-table-item-button--style-'.$ld['button_style'];

		$iout.='" style="';

		if(isset($ld['font_size']) && $ld['font_size']){
		    $iout.=' font-size: '.'inherit'.';';
        }

//		print_rr($ld);

		$iout.='" >';



		$inner_con_markup = '';
		$inner_markup = '';
		$inner_con_markup_end = '';




		$inner_dom_conf = $this->generate_tag_for_child($margs,$ld,$po);




//		echo '$inner_dom_conf - '; print_rr($inner_dom_conf);



		$_pf = null;

		// -- try to settle inner markup





		if(isset($ld['button_type']) && $ld['button_type']=='add-to-cart') {


			if(class_exists('WC_Product_Factory')) {
				$_pf     = new WC_Product_Factory();
				$product = $_pf->get_product( $po->ID );


				if ( $product ) {



					if ( $ld['button_style'] == 'default' ) {

						if ( $product->is_type( 'variable' ) || $product->is_type( 'grouped' ) ) {
							$inner_markup =  esc_html__( "See Options",'dzswtl' );
						}


					}


				}
			}

			if ( $product && isset($ld['button_style']) &&  ( $ld['button_style'] == 'cosco' ) ) {
			    $inner_markup .= '<span class="dzs-button color-normal-highlight color-over-dark  btn-style-default    btn-padding-big" >';
			    $inner_markup .= '<span class="over-bg " >';
				$inner_markup .= '</span>';
			    $inner_markup .= '<span class="the-icon " >';
			    $inner_markup .= '<i class="svg-icon fa fa-shopping-cart"></i>';
				$inner_markup .= '</span>';
			    $inner_markup .= '<span class="the-text " >';
			    $inner_markup .= esc_html( $product->add_to_cart_text() );
				$inner_markup .= '</span>';
				$inner_markup .= '</span>';
			}
			if ( $product && isset($ld['button_style']) &&  (  $ld['button_style'] == 'gamma' ) ) {



			    $inner_markup .= '<span class="add-to-cart-btn" >';
			    $inner_markup .= esc_html( $product->add_to_cart_text() );
				$inner_markup .= '</span>';
			}



			if ( $ld['button_style'] == 'default' ) {


				if ( $product->is_type( 'simple' ) ) {

					if ( $product->is_purchasable() && $product->is_in_stock() && ! $product->is_sold_individually() ) {


//                                        $url = $product->add_to_cart_url();


						// ' . $url . '
						$inner_markup .= '<form action="" class="cart" method="get" enctype="multipart/form-data">';
//                            $iout .= woocommerce_quantity_input( array(), $product, false );
						$inner_markup .= '<input type="hidden" name="add-to-cart" value="' . $po->ID . '"/>';
						$inner_markup .= '<button class="add-to-cart-btn"  class="button alt">' . esc_html( $product->add_to_cart_text() ) . '</button>';
						$inner_markup .= '</form>';
					}else{

						$inner_markup =  esc_html__( "See Options",'dzswtl' );
                    }

				}else{

					$inner_markup =  esc_html__( "See Options",'dzswtl' );
                }
			}



			if(isset($ld['button_style']) && $ld['button_style']=='just-icon'){




				$icon_class = 'fa fa-shopping-cart';


                $price = null;
				if($product){

					$price = $product->get_price();
                }

//					print_rr($product);
//					echo '$product->get_price() -'.$product->get_price();

				if($price && $price===0){


					if($product && $product->is_downloadable()){

						$downloads = $product->get_downloads();

//							print_rr($downloads);


						foreach( $downloads as $key => $each_download ) {


//						    print_rr($each_download);

							$icon_class = 'fa fa-download';
						}
					}
				}

				$inner_markup.='<i class="'.$icon_class.'"></i>';
			}
		}else{

			if ( isset( $ld['button_style'] ) && $ld['button_style'] == 'just-icon' ) {
				$icon_class = 'fa fa-star';









				if($ld['button_type']=='wishlist') {



					$icon_class = 'svg-icon  fa fa-star-o';





						$arr_wishlist= $this->get_wishlist();


//	        echo '$arr_wishlist - '; print_rr($arr_wishlist);
						if(in_array($po->ID,$arr_wishlist)){
							$icon_class = str_replace('fa-star-o','fa-star',$icon_class);
						}



				}
				if($ld['button_type']=='custom') {



					$icon_class = $ld['button_custom_text'];


				}
				$inner_markup.='<i class="'.$icon_class.'"></i>';
			}
			if($ld['button_type']=='custom') {

				$inner_markup.=do_shortcode($ld['button_custom_text']);
			}
        }









		if(isset($ld['button_functionality']) && $ld['button_functionality']=='none'){
			$ld['button_functionality'] = 'link';
		}

		if(isset($ld['button_functionality']) && $ld['button_functionality']=='purchase_lightbox'){


		    ob_start();






			wp_enqueue_script('ultibox',$this->base_url.'libs/ultibox/ultibox.js');
			wp_enqueue_style('ultibox',$this->base_url.'libs/ultibox/ultibox.css');
			wp_enqueue_script('contentscroller',$this->base_url.'libs/contentscroller/contentscroller.js');
			wp_enqueue_style('contentscroller',$this->base_url.'libs/contentscroller/contentscroller.css');


		    $im_arrs = $this->get_product_images($po->ID,450);

//		    print_rr($im_arrs);


			$th_arrs = $this->get_product_images($po->ID,150);



			$product = wc_get_product($po->ID);

//			print_rr($product);

			$price = $product->get_price();;


		    ?>
            <div id="purchase-lightbox-<?php echo $po->ID; ?>" class="row row-for-ultibox purchase-lightbox-ultibox show-in-ultibox">


                <div class="col-md-4">


                    <div  class="contentscroller auto-init bullets-right animate-height " style="width: 100%; height: auto;" data-options='{
    "settings_direction": "vertical"
    ,"settings_onlyone": "on"
    ,"outer_thumbs": "#cs2"
}'>
                        <div class="items">
                            <?php

                            foreach ($im_arrs as $im){

                                $url = '';

                                if(isset($im['url'])){
                                    $url = $im['url'];
                                }
                                ?>
                                <div class="csc-item">
                                    <img  class="fullwidth" src="<?php echo $url; ?>"/>
                                </div><?php
                            }

                            ?>

                        </div>


                    </div>

                    <?php
                    if(is_array($th_arrs) && count($th_arrs)>1){
                    ?>



                    <div  class="contentscroller is-functional skin-nova auto-init bullets-right animate-height " style="width: 100%; height: 80px;" data-options='{
    "settings_direction": "horizontal"
    ,"settings_onlyone": "off"
    ,"settings_autoHeight_proportional": "off"
    ,"settings_autoHeight": "off"
    ,"nav_type": "slide"
}'>

                        <div class="items">
	                        <?php

	                        foreach ($th_arrs as $im){

                                $url = '';


                                if(isset($im['url'])){
                                    $url = $im['url'];
                                }

		                        ?>
                                <div class="csc-item">
                                <div  class="fullwidth divimage" style="background-image: url(<?php echo $url; ?>)"></div>
                                </div><?php
	                        }

	                        ?>


                        </div>


                    </div>

                        <?php
                    }
                        ?>

                </div>
                <div class="col-md-8">


                    <h3><?php echo $po->post_title; ?></h3>

                    <div class="price-highlight"><span class="currency-symbol"><?php
			if(function_exists('get_woocommerce_currency_symbol')) {
				echo get_woocommerce_currency_symbol();
			}
                            ?></span><span class="the-price-number"><?php echo $price; ?></span></div>

                    <div class="product-small-description">
                        <?php
                        echo do_shortcode($po->post_content);
                        ?>

                    </div>
                    <form class=" cart" method="post" enctype="multipart/form-data">

                        <input type="hidden" name="add-to-cart" value="<?php echo $po->ID; ?>" />

                        <?php




                        if ($product->is_type( 'variable' )){


	                        $attributes = $product->get_attributes();
	                        $attribute_keys = array_keys( $attributes );
	                        $available_variations = $product->get_available_variations();;
	                        $variation_attributes = $product->get_variation_attributes();;



//	                        echo '$available_variations - '; print_rr($available_variations);


	                        wp_enqueue_script('dzsselector', $this->base_url . 'libs/dzsselector/dzsselector.js');
	                        wp_enqueue_style('dzsselector', $this->base_url . 'libs/dzsselector/dzsselector.css');


	                        foreach ($variation_attributes as $lab=>$val){


//		                        $lab = str_replace('pa_','',$lab);

//		                        echo '$lab - '. $lab;

//	                            $term = get_term_by('slug',$lab,'product_attributes');
	                            $tax = get_taxonomy($lab);



//	                            echo '$term - '; print_rr($term);
//	                            echo '$tax - '; print_rr($tax);

                                echo '<h6 class="pa-tax-label">'.$tax->label.'</h6>';

                        if ( empty( $available_variations ) && false !== $available_variations ){
	                        ?>

	                        <?php
                        }else{
	                        ?>
                            <div class="variations" cellspacing="0">
                                <select class="dzs-style-me attribute-selector  opener-listbuttons option-display-block skin-btn-secondary " name="variation_id">


			                        <?php

			                        $extra_feeding = '';
			                        foreach ( $available_variations as $lab2 => $val2 ) {


//				                        echo 'val 11 - '; print_rr($product->get_variation_attributes() );
//				                        echo 'val - '; print_rr($val);

				                        $atts = $val2['attributes'];
//				                        echo 'atts - '; print_rr($atts);


                                        foreach ($atts as $lab3=>$val3){

//	                                        echo 'lab3 - '.$lab3.' lab - '.$lab;

                                            if(strpos($lab3,$lab)!==false){

//                                                echo 'wjaa';
                                            }else{
                                                continue;
                                            }
                                        }
                                        $atts_vals = array_values($atts);


//				                        echo '$atts_vals - '; print_rr($atts_vals);

				                        $lab_var = $atts_vals[0];



				                        echo '<option data-price="'.$val2['display_price'].'" value="'.$val2['variation_id'].'"></option>';
				                        $extra_feeding.='<li class="bigoption fig-position selector-btn-secondary"><span class="the-text">'.$lab_var.'</span></li>';


				                        ?>



				                        <?php
			                        };
			                        ?>
                                </select>

                                <ul class="dzs-style-me-feeder">

			                        <?php echo $extra_feeding; ?>

                                </ul>

                            </div>
                        <?php
                        };

                            }



                        }
                            ?>


                        <div class="cart-add">
                        <div class="btn-border-circle decrement-val">
                            <div class="icon-inside css-minus">

                            </div>
                        </div>



                        <div class="quantity">
                            <input type="text" class="input-text qty text"    name="quantity" value="1" title="Qty" size="4" pattern="[0-9]*" >
                        </div>



                        <div class="btn-border-circle increment-val">
                            <div class="icon-inside css-plus">

                            </div>
                        </div>


                        <button type="submit" class="dzs-button padding-big add-to-cart single_add_to_cart_button button  color-normal-highlight btn-style-default color-over-dark style-orange"><span class="the-bg"></span><span class="the-text">Add to cart</span></button>

                        </div>

                    </form>
                </div>
            </div><?php


			$this->footer_extra_html.=ob_get_clean();
		}


		$inner_con_markup = '<'.$inner_dom_conf['tag'].' class="'.$inner_dom_conf['class'].'" '.$inner_dom_conf['extraattr'].'';


//		echo '$inner_dom_conf[\'link\'] - '.$inner_dom_conf['link'];
		if(isset($inner_dom_conf['link']) && $inner_dom_conf['link']){

			$inner_con_markup .=' href="'.$inner_dom_conf['link'].'"';
		}
		$inner_con_markup .= '>';





		if($inner_con_markup){
			$iout.=$inner_con_markup;
		}




		if($inner_markup){
			$iout.=$inner_markup;
		}



		$inner_con_markup_end = '</'.$inner_dom_conf['tag'].'>';
		if($inner_con_markup_end){
			$iout.=$inner_con_markup_end;
		}






		if(isset($ld['extra_html']) && $ld['extra_html']){


			$extra_html = $ld['extra_html'];

			$extra_html=$this->generate_extra_html($extra_html,$_pf, $po);

			$iout.=do_shortcode($extra_html);
//                                $iout.=($ld['extra_html']);
		}




		$iout.='</div><!--end -->';



	    if(isset($ld['button_type']) && $ld['button_type']=='add-to-cart'){

        }


        return $iout;

	}

	function generate_add_to_cart($margs,$ld,$po){

		$iout = '';

		return $iout;

	}

	function register_links(){



		register_post_status( 'dzs_preview', array(
			'label'                     => _x( 'DZS Preview', 'post' ),
			'public'                    => false,
			'exclude_from_search'       => true,
			'show_in_admin_all_list'    => false,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop( 'Table Preview <span class="count">(%s)</span>', 'Table Preview  <span class="count">(%s)</span>' ),
		) );

		$labels = array(
			'name' => __("Shop Layouts"),
			'singular_name' => __('Shop Layout'),
		);



		$lab = 'dzswtl_list_layout';



		$args = array(
			'labels' => $labels,
			'public' => true,
			'has_archive' => true,
			'hierarchical' => false,
			'supports' => array('title','editor','author','revisions'),
			'rewrite' => array('slug' => 'woo-layout'),
			'yarpp_support' => true,
			//'taxonomies' => array('categoryportfolio'),
		);
		register_post_type($lab,$args);
	}

	function handle_save_post($post_id){


		$po = get_post($post_id);

//        error_log(print_rr($po, array('echo'=>false)));

		if($po->post_status=='publish'){
			$po->post_status = 'draft';
		}

		if($po->post_title=='Auto Draft'){
			$po->post_content = __("This is just a preview page");
		}


//        error_log(print_rr($po, array('echo'=>false)));
		if($po->post_status!='auto-draft' ||  ( ($po->post_parent) && $po->post_parent!='0' ) ){
//            die("HMM");
		}





//		error_log('save_post '.$post_id);


//		$po = get_post($post_id);


		$taxonomies = get_taxonomies('','names');

		foreach ($taxonomies as $taxonomy){
			if(strpos($taxonomy,'pa_')===0){

				$po_terms = wp_get_post_terms($po->ID,$taxonomy);
//				error_log('terms - '.print_rr($po_terms,true));

				if(is_array($po_terms) && count($po_terms)) {
			        update_post_meta( $po->ID, 'metapa_' . $taxonomy, $po_terms[0]->name );
				}
			}
		}

	}

	function handle_init(){

//        header('X-Frame-Options: GOFORIT');

		global $pagenow, $post;


		if(is_admin()){



//		    print_rr($post);




			wp_enqueue_style('dzswtl-admin', $this->base_url . "admin/admin.css");
			wp_enqueue_script('dzswtl-admin', $this->base_url . "admin/admin.js");
            wp_enqueue_style('dzswtl-admin-global', $this->base_url . "admin/admin_global.css");
			wp_enqueue_script('dzswtl-admin-global', $this->base_url . "admin/admin_global.js");

			if (isset($_GET['page']) && $_GET['page'] == $this->adminpagename_mainoptions) {

				$fontawesomelink = $this->base_url . 'libs/fontawesome/font-awesome.min.css';
				if(defined("DZSWTL_USE_FONTAWESOME_FROM_CDN") && DZSWTL_USE_FONTAWESOME_FROM_CDN=="ON"){
					$fontawesomelink = 'https://'.'maxcdn'.'bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css';
				}

				wp_enqueue_style( 'fontawesome', $fontawesomelink);

				wp_enqueue_style('dzstabsandaccordions', $this->base_url . 'libs/dzstabsandaccordions/dzstabsandaccordions.css');
				wp_enqueue_script('dzstabsandaccordions', $this->base_url . "libs/dzstabsandaccordions/dzstabsandaccordions.js");



//				wp_enqueue_style('dzswtl-admin-mo', $this->base_url . "admin/admin-mo.css");
				wp_enqueue_script('dzswtl-admin-mo', $this->base_url . "admin/admin-mo.js");
				wp_enqueue_style('dzstoggle', $this->base_url . 'libs/dzstoggle/dzstoggle.css');
				wp_enqueue_script('dzstoggle', $this->base_url . "libs/dzstoggle/dzstoggle.js");

			}


			if(current_user_can('manage_options')==false){

//                echo dzs_curr_url();
				if( strpos(dzs_curr_url(), 'edit.php?post_type=page')!==false ){

//                    echo 'hmmdada'.admin_url('post-new.php?post_type=page');

					$url = admin_url('post-new.php?post_type=page');

					wp_redirect( $url );

					exit;

					// TODO: redirect

//                    header('Location: '.admin_url('post-new.php?post_type=page'));
//                    echo $_GET['post_type']. ' '.admin_url('post-new.php?post_type=page');
//                    if(isset($_GET['post_type']) && $_GET['post_type']=='page'){
//                    }
				}
			}




			if(current_user_can('manage_options') || current_user_can('directory_make_shortcode')){

				wp_enqueue_script('dzswtl-add-generators', $this->base_url . 'shortcodegenerator/add-generators-to-mce.js');
				wp_enqueue_script('dzswtl-shortcode-receiver', $this->base_url . 'shortcodegenerator/shortcode-receiver.js');


				wp_enqueue_script('ultibox',$this->base_url.'libs/ultibox/ultibox.js');
				wp_enqueue_style('ultibox',$this->base_url.'libs/ultibox/ultibox.css');

			}

		}


		add_filter('pre_get_posts', array($this,'posts_for_current_author') );


		$this->register_links();


		if($this->plugin_justactivated=='on'){

			flush_rewrite_rules();

			error_log("JUST ACTIVATED DZSWTL");
        }



		add_action('admin_footer-edit.php',array($this,'status_into_inline_edit'));
		add_action( 'post_submitbox_misc_actions',array($this, 'add_to_post_status_dropdown') );



		add_action( 'product_cat_edit_form_fields', array($this,'term_meta_fields'), 10, 10 );
		add_action( 'product_attributes_edit_form_fields', array($this,'term_meta_fields'), 10, 10 );



		add_action( 'edited_product_cat', array($this,'save_taxonomy_custom_meta'), 10, 2 );
		add_action( 'edited_product_attributes', array($this,'save_taxonomy_custom_meta'), 10, 2 );




		if(isset($_GET['dzswtl_action']) && $_GET['dzswtl_action']=='load_new_content'){

//			echo 'ceva';
			add_action( 'pre_get_posts', array($this,'search_pre_get_posts') );
			add_filter( 'posts_search', array($this,'filter_posts_search_include_tags'), 500, 2 );



        }


		add_action( 'woocommerce_product_option_terms', array( $this, 'product_option_terms' ), 10, 2 );
		add_action( 'dzswtl_product_attribute_field', array( $this, 'attribute_fields' ), 10, 3 );
		add_filter( 'product_attributes_type_selector', array( $this, 'add_attribute_types' ) );

		if(function_exists('wc_get_attribute_taxonomies')){

			$attribute_taxonomies = wc_get_attribute_taxonomies();

			if ( empty( $attribute_taxonomies ) ) {
				return;
			}

			foreach ( $attribute_taxonomies as $tax ) {
				add_action( 'pa_' . $tax->attribute_name . '_add_form_fields', array( $this, 'add_attribute_fields_pa' ) );
				add_action( 'pa_' . $tax->attribute_name . '_edit_form_fields', array( $this, 'edit_attribute_fields_pa' ), 10, 2 );
			}
		}
		add_action( 'created_term', array( $this, 'save_term_meta' ), 10, 2 );
		add_action( 'edit_term', array( $this, 'save_term_meta' ), 10, 2 );






		/*
		*/
	}

	public function save_term_meta( $term_id, $tt_id ) {
		foreach ( $this->attribute_extra_types as $type => $label ) {
			if ( isset( $_POST[$type] ) ) {
				update_term_meta( $term_id, $type, $_POST[$type] );
			}
		}
	}

	function filter_posts_search_include_tags( $search, &$wp_query ) {
		global $wpdb;

//		error_log(' search - '.print_r($search,true));
		if ( empty( $search ))
			return $search;

//		echo 'ceva search';
		$terms = $wp_query->query_vars[ 's' ];
		$exploded = explode( ' ', $terms );
		if( $exploded === FALSE || count( $exploded ) == 0 )
			$exploded = array( 0 => $terms );

		error_log('dzswtl search  - '.print_r($search,true));
		$search = '';

		error_log('dzswtl search tags - '.print_r($exploded,true));






		$table_name = $wpdb->prefix.'posts';



		foreach( $exploded as $tag ) {
			$search .= " AND (
            (".$wpdb->prefix."posts.post_title LIKE '%$tag%')
            OR (".$wpdb->prefix."posts.post_content LIKE '%$tag%')
            OR EXISTS
            (
                SELECT * FROM ".$wpdb->prefix."terms
                INNER JOIN ".$wpdb->prefix."term_taxonomy
                    ON ".$wpdb->prefix."term_taxonomy.term_id = ".$wpdb->prefix."terms.term_id
                INNER JOIN ".$wpdb->prefix."term_relationships
                    ON ".$wpdb->prefix."term_relationships.term_taxonomy_id = ".$wpdb->prefix."term_taxonomy.term_taxonomy_id
                WHERE taxonomy = 'product_tag'
                    AND object_id = ".$wpdb->prefix."posts.ID
                    AND ".$wpdb->prefix."terms.name LIKE '%$tag%'
            )
        )";
		}
		error_log('dzswtl new search  - '.print_r($search,true));

		return $search;
	}


	public function attribute_fields( $type, $value, $form ) {
		// Return if this is a default attribute type
		if ( in_array( $type, array( 'select', 'text' ) ) ) {
			return;
		}

		// Print the open tag of field container
		printf(
			'<%s class="form-field">%s<label for="term-%s">%s</label>%s',
			'edit' == $form ? 'tr' : 'div',
			'edit' == $form ? '<th>' : '',
			esc_attr( $type ),
			$this->attribute_extra_types[$type],
			'edit' == $form ? '</th><td>' : ''
		);

		if($type=='color'){
				?>
                <input class="color-with-spectrum attribute-type-<?php echo esc_attr( $type ) ?>" type="text" id="term-<?php echo esc_attr( $type ) ?>" name="<?php echo esc_attr( $type ) ?>" value="<?php echo esc_attr( $value ) ?>" />
				<?php
		}

		// Print the close tag of field container
		echo 'edit' == $form ? '</td></tr>' : '</div>';
	}
	public function product_option_terms( $taxonomy, $index ) {
		if ( ! array_key_exists( $taxonomy->attribute_type, $this->attribute_extra_types ) ) {
			return;
		}

		$taxonomy_name = wc_attribute_taxonomy_name( $taxonomy->attribute_name );
		global $thepostid;
		?>

        <select multiple="multiple" data-placeholder="<?php esc_attr_e( 'Select terms', 'wcvs' ); ?>" class="multiselect attribute_values wc-enhanced-select" name="attribute_values[<?php echo $index; ?>][]">
			<?php

			$all_terms = get_terms( $taxonomy_name, apply_filters( 'woocommerce_product_attribute_terms', array( 'orderby' => 'name', 'hide_empty' => false ) ) );
			if ( $all_terms ) {
				foreach ( $all_terms as $term ) {
					echo '<option value="' . esc_attr( $term->term_id ) . '" ' . selected( has_term( absint( $term->term_id ), $taxonomy_name, $thepostid ), true, false ) . '>' . esc_attr( apply_filters( 'woocommerce_product_attribute_term_name', $term->name, $term ) ) . '</option>';
				}
			}
			?>
        </select>
        <button class="button plus select_all_attributes"><?php esc_html_e( 'Select all', 'wcvs' ); ?></button>
        <button class="button minus select_no_attributes"><?php esc_html_e( 'Select none', 'wcvs' ); ?></button>
        <button class="button fr plus tawcvs_add_new_attribute" data-type="<?php echo $taxonomy->attribute_type ?>"><?php esc_html_e( 'Add new', 'wcvs' ); ?></button>

		<?php
	}
	public function get_tax_attribute( $taxonomy ) {
		global $wpdb;

		$attr = substr( $taxonomy, 3 );
		$attr = $wpdb->get_row( "SELECT * FROM " . $wpdb->prefix . "woocommerce_attribute_taxonomies WHERE attribute_name = '$attr'" );

		return $attr;
	}
	public function add_attribute_fields_pa( $taxonomy ) {
		$attr = $this->get_tax_attribute( $taxonomy );


//		echo 'attr - '.print_rr($attr,true);
		do_action( 'dzswtl_product_attribute_field', $attr->attribute_type, '', 'add' );


		wp_enqueue_style('spectrum',$this->base_url.'libs/spectrum/spectrum.css');
		wp_enqueue_script('spectrum',$this->base_url.'libs/spectrum/spectrum.js');
	}
	public function add_attribute_types( $types ) {
		$types = array_merge( $types, $this->attribute_extra_types );

		return $types;
	}
	public function edit_attribute_fields_pa( $term, $taxonomy ) {
		$attr  = $this->get_tax_attribute( $taxonomy );
		$value = get_term_meta( $term->term_id, $attr->attribute_type, true );

//		echo 'attr - '.print_rr($attr,true);
//		echo 'value - '.print_rr($value,true);
		do_action( 'dzswtl_product_attribute_field', $attr->attribute_type, $value, 'edit' );


		wp_enqueue_style('spectrum',$this->base_url.'libs/spectrum/spectrum.css');
		wp_enqueue_script('spectrum',$this->base_url.'libs/spectrum/spectrum.js');
	}




	function term_meta_fields($term){
		// this will add the custom meta field to the add new term page

		$struct_uploader = '<div class="dzs-wordpress-uploader insert-id">
<a href="#" class="button-secondary">' . __('Upload', 'dzsvp') . '</a>
</div>';

		$fontawesomelink = $this->base_url . 'libs/fontawesome/font-awesome.min.css';
		if(defined("DZSWTL_USE_FONTAWESOME_FROM_CDN") && DZSWTL_USE_FONTAWESOME_FROM_CDN=="ON"){
			$fontawesomelink = 'https://'.'maxcdn'.'bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css';
		}

		wp_enqueue_style( 'fontawesome', $fontawesomelink);

		foreach ($this->term_metas as $tem) {
			?>

			<?php


			$t_id = $term->term_id;

			// retrieve the existing value(s) for this meta field. This returns an array
			$term_meta = get_option("taxonomy_$t_id"); ?>
            <tr class="form-field">
                <th scope="row" valign="top"><label
                            for="term_meta[<?php echo $tem['name']; ?>]"><?php echo $tem['title']; ?></label></th>
                <td class="<?php
				if($tem['type']=='media-upload'){
					echo 'setting-upload';
				}
				?>">





					<?php

					if($tem['type']=='media-upload'){
						echo '<span class="uploader-preview"></span>';
					}
					?>



					<?php
					$lab = 'term_meta['.$tem['name'].']';

					$val = '';

					if(isset($term_meta[$tem['name']])){

						$val = esc_attr($term_meta[$tem['name']]) ? esc_attr($term_meta[$tem['name']]) : '';
					}

					$class = 'setting-field medium';


					if($tem['type']=='media-upload') {
						$class.=' uploader-target';

						wp_enqueue_media();
					}

					if($tem['type']=='color') {
						$class .= ' color-with-spectrum';
					}
					if($tem['type']=='media-upload' || $tem['type']=='text' || $tem['type']=='input') {
					}

					if($tem['type']=='iconselector') {
					wp_enqueue_style('spectrum',$this->base_url.'libs/spectrum/spectrum.css');
					wp_enqueue_script('spectrum',$this->base_url.'libs/spectrum/spectrum.js');
					wp_enqueue_script('faiconselector',$this->base_url.'libs/dzsiconselector/dzsiconselector.js');
					wp_enqueue_style('faiconselector',$this->base_url.'libs/dzsiconselector/dzsiconselector.css');

					$class.= ' style-iconselector iconselector-waiter';
					?><div class="iconselector" data-input-acts-as-search="on">
                        <p>

                            <span class="iconselector-preview"></span>
							<?php
							}

							echo DZSHelpers::generate_input_text($lab, array(
								'class' => $class,
								'seekval' => $val,
								'id' => $lab,
							));
							if($tem['type']=='iconselector') {
							?>
                            <span class="iconselector-btn"><i class="fa fa-caret-down"></i>
                        </p>

                        </span><div class="iconselector-clip"><?php
							$icons_html = '';
							include_once "class_parts/faicons_html.php";
							echo $icons_html;
							?></div>
                    </div><?php
				}


				if($tem['type']=='color') {
//                DZSHelpers::generate_input_text($lab, array('val' => '', 'class' => 'wp-color-picker-init ', 'seekval' => $val));
				}

				if($tem['type']=='media-upload') {
					echo $struct_uploader;
				}
				?>
					<?php

					?>
                    <p class="description"><?php _e('Enter a value for this field', 'pippin'); ?></p>
                </td>
            </tr>
			<?php
		}
	}

	function save_taxonomy_custom_meta( $term_id ) {
		if ( isset( $_POST['term_meta'] ) ) {
			$t_id = $term_id;
			$term_meta = get_option( "taxonomy_$t_id" );
			$cat_keys = array_keys( $_POST['term_meta'] );
			foreach ( $cat_keys as $key ) {
				if ( isset ( $_POST['term_meta'][$key] ) ) {
					$term_meta[$key] = $_POST['term_meta'][$key];
				}
			}
			// Save the option array.
			update_option( "taxonomy_$t_id", $term_meta );
		}
	}

	function add_to_post_status_dropdown(){
		global $post;
		?>
        <script>
            jQuery(document).ready(function($){
                $("select#post_status").append("<option value=\"dzs_preview\" <?php selected('dzs_preview', $post->post_status); ?>>Grid preview</option>");
            });
        </script>
		<?php
	}
	function status_into_inline_edit() { // ultra-simple example
		echo "<script>
	jQuery(document).ready( function() {
		jQuery( 'select[name=\"_status\"]' ).append( '<option value=\"dzs_preview\">Grid preview </option>' );
	});
	</script>";
	}


	function handle_init_end(){

		$this->check_posts();








		if (isset($_GET['action'])) {



			// -- download get
			if($_GET['action']=='dzswtl_download'){


				if(isset($_GET['id'])&&$_GET['id']){

					$po = get_post($_GET['id']);

//                    print_r($po);


					$title = 'song';


					if($po && $po->post_title){
						$title = $po->post_title;
					}


					// -- todo: might need this later
//					if($this->db_mainoptions['allow_download_only_for_registered_users']=='on'){
//						global $current_user;
//
////                        print_rr($current_user);
//
//
//						if($current_user->ID){
//
//
//							if($this->db_mainoptions['allow_download_only_for_registered_users_capability'] && $this->db_mainoptions['allow_download_only_for_registered_users_capability']!='read'){
//								if(current_user_can($this->db_mainoptions['allow_download_only_for_registered_users_capability'])){
//
//								}else{
//
//									die(__("You do not have permission",'dzsap'));
//								}
//							}
//						}else{
//
//							die(__("You need to register",'dzsap'));
//						}
//					}


					$filename = '';

					$path = '';

					if($po->post_type=='dzsap_items'){

						$ceva = 0;
						$cevamargs =array();
						$filename = $this->get_track_source($po->ID,$ceva,$cevamargs);

						$path = '';

						if(strpos($filename,site_url())!==false){
							$path = str_replace(site_url(),ABSPATH,$filename);
						}


//					    echo site_url();
//					    echo ABSPATH;
//					    error_log('$filename - '.$filename);
					}



					if($filename==''){
						if($filename==''){
							if(function_exists('get_field')){
								$arr = get_field('scratch_preview',$po->ID);


								if($arr){

									$media = wp_get_attachment_url($arr);

//                echo 'media - '.$media;
									$filename = $media;
								}
							}
						}
					}


					if($po->post_type=='product') {



						if(class_exists('WC_Product_Factory')) {
							$_pf     = new WC_Product_Factory();
							$product = $_pf->get_product( $po->ID );


							if ( $product->is_downloadable() ) {

								$downloads = $product->get_downloads();

//							print_rr($downloads);


								foreach ( $downloads as $key => $each_download ) {
									$filename = $each_download['file'];

//							echo 'link - '.$link;
								}
							}
						}
					}






//                    echo $filename;


					$extension = 'mp3';
					$content_type = 'application/octet-stream';

					// -- dzs ap download
					if(strpos($filename,'.m4a')!==false){
						$extension = 'm4a';
						$content_type = 'audio/mp4';
//						$content_type = 'audio/x-m4a';
					}
					if(strpos($filename,'.wav')!==false){
						$extension = 'wav';
						$content_type = 'audio/wav';
//						$content_type = 'audio/x-m4a';
					}


//                    echo $filename;

					header("Pragma: public");
					header("Expires: 0");
//					header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
//					header("Cache-Control: public");
//					header("Content-Description: File Transfer");
					header("Content-Type: '.$content_type.'");
					header("Content-Disposition: attachment; filename=\"".strtolower($title).".".$extension."\"");
					header("Content-Transfer-Encoding: binary");
//                    header("Content-Length: ".filesize($filename));


//                    $path = '';


					if($path){

						header('Content-Length: '.filesize($path));

						readfile($path);
					}else{

						echo  file_get_contents($filename);
					}







					// --end id


				}
				die();
			}
		}





		if(get_option('dzswtl_installed_sample_data')){

		}else{




//		    include_once "class_parts/sample-data.php";



			update_option('dzswtl_installed_sample_data', 'yes');
		}

	}




	function check_posts() {

	    // -- call in init_end

		if(isset($_GET['dzswtl_action'])){
			if($_GET['dzswtl_action']=='load_filter_availability'){


				$taxs = json_decode(stripslashes($_POST['postdata']),true);


//			    print_rr($taxs);

			    $final_arr = array();


			    foreach ($taxs as $tax_name){


				    $final_arr[$tax_name] = array();

				    $terms = get_terms( $tax_name, array(
					    'hide_empty' => false,
				    ) );





//				    print_rr($terms);

				    foreach ($terms as $term){


					    $pages = get_posts(array(
						    'post_type' => 'any',
						    'numberposts' => -1,
						    'tax_query' => array(
							    array(
								    'taxonomy' => $tax_name,
								    'field' => 'id',
								    'terms' => $term->term_id, // Where term_id of Term 1 is "1".
								    'include_children' => false
							    )
						    )
					    ));

//					    echo 'term_pages ( '.$term->slug.' ) - '; print_rr($pages);


					    $final_arr[$tax_name][$term->slug] = array();
                        foreach ($pages as $pg){
	                        array_push($final_arr[$tax_name][$term->slug],$pg->ID);
                        }
                    }

			    }

			    echo json_encode($final_arr);

				die();




			}
			if($_GET['dzswtl_action']=='load_subcats'){


			    $term_parent = $_POST['postdata'];


				$taxonomy = 'product_cat';
				$term_parent_id = $this->sanitize_term_slug_to_id($term_parent,$taxonomy);


//				print_rr($term_parent);

				$terms = get_terms( $taxonomy, array(
					'hide_empty' => false,
					'parent' => $term_parent_id,
				) );



//				print_rr($terms);

				echo json_encode($terms);

				die();




			}
			if($_GET['dzswtl_action']=='load_new_content'){

			    // -- load_new_content

				error_reporting(E_ERROR | E_PARSE);
//                echo 'post - ';print_r($_POST);
//                echo 'get - ';print_r($_GET);


                if(isset($_POST['postdata'])){

                    try{

	                    $args = json_decode(stripslashes($_POST['postdata']),true);


//                echo 'args - '; print_r($args);

                if(isset($args['cookie_set_posts_per_page']) && $args['cookie_set_posts_per_page']=='on' && isset($args['posts_per_page']) && $args['posts_per_page']){

                    // -- we set cookie to remembers

	                @setcookie( 'dzswtl_posts_per_page_'.$args['called_from_post_id'], $args['posts_per_page'], time() + 30 * 3600 * 24, COOKIEPATH, COOKIE_DOMAIN );

//	                error_log('setcookie - ('.'dzswtl_posts_per_page_'.$args['called_from_post_id'].') ');


                }
                if(isset($args['cookie_set_layout']) && $args['cookie_set_layout']=='on' && isset($args['layout']) && $args['layout']){

                    // -- we set cookie to remembers

	                @setcookie( 'dzswtl_layout_'.$args['called_from_post_id'], $args['layout'], time() + 30 * 3600 * 24, COOKIEPATH, COOKIE_DOMAIN );

//	                error_log('setcookie - ('.'dzswtl_posts_per_page_'.$args['called_from_post_id'].') ');


                }

	                    echo $this->shortcode_woo_table($args);
                    }catch(Exception $e){
                        error_log('no json '.print_rr($e));


                    }
                }


				die();
			}
		}

		if(isset($_POST['dzswtl_action'])){
			if($_POST['dzswtl_action']=='delete_sample_data'){




				$the_slug = 'preview-post-1';
				$args = array(
					'name'        => $the_slug,
					'post_type'   => 'any',
					'post_status'   => 'any',
					'numberposts' => 1
				);
				$my_posts = get_posts($args);
				print_r($my_posts);
				if( $my_posts ) {
					wp_delete_post($my_posts[0]->ID);
				}


				$the_slug = 'preview-post-2';
				$args = array(
					'name'        => $the_slug,
					'post_type'   => 'any',
					'post_status'   => 'any',
					'numberposts' => 1
				);
				$my_posts = get_posts($args);
				if( $my_posts ) {
					wp_delete_post($my_posts[0]->ID);
				}

				$taxonomy = 'product_cat';
				$category = get_term_by('slug','dzs_preview',$taxonomy);


				wp_delete_term($category->term_id,$taxonomy);
			}
		}










		if(isset($_GET) && isset($_GET['dzswtl-load-lightbox-css']) && $_GET['dzswtl-load-lightbox-css']=='on'){

			header("Content-type: text/css");
			?>
			<?php
			die();
		}



	}

	function handle_wp_head(){
		$this->sanitize_get_arr();


		global $post;


		if($post && $post->post_type=='dzswtl_list_layout'){
		    add_filter('the_content',array($this,'filter_the_content'));
        }

        if(function_exists('is_product_category') && is_product_category()){

//		    echo 'cevadada';

            if($this->db_mainoptions['replace_woocommerce_category_page_shortcode']){

	            add_filter('product_cat_description',array($this,'filter_product_cat_description'));
            }



        }
    }

    function filter_product_cat_description($content){
//	    echo 'cevadada';
	    global $wp_query;



//	    print_rr($wp_query);

	    $cat = $wp_query->query['product_cat'];

	    $fout = do_shortcode(str_replace('{{cat}}',$cat,$this->db_mainoptions['replace_woocommerce_category_page_shortcode']));

	    return $fout;
    }
    function filter_the_content($content){

	    global $post;


//	    return 'alceva';
	    if(function_exists('is_product_category') && is_product_category()){
//	        echo 'cevadada';
//	        return 'hmmdada';
	    }

	    if($post && $post->post_type=='dzswtl_list_layout'){


	        $str = '<div class="warning">'.wp_kses(sprintf(__('%swarning: %s this is not how to include the shop layout in a page, please read %sdocs%s','dzswtl'),'<strong>','</strong>','<a href="'.$this->thepath.'readme/index.html" target="_blank">','</a>'), $this->allowed_tags).'</div>';

	        $str.='<h4>'.esc_html__("Preview",'dzswtl').'</h4>';
	        $str.='[dzs_woo_table layout="'.$post->post_name.'" show_filtered_by="on" posts_per_page="12"]';

		    $str.='<br><br><br><h6>'.esc_html__("How to install",'dzswtl').'</h6>';
	        $str.='<p>
            You can now add layouts you create in the <strong>Shop</strong> Admin into any post or page. To make it simple a Shortcode Generator is included. You can access it via this button.</p>';
	        $str.='<p>
            <a class="colorbox" href="https://i.imgur.com/5Dp7rzg.jpg"><a class="colorbox" href="https://i.imgur.com/5Dp7rzg.jpg"><img class="fig" src="https://i.imgur.com/5Dp7rzg.jpg"></a></a></p>';
	        $str.='<p>
            <em>The first button is the shortcode genreator launcher and the second one ( the one with a plus ) ads a single audio player to the page from the media gallery.</em></p>';
	        $str.='<p>
            <iframe allowfullscreen="" frameborder="0" height="315" scrolling="no" src="//www.youtube.com/embed/9iGVUVxnaWY" width="100%"></iframe></p>';

	        $content = do_shortcode($str);
	    }



	    return $content;
    }
	function handle_wp_footer(){

//        header('X-Frame-Options: GOFORIT');



        if($this->footer_extra_html){
            echo $this->footer_extra_html;
        }



        if($this->db_mainoptions['style_widget']=='on'){
            echo '<style>';
            echo '  .dzswtl_widget {  background-color: #fff;
    padding: 15px;
    border-radius: 3px;
    margin-bottom: 30px; }';
            echo '  .dzswtl_widget .dzs-woo-filter.multiple-style-default { overflow: auto;
    max-height: 200px; }';
            echo '</style>';
        }


		?><script>
			<?php


            // -- front end footer

			echo 'window.dzswtl_settings = { version: "'.DZSWTL_VERSION.'",site_url : "'.site_url().'",ajaxurl : "'.admin_url('admin-ajax.php').'",admin_url : "'.admin_url().'"';


			if($this->db_mainoptions['filter_check_availability']){
			    echo ',filter_check_availability: "'.$this->db_mainoptions['filter_check_availability'].'"';
            }

			if(defined('dzswtl_VERSION')){
				echo ',zoomsounds_defined:"on"';
			}else{

				echo ',zoomsounds_defined:"off"';
			}





			$arr_wishlist= $this->get_wishlist();
			echo ',wishlist_ids:\''.json_encode($arr_wishlist).'\'';



			echo '};  ';




			// -- we need layout and posts per page
			if(isset($this->args_curr_wootable['layout'])){

//				unset($this->args_curr_wootable['layout']);
            }
			if(isset($this->args_curr_wootable['posts_per_page'])){

//				unset($this->args_curr_wootable['posts_per_page']);
            }


			$str_curr_args = json_encode($this->args_curr_wootable);



			$str_curr_args = str_replace('\\','{{escape}}',$str_curr_args);

			?>
            window.dzswtl_curr_args = '<?php echo $str_curr_args; ?>';



			<?php




			if($this->sw_enable_multisharer){
			?>
            window.dzswtl_social_feed_for_social_networks = '<h6 class="social-heading">Social Networks</h6> <a class="social-icon" href="#" onclick="window.dzs_open_social_link(&quot;https://www.facebook.com/sharer.php?u={{replacewithdataurl}}&amp;title=test&quot;); return false;"><i class="fa fa-facebook-square"></i><span class="the-tooltip">SHARE ON FACEBOOK</span></a> <a class="social-icon" href="#" onclick="window.dzs_open_social_link(&quot;https://twitter.com/share?url={{replacewithdataurl}}&amp;text=Check this out!&amp;via=ZoomPortal&amp;related=yarrcat&quot;); return false;"><i class="fa fa-twitter"></i><span class="the-tooltip">SHARE ON TWITTER</span></a> <a class="social-icon" href="#" onclick="window.dzs_open_social_link(&quot;https://plus.google.com/share?url={{replacewithdataurl}}&quot;); return false; "><i class="fa fa-google-plus-square"></i><span class="the-tooltip">SHARE ON GOOGLE PLUS</span></a> <a class="social-icon" href="#" onclick="window.dzs_open_social_link(&quot;https://www.linkedin.com/shareArticle?mini=true&amp;url={{replacewithdataurl}}&amp;title=Check%20this%20out%20&amp;summary=&amp;source=http://localhost:8888/soundportal/source/index.php?page=page&amp;page_id=20&quot;); return false; "><i class="fa fa-linkedin"></i><span class="the-tooltip">SHARE ON LINKEDIN</span></a> <a class="social-icon" href="#" onclick="window.dzs_open_social_link(&quot;https://pinterest.com/pin/create/button/?url={{replacewithdataurl}}&amp;text=Check this out!&amp;via=ZoomPortal&amp;related=yarrcat&quot;); return false;"><i class="fa fa-pinterest"></i><span class="the-tooltip">SHARE ON PINTEREST</span></a>';


            window.dzswtl_social_feed_for_share_link = '<h6 class="social-heading">Share Link</h6> <div class="field-for-view field-for-view-link-code">{{replacewithdataurl}}</div>';


            window.dzswtl_social_feed_for_embed_link = ' <h6 class="social-heading">Embed Code</h6> <div class="field-for-view field-for-view-embed-code">{{replacewithembedcode}}</div>';

			<?php


                    if($this->db_mainoptions['convert_search_field_from_theme']){
                        ?>jQuery(document).ready(function($){
                            if($('.dzs-woo-table').length && $('<?php echo $this->db_mainoptions['convert_search_field_from_theme']; ?>').length){

                                var _c = $('<?php echo $this->db_mainoptions['convert_search_field_from_theme']; ?>');

                                _c.attr('name','woo_search');

                                if(_c.parent().get(0) && _c.parent().get(0).nodeName=="FORM"){
                                    _c.parent().on('submit',function(){
                                        return false;
                                    })
                                }
                            }
            });<?php
                    }


			}


			?>
        </script><?php






	}

	function posts_for_current_author($query) {
		global $pagenow;


		// show only own posts

		if( 'edit.php' != $pagenow || !$query->is_admin ){
			return $query;
		}

		if( !current_user_can( 'manage_options' ) ) {
			global $user_ID;
			$query->set('author', $user_ID );
		}
		return $query;
	}


	function login_enqueue_scripts(){

		wp_enqueue_script('jquery');

	}

	function handle_add_meta_boxes(){

//	    echo 'is metaboxes';


        add_meta_box('dzswtl_meta_options', esc_html__('Product shop builder settings','dzswtl'), array($this, 'dzswtl_admin_meta_options'), 'product', 'normal');
    }



    function dzswtl_admin_meta_options() {
        global $post, $wp_version;
        $struct_uploader = '<div class="dzsvg-wordpress-uploader">
<a href="#" class="button-secondary">' . __('Upload', 'dzswtl') . '</a>
</div>';
        //$wp_version = '3.4.1';
        if ($wp_version < 3.5) {
            $struct_uploader = '<div class="dzs-single-upload">
<input id="files-upload" class="" name="file_field" type="file">
</div>';
        }
        ?>
        <div class="dzswtl-meta-con">
            <input type="hidden" name="dzs_nonce" value="<?php echo wp_create_nonce('dzs_nonce'); ?>"/>




            <div class="dzs-setting">
                <?php
                $lab = 'dzswtl_replace_item_link';
                ?>
                <h4><?php echo __('Replace item link ', 'dzswtl'); ?></h4>
                <?php echo DZSHelpers::generate_input_text($lab, array('class' => 'input-big-image main-thumb', 'def_value' => '', 'seekval' => get_post_meta($post->ID, $lab, true))); ?>
                <?php
//                echo $struct_uploader;
                ?>
                <div
                        class='sidenote'><?php echo __('select a thumbnail for the video ( can auto generate if it is an Vimeo or YouTube track )', 'dzswtl'); ?></div>
            </div>

            <div class="dzs-setting">
                <?php
                $lab = 'dzswtl_extra_classes';
                ?>
                <h4><?php echo __('Extra Classes', 'dzswtl'); ?></h4>
                <?php echo DZSHelpers::generate_input_text($lab, array('class' => '', 'def_value' => '', 'seekval' => get_post_meta($post->ID, $lab, true))); ?>
                <div  class='sidenote'><?php echo __('[advanced] some extra classes that you want added to the portfolio item', 'dzswtl'); ?></div>
            </div>

        </div>

        <?php


        wp_enqueue_style('dzsselector', $this->base_url.'libs/dzsselector/dzsselector.css');
        wp_enqueue_script('dzsselector', $this->base_url.'libs/dzsselector/dzsselector.js');
    }




    function handle_edit_post($post_id){

        global $post;

		if(is_admin() && current_user_can('manage_options')==false){
//            die("CANNOT EDIT");
		}


        if (!$post) {
            return;
        }
        /* Check autosave */
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return $post_id;
        }
        if (isset($_REQUEST['dzs_nonce'])) {
            $nonce = $_REQUEST['dzs_nonce'];
            if (!wp_verify_nonce($nonce,'dzs_nonce'))
                wp_die('Security check');
        }
        if (is_array($_POST)) {
            $auxa = $_POST;
            foreach ($auxa as $label => $value) {

                //print_r($label); print_r($value);
                if (strpos($label,'dzswtl_') !== false) {
                    dzs_savemeta($post->ID,$label,$value);
                }
            }
        }
	}

	function handle_admin_menu() {


		global $current_user;




		$admin_cap = $this->capability_admin;

//        echo 'ceva'.$this->addons_dzsvp_activated;


		$dzsvg_page = add_menu_page(__('Shop Builder', 'dzsvg'), __('Shop Builder', 'dzsvg'), $admin_cap, $this->adminpagename_mainoptions, array($this, 'admin_page_mainoptions'), 'div');


	}



	function admin_page_mainoptions() {

//        echo 'ceva';



		include_once "class_parts/admin-page-mainoptions.php";
	}



	function handle_admin_footer(){

		global $post,$pagenow;




//		echo '$pagenow -'.$pagenow;
		if(($pagenow=='edit.php' && isset($_GET['post_type']) && $_GET['post_type'] == 'dzswtl_list_layout') || ($post && $post->post_type=='dzswtl_list_layout')){
			if(( isset($_GET['post']) || $pagenow=='post-new.php') ){







				$the_slug = 'preview-post-1';
				$args = array(
//                'post_name'        => $the_slug,
'post_type'   => 'product',
'post_status'   => 'dzs_preview',
'post_name__in'  => array($the_slug),
'numberposts' => 1,
				);
				$my_posts = get_posts($args);

//            echo 'my_posts - '; print_r($my_posts);
				if( is_array($my_posts) && count($my_posts) > 0) {



				}else{

				    // -- if we don't have preview posts




					$upload_dir = wp_upload_dir();
					$image_data = file_get_contents($this->base_url.'sampledata/sampleimage.png');
					$filename = basename('sampleimage.png');
					if(wp_mkdir_p($upload_dir['path']))     $file = $upload_dir['path'] . '/' . $filename;
					else                                    $file = $upload_dir['basedir'] . '/' . $filename;
					file_put_contents($file, $image_data);

					$wp_filetype = wp_check_filetype($filename, null );
					$attachment = array(
						'post_mime_type' => $wp_filetype['type'],
						'post_title' => sanitize_file_name($filename),
						'post_content' => '',
						'post_status' => 'inherit'
					);


					require_once(ABSPATH . 'wp-admin/includes/image.php');





					$term = wp_insert_term(
						'Preview', // the term
						'product_cat', // the taxonomy
						array(
							'description'=> 'Preview Category',
							'slug' => 'dzs_preview',
							'parent'=> 0
						)
					);

//                echo 'cat - '; print_r($term);

					// Create post object
					$my_post = array(
						'post_title'    => "Preview Post 1",
						'post_content'  => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
						'post_type'   => 'product',
						'post_status'   => 'dzs_preview',
						'post_name'   => 'preview-post-1',
						'post_author'   => 1,
						//                    'post_category' => array( 8,39 )
					);

// Insert the post into the database
					$post_id = wp_insert_post( $my_post );

//                echo 'post_id - '.$post_id;

					wp_set_post_terms( $post_id, array($term['term_id']), 'product_cat' );
//                update_post_meta( $post_id, '_old_price', '10' );
					update_post_meta( $post_id, '_price', '10' );







					$attach_id = wp_insert_attachment( $attachment, $file, $post_id );





					$attach_data = wp_generate_attachment_metadata( $attach_id, $file );
					$res1= wp_update_attachment_metadata( $attach_id, $attach_data );
					$res2= set_post_thumbnail( $post_id, $attach_id );



					// Create post object
					$my_post = array(
						'post_title'    => "Preview Post 2",
						'post_content'  => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
						'post_type'   => 'product',
						'post_status'   => 'dzs_preview',
						'post_name'   => 'preview-post-2',
						'post_author'   => 1,

					);

// Insert the post into the database
					$post_id = wp_insert_post( $my_post );

//                echo 'post_id - '.$post_id;

					wp_set_post_terms( $post_id, array($term['term_id']), 'product_cat' );
//                update_post_meta( $post_id, '_old_price', '15' );
					update_post_meta( $post_id, '_price', '15' );




					$attach_data = wp_generate_attachment_metadata( $attach_id, $file );
					$res1= wp_update_attachment_metadata( $attach_id, $attach_data );
					$res2= set_post_thumbnail( $post_id, $attach_id );
				}




				$arr_data = array();

				if($post->post_content) {
					parse_str($post->post_content, $arr_data);
				}
				?>


                <br>
                <br>
                <div id="listbuilder-con" class="list-builder-con">

                    <div class="dzs-row">
                        <div class="dzs-col-md-3">

                            <div class="admin-builder-block">
                                <div class="admin-builder-head">
                                    <h3 class="admin-builder-head--title"><i class="dzs-round-icon-con"><i class="fa fa-align-justify" aria-hidden="true"></i></i> <span class="the-label">Outline</span></h3>
                                </div>

                                <div class="admin-builder-content">
                                    <div class="builder-layers-con">
                                        <div class="dd" id="nestable3" style="width: 100%; max-width: none; margin: 0 auto;">
                                            <ol class="dd-list builder-layers">

												<?php






												if($arr_data){


													if (isset($arr_data)) {
														$bars = $arr_data['bars'];
//                                                        echo 'bars - '; print_r($bars);
//                                    print_r($bars);
														foreach ($bars as $lab_bar => $val_bar) {

															if(is_numeric($lab_bar)){


//                                                                echo 'lab_bar - '; print_r($lab_bar);

																echo dzswtl_generate_layer_item($val_bar);
															}
														}
													}
												}







												?>

                                            </ol>
                                        </div>
                                    </div>

                                    <div class="add-builder-elements-con">

                                        <span class="add-builder-btn add-element"><i class="fa fa-plus"></i> <?php echo __("Add Element"); ;?></span> &nbsp; &nbsp; <span class="add-builder-btn add-container"><i class="fa fa-circle-o-notch"></i> <?php echo __("Add Container"); ;?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="dzs-col-md-9">

                            <div class="admin-builder-block">
                                <div class="admin-builder-head">
                                    <h3 class="admin-builder-head--title"><i class="dzs-round-icon-con" style="background-color: #0391CE"><i class="fa fa-television" aria-hidden="true" style="margin-left: 1px;"></i></i> <span class="the-label">Preview</span></h3>
                                </div>
                                <div class="admin-builder-content">
                                    <div class="builder-demo-con">
                                    </div>

                                    <div class="wheel-loader">
                                        <div class="wheel-loader--wrap">
                                            <div class="bar1"></div>
                                            <div class="bar2"></div>
                                            <div class="bar3"></div>
                                            <div class="bar4"></div>
                                            <div class="bar5"></div>
                                            <div class="bar6"></div>
                                            <div class="bar7"></div>
                                            <div class="bar8"></div>
                                            <div class="bar7"></div>
                                            <div class="bar8"></div>
                                            <div class="bar9"></div>
                                            <div class="bar10"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <br>
                    <br>
                    <br>
                    <br>
                    <div class="row">
                        <div class="col-md-12">
							<?php
							$mainsettings = array(
								'position_type' => 'relative',
								'pagination_method' => 'scroll',
								'index' => '0',
								'width' => '100%',
								'height' => 'auto',
								'animation_time' => '2000',
								'maxperc' => '100',
								'margin_top' => '0',
								'margin_right' => '0',
								'margin_bottom' => '0',
								'margin_left' => '0',
								'color' => '',
								'background_color' => '#285e8e',
								'type' => 'rect',
								'initon' => 'scroll',
								'maxnr' => '100',
								'arg4_label' => __("Background Color"),
								'arg5_label' => __("Height"),
								'arg6_label' => __("Animation Time"),
								'arg7_label' => '',
								'arg8_label' => '',
								'arg9_label' => '',
							);

							//                       echo '$arr_data - '; print_rr($arr_data);


							$mainsettings = array_merge($mainsettings,$arr_data['bars']['mainsettings']);

							//                        $mainsettings = array_merge();
							?>

                            <div id="tabs-mainsettings" class="dzs-tabs skin-box">


                                <div class="dzs-tab-tobe">
                                    <div class="tab-menu with-tooltip">
                                        <i class="fa fa-file"></i>&nbsp;&nbsp;<?php echo __("General Settings"); ?>
                                    </div>
                                    <div class="tab-content">

                                        <div class="dzs-row">
                                            <div class="dzs-col-md-4">
												<?php
												$lab = 'pagination_method';

												$val = '';

												$val = $mainsettings[$lab];

												?>
                                                <div class="setting">
                                                    <h4 class="setting-label"><?php echo __("Pagination Method"); ?></h4>

													<?php
													echo DZSHelpers::generate_select('bars[mainsettings]['.$lab.']', array(
														'class'=>' builder-field dzs-style-me skin-beige',
														'options'=>array(
															array(
																'label'=>__("Pages"),
																'value'=>'pages',
															),
															array(
																'label'=>__("Infinite Scroll"),
																'value'=>'scroll',
															),
															array(
																'label'=>__("No pagination"),
																'value'=>'none',
															),
														),
														'seekval'=>$val,
													));
													?>
                                                </div>


												<?php
												$lab = 'skin';

												$val = '';

												$val = $mainsettings[$lab];

												?>
                                                <div class="setting">
                                                    <h4 class="setting-label"><?php echo __("Skin"); ?></h4>

													<?php
													echo DZSHelpers::generate_select('bars[mainsettings]['.$lab.']', array(
														'class'=>' builder-field dzs-style-me skin-beige dzs-dependency-field',
														'options'=>array(
															array(
																'label'=>__("No skin"),
																'value'=>'',
															),
															array(
																'label'=>__("Bruma Skin"),
																'value'=>'skin-bruma', // for list zoomsounds
															),
															array(
																'label'=>__("Gamma Skin"),
																'value'=>'skin-gamma', // -- for grid zoomsounds
															),
														),
														'seekval'=>$val,
													));
													?>
                                                </div>


												<?php
												$lab = 'theme';

												$val = '';

												$val = $mainsettings[$lab];




												//											$dependency = array(
												//												array(
												//													'element' => 'bars[mainsettings][skin]',
												//													'value' => array('skin-bruma'),
												//												),
												//											);

												?>
                                                <div class="setting"  >
                                                    <h4 class="setting-label"><?php echo __("Theme"); ?></h4>

													<?php
													echo DZSHelpers::generate_select('bars[mainsettings]['.$lab.']', array(
														'class'=>' builder-field dzs-style-me skin-beige',
														'options'=>array(
															array(
																'label'=>__("Default"),
																'value'=>'',
															),
															array(
																'label'=>__("Theme Dark"),
																'value'=>'theme-dark',
															),
															array(
																'label'=>__("Theme Light"),
																'value'=>'theme-light', // for list zoomsounds
															),

														),
														'seekval'=>$val,
													));
													?>
                                                </div>


												<?php
												$lab = 'layout_mode';

												$val = '';

												$val = $mainsettings[$lab];

												?>
                                                <div class="setting">
                                                    <h4 class="setting-label"><?php echo __("Layout Mode"); ?></h4>

													<?php
													echo DZSHelpers::generate_select('bars[mainsettings]['.$lab.']', array(
														'extraattr'=>' data-label="'.$lab.'"',
														'class'=>' builder-field dzs-style-me skin-beige dzs-dependency-field',
														'options'=>array(
															array(
																'label'=>__("List"),
																'value'=>'list',
															),
															array(
																'label'=>__("Grid"),
																'value'=>'grid',
															),
														),
														'seekval'=>$val,
													));
													?>
                                                </div>


												<?php
												$lab = 'layout_mode_grid_cols';

												$val = 'dzs-layout--3-cols';


												if(isset($mainsettings[$lab]) && $mainsettings[$lab]){

													$val = $mainsettings[$lab];
												}







												$dependency = array(
													array(
														'element' => 'layout_mode',
														'value' => array('grid'),
													),
												);





												?>
                                                <div class="setting  check-label check-parent1"  data-dependency='<?php echo json_encode($dependency); ?>' >
                                                    <h4 class="setting-label"><?php echo __("Number of Columns"); ?></h4>

													<?php
													echo DZSHelpers::generate_select('bars[mainsettings]['.$lab.']', array(
														'extraattr'=>' data-label="'.$lab.'"',
														'class'=>' builder-field dzs-style-me skin-beige',
														'options'=>array(
															array(
																'label'=>__("One Columns"),
																'value'=>'dzs-layout--1-cols',
															),
															array(
																'label'=>__("Two Columns"),
																'value'=>'dzs-layout--2-cols',
															),
															array(
																'label'=>__("Three Columns"),
																'value'=>'dzs-layout--3-cols',
															),
															array(
																'label'=>__("Four Columns"),
																'value'=>'dzs-layout--4-cols',
															),
															array(
																'label'=>__("Five Columns"),
																'value'=>'dzs-layout--5-cols',
															),
														),
														'seekval'=>$val,
													));
													?>
                                                </div>






                                                <?php

                                                $lab = 'grid_mode';

                                                $val = 'normal';


                                                if(isset($mainsettings[$lab]) && $mainsettings[$lab]){

	                                                $val = $mainsettings[$lab];
                                                }

                                                ?>

                                                <div class="setting  check-label check-parent1"  data-dependency='<?php echo json_encode($dependency); ?>' >
                                                    <h4 class="setting-label"><?php echo esc_html__("Grid mode",'dzswtl'); ?></h4>

		                                            <?php
		                                            echo DZSHelpers::generate_select('bars[mainsettings]['.$lab.']', array(
			                                            'extraattr'=>' data-label="'.$lab.'"',
			                                            'class'=>' builder-field dzs-style-me skin-beige',
			                                            'options'=>array(
				                                            array(
					                                            'label'=>__("Normal"),
					                                            'value'=>'normal',
				                                            ),
				                                            array(
					                                            'label'=>__("Masonry"),
					                                            'value'=>'masonry',
				                                            ),
				                                            array(
					                                            'label'=>__("Horizontal scroller"),
					                                            'value'=>'scroller',
				                                            ),
			                                            ),
			                                            'seekval'=>$val,
		                                            ));
		                                            ?>
                                                </div>

												<?php
												$lab = 'layout_mode_grid_cols_gap';

												$val = '';


												if(isset($mainsettings[$lab]) && $mainsettings[$lab]){

													$val = $mainsettings[$lab];
												}




												?>
                                                <div class="setting  check-label check-parent1"  data-dependency='<?php echo json_encode($dependency); ?>' >
                                                    <h4 class="setting-label"><?php echo __("Column padding"); ?></h4>

													<?php
													echo DZSHelpers::generate_select('bars[mainsettings]['.$lab.']', array(
														'extraattr'=>' data-label="'.$lab.'"',
														'class'=>' builder-field dzs-style-me skin-beige',
														'options'=>array(
															array(
																'label'=>esc_html__("default",'dzswtl'),
																'value'=>'',
															),
															array(
																'label'=>sprintf(esc_html__("%s pixel",'dzswtl'),'1'),
																'value'=>'1',
															),
															array(
																'label'=>sprintf(esc_html__("%s pixels",'dzswtl'),'10'),
																'value'=>'10',
															),
															array(
																'label'=>sprintf(esc_html__("%s pixels",'dzswtl'),'30'),
																'value'=>'30',
															),

														),
														'seekval'=>$val,
													));
													?>
                                                </div>
                                            </div>


                                            <div class="dzs-col-md-4">
												<?php
												$lab = 'item_align';

												$val = '';

												$val = $mainsettings[$lab];

												?>
                                                <div class="setting">
                                                    <h4 class="setting-label"><?php echo __("Item Align"); ?></h4>

													<?php
													echo DZSHelpers::generate_select('bars[mainsettings]['.$lab.']', array(
														'class'=>' builder-field dzs-style-me skin-beige',
														'options'=>array(
															array(
																'label'=>__("Default Align"),
																'value'=>'',
															),
															array(
																'label'=>__("Left"),
																'value'=>'left',
															),
															array(
																'label'=>__("Center"),
																'value'=>'center',
															),
															array(
																'label'=>__("Right"),
																'value'=>'right',
															),
														),
														'seekval'=>$val,
													));
													?>
                                                </div>
												<?php
												$lab = 'item_text_align';

												$val = '';

												$val = $mainsettings[$lab];

												?>
                                                <div class="setting">
                                                    <h4 class="setting-label"><?php echo __("Text Align"); ?></h4>

													<?php
													echo DZSHelpers::generate_select('bars[mainsettings]['.$lab.']', array(
														'class'=>' builder-field dzs-style-me skin-beige',
														'options'=>array(
															array(
																'label'=>__("Default Align"),
																'value'=>'',
															),
															array(
																'label'=>__("Left"),
																'value'=>'left',
															),
															array(
																'label'=>__("Center"),
																'value'=>'center',
															),
															array(
																'label'=>__("Right"),
																'value'=>'right',
															),
														),
														'seekval'=>$val,
													));
													?>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="clear"></div>



                                        <div class="">
                                            <h4>Shortcode:</h4>
                                            <pre>[dzs_woo_table layout="<?php  echo $post->post_name; ?>" show_filtered_by="on" posts_per_page="6"]</pre>
                                        </div>

                                    </div>


                                </div>






                            </div>
                            <br>

                        </div>
                    </div>

                    <h2 class="hndle ui-sortable-handle"><span>Publish</span></h2>



                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                </div>

				<?php

			}else{


			    // -- else we can import demos

                ?><div class="dzswtl-import-layout-con">
                    <h2>Import layout</h2>
                    <div class="dzs-row" style="max-width: 95%;">
                        <?php
                        $lab = 'e-auto-trading';
                        ?>
                        <div class="dzs-col-md-4"><div class="divimage fullwidth dzswtl-import-layout " data-layout-name="<?php echo $lab; ?>" style="background-image: url(<?php echo $this->base_url; ?>sampledata/img/<?php echo $lab; ?>.jpg)"></div></div>
                        <?php
                        $lab = 'e-chairs';
                        ?>
                        <div class="dzs-col-md-4"><div class="divimage fullwidth dzswtl-import-layout " data-layout-name="<?php echo $lab; ?>" style="background-image: url(<?php echo $this->base_url; ?>sampledata/img/<?php echo $lab; ?>.jpg)"></div></div>
                        <?php
                        $lab = 'e-list-shop';
                        ?>
                        <div class="dzs-col-md-4"><div class="divimage fullwidth dzswtl-import-layout " data-layout-name="<?php echo $lab; ?>" style="background-image: url(<?php echo $this->base_url; ?>sampledata/img/<?php echo $lab; ?>.jpg)"></div></div>
                    </div>
                        <div class="dzs-row" style="max-width: 95%;">
                        <?php
                        $lab = 'e-electric-laptops';
                        ?>
                        <div class="dzs-col-md-4"><div class="divimage fullwidth dzswtl-import-layout " data-layout-name="<?php echo $lab; ?>" style="background-image: url(<?php echo $this->base_url; ?>sampledata/img/<?php echo $lab; ?>.jpg)"></div></div>
                        <?php
                        $lab = 'e-fashion-shop';
                        ?>
                        <div class="dzs-col-md-4"><div class="divimage fullwidth dzswtl-import-layout " data-layout-name="<?php echo $lab; ?>" style="background-image: url(<?php echo $this->base_url; ?>sampledata/img/<?php echo $lab; ?>.jpg)"></div></div>
                        <?php
                        $lab = 'e-listar';
                        ?>
                        <div class="dzs-col-md-4"><div class="divimage fullwidth dzswtl-import-layout " data-layout-name="<?php echo $lab; ?>" style="background-image: url(<?php echo $this->base_url; ?>sampledata/img/<?php echo $lab; ?>.jpg)"></div></div>
                    </div>
                        <div class="dzs-row" style="max-width: 95%;">

                        <?php
                        $lab = 'e-pro-sounds';
                        ?>
                        <div class="dzs-col-md-4"><div class="divimage fullwidth dzswtl-import-layout " data-layout-name="<?php echo $lab; ?>" style="background-image: url(<?php echo $this->base_url; ?>sampledata/img/<?php echo $lab; ?>.jpg)"></div></div>

                        <?php
                        $lab = 'e-real-estate';
                        ?>
                        <div class="dzs-col-md-4"><div class="divimage fullwidth dzswtl-import-layout " data-layout-name="<?php echo $lab; ?>" style="background-image: url(<?php echo $this->base_url; ?>sampledata/img/<?php echo $lab; ?>.jpg)"></div></div>
                        <?php
                        $lab = 'e-audio-wave';
                        ?>
                        <div class="dzs-col-md-4"><div class="divimage fullwidth dzswtl-import-layout " data-layout-name="<?php echo $lab; ?>" style="background-image: url(<?php echo $this->base_url; ?>sampledata/img/<?php echo $lab; ?>.jpg)"></div></div>
                        </div>
                <div class="dzs-row" style="max-width: 95%;">
                        <?php
                        $lab = 'e-audio-grid';
                        ?>
                        <div class="dzs-col-md-4"><div class="divimage fullwidth dzswtl-import-layout " data-layout-name="<?php echo $lab; ?>" style="background-image: url(<?php echo $this->base_url; ?>sampledata/img/<?php echo $lab; ?>.jpg)"></div></div>
                        <?php
                        $lab = 'e-charts';
                        ?>
                        <div class="dzs-col-md-4"><div class="divimage fullwidth dzswtl-import-layout " data-layout-name="<?php echo $lab; ?>" style="background-image: url(<?php echo $this->base_url; ?>sampledata/img/<?php echo $lab; ?>.jpg)"></div></div>
                    </div>
                    </div>
                </div><div class="feedbacker">Loading..</div><?php
            }

		}



	}
	function handle_admin_head(){



		global $pagenow, $post;

//        echo $pagenow;








		echo '<script>window.dzswtl_settings = { base_url: "'.$this->base_url.'",version: "'.DZSWTL_VERSION.'",site_url : "'.site_url().'",translate_add_filter: "'.esc_html__("Add filter",'dzswtl').'",translate_add_shortcode: "'.esc_html__("Add shop",'dzswtl').'"';


		if($post){
			echo ',post_type:"'.$post->post_type.'"';
		}
		if(1){
			echo ',shortcode_generator_url:"'.admin_url('admin.php?page='.$this->adminpagename_mainoptions).'&dzswtl_shortcode_generator=on'.'"';
		}
		if(1){
			echo ',filter_generator_url:"'.admin_url('admin.php?page='.$this->adminpagename_mainoptions).'&dzswtl_filter_generator=on'.'"';
		}
		if(1){
			echo ',con_shortcode_generator_url:"'.admin_url('admin.php?page='.$this->adminpagename_mainoptions).'&dzswtl_con_shortcode_generator=on'.'"';
		}
		if(1){
			echo ',generate_layout_item_default_margs:\''.json_encode($this->generate_layout_item_default_margs).'\'';
		}

		if($post && $post->post_type=='dzswtl_list_layout'){


			$struct_item_default = str_replace(array("\r","\r\n","\n"),'',dzswtl_generate_layer_item());
			$struct_item_element = str_replace(array("\r","\r\n","\n"),'',dzswtl_generate_layer_item(array('type' => 'element','background_color' => 'transparent','text' => 'insert text here','height' => 'auto')));
			$struct_item_container = str_replace(array("\r","\r\n","\n"),'',dzswtl_generate_layer_item(array('type' => 'container','background_color' => 'transparent','height' => 'auto')));



			?>
            , struct_layer_element: `<?php echo $struct_item_element; ?>`
            , struct_layer_container: `<?php echo $struct_item_container; ?>`
			<?php
		}

		echo ' };';
		echo '  </script>';


//        add_filter('user_can_richedit', array($this, 'disable_wyswyg_for_custom_post_type'));

		if($post && $post->post_type=='dzswtl_list_layout'){

//            wp_enqueue_script('jquery-ui-core');
//            wp_enqueue_script('jquery-ui-sortable');
//            wp_enqueue_script('jquery-ui-mouse');
//            wp_enqueue_script('jquery-ui-slider');

			add_filter('user_can_richedit', '__return_false', 50);

			wp_enqueue_script('jquery.nestable.js',$this->base_url.'libs/listbuilder/jquery.nestable.js');

			wp_enqueue_script('gridbuilder', $this->base_url . 'libs/gridbuilder/gridbuilder.js');
			wp_enqueue_style('gridbuilder', $this->base_url . 'libs/gridbuilder/gridbuilder.css');


			wp_enqueue_style('dzswtl', $this->base_url . "libs/dzswootable/dzswootable.css");
			wp_enqueue_script('dzswtl', $this->base_url . "libs/dzswootable/dzswootable.js");

			wp_enqueue_script('spectrum', $this->base_url . 'libs/spectrum/spectrum.js');
			wp_enqueue_style('spectrum', $this->base_url . 'libs/spectrum/spectrum.css');

			wp_enqueue_script('listbuilder', $this->base_url . 'libs/listbuilder/listbuilder.js');
			wp_enqueue_style('listbuilder', $this->base_url . 'libs/listbuilder/listbuilder.css');

			wp_enqueue_script('dzstaa', $this->base_url . 'libs/dzstabsandaccordions/dzstabsandaccordions.js');
			wp_enqueue_style('dzstaa', $this->base_url . 'libs/dzstabsandaccordions/dzstabsandaccordions.css');
//            wp_enqueue_script('dzstooltip', $this->base_url . 'libs/dzstooltip/dzstooltip.js');
			wp_enqueue_style('dzstooltip', $this->base_url . 'libs/dzstooltip/dzstooltip.css');
			wp_enqueue_script('dzsselector', $this->base_url . 'libs/dzsselector/dzsselector.js');
			wp_enqueue_style('dzsselector', $this->base_url . 'libs/dzsselector/dzsselector.css');
			wp_enqueue_style('dzstoggle', $this->base_url . 'libs/dzstoggle/dzstoggle.css');
			wp_enqueue_script('dzstoggle', $this->base_url . "libs/dzstoggle/dzstoggle.js");



			$fontawesomelink = $this->base_url . 'libs/fontawesome/font-awesome.min.css';
			if(defined("DZSWTL_USE_FONTAWESOME_FROM_CDN") && DZSWTL_USE_FONTAWESOME_FROM_CDN=="ON"){
				$fontawesomelink = 'https://'.'maxcdn'.'bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css';
			}

			wp_enqueue_style( 'fontawesome', $fontawesomelink);




			global $dzsap;

			if($dzsap){
			    try{

				    wp_enqueue_style('dzsap', $dzsap->base_url . 'audioplayer/audioplayer.css');
				    wp_enqueue_script('dzsap', $dzsap->base_url . "audioplayer/audioplayer.js");




			    }catch(Exception $e){

                }
            }

//            echo 'ceva';

		}

	}

















	function handle_current_screen() {

		if(is_admin() && current_user_can('manage_options')==false){
			$url = get_current_screen();

//            echo 'url - '; print_r($url);

			$sw = false;



			if($url->base=='edit-tags'){
				$sw = true;
			}
			if($url->base=='post'){
//                $sw = true;
			}
			if($url->base=='upload'){
				$sw = true;
			}
			if($url->base=='profile'){
				$sw = true;
			}
			if($url->base=='edit-comments'){
				$sw = true;
			}



			if($sw){
				die(' DEMO MODE - You do not have access to this page, <a href="'.admin_url().'">return back to dashboard</a>  ');
			}
		}



	}
	function handle_admin_notices(){

	}


}