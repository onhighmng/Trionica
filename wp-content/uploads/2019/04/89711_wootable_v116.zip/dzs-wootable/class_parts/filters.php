<?php


//echo '$pargs init -'; print_rr($pargs);

$margs = array(

	'title'=>'filter', // -- not used
	'feed_from'=>'categories', // -- categories or price or ratings or custom-attribute or custom-taxonomy or custom-meta
	'type'=>'detect', // slider or select or multiple or input ?
	'slider_min'=>'0',
	'slider_max'=>'300',
	'slider_step'=>'1',
	'custom_meta_values'=>'',
	'categories_type'=>'',
	'show_curr_selected'=>'off', // -- show the current selected filter


	'left_label'=>'',
	'parent'=>'',


	'label_all'=>esc_html__("All",'dzswtl'),
	'label_auto_empty'=>esc_html__("Select first",'dzswtl'),


	'custom_taxonomy_name'=>"",
	'term_parent'=>"",

	'flex_align'=>"",

	'flex_prop'=>"",
	'margin_left'=>"",
	'margin_right'=>"",
	'extra_classes'=>"",

	'include_count'=>"off",
	'type_select_style'=>"default", // -- default or coronae
	'type_multiple_style'=>"default", // -- default or checkbox-search

	'the_name'=>"", // -- custom name, will overwrite auto name

);

if(is_array($pargs)===false){
	$pargs = array();
}
$margs = array_merge($margs, $pargs);

//       echo 'margs init -'; print_rr($margs);


$left_label_set = false;


$index_filter = $this->index_filter;




$options = array();

$lab = 'default';
$lab_sanitized = 'default';
$seekval = '';

if($margs['the_name']){
	if($lab=='default'){
		$lab = $margs['the_name'];
	}
	if($lab_sanitized=='default'){
		$lab_sanitized = $margs['the_name'];
	}
}

if($margs['feed_from']=='categories'){

//	print_rr($margs);


	// -- we will force type to multiple for now
//	$margs['type']='multiple';


//	echo 'margs - '; print_rr($margs);
	if($lab=='default'){
		$lab = 'cat';
	}
	if($lab_sanitized=='default'){
		$lab_sanitized = 'cat';
	}

	$tax_name = 'product_cat';

	$args = array(
		'orderby' => 'name',
		'order'   => 'ASC',
		'taxonomy'   => $tax_name,
	);


	if($margs['term_parent']!==''){

		if($margs['term_parent']){
			$args['parent']=$this->sanitize_term_slug_to_id($margs['term_parent'],'product_cat');

		}
	}




	if($margs['term_parent']==='auto'){

		if($lab=='cat[]'){
			$lab = 'subcat[]';
		}
		if($lab_sanitized=='cat' || $lab_sanitized=='default'){
			$lab_sanitized = 'subcat';
		}

		$margs['original_term_parent']=$margs['term_parent'];


		if(isset($_GET['cat']) && $_GET['cat']){
			$args['parent'] = $this->sanitize_term_slug_to_id($_GET['cat'],'product_cat');
		}

//		print_rr($margs);
	}

//	echo '$args - '; print_rr($args);
	$categories = get_categories($args);

//	echo 'categories - '; print_rr($categories);



	if($margs['categories_type']=='category-thumb'){

		$margs['type']='single-with-image';



	}


	foreach( $categories as $cat ) {


//                    print_rr($cat);

//                    $lab = 'cat[]';


		if(isset($_GET) && is_array($_GET) && count($_GET)>0){

			if(isset($_GET[$lab_sanitized])){

				$cats = $_GET[$lab_sanitized];
				if(strpos($_GET[$lab_sanitized],'%252C')!==false){

					$cats=str_replace('%252C', ',', $_GET[$lab_sanitized]);


				}

				if(strpos($_GET[$lab_sanitized],'%2C')!==false){

					$cats=str_replace('%2C', ',', $_GET[$lab_sanitized]);

				}
				$cats=explode(',',$cats);
				$seekval=$cats;
			}
		}


		$aux = array(
			'label'=>$cat->name,
			'value'=>$cat->slug,
		);

		array_push($options, $aux);


	}

//	echo '$options - '; print_rr($options);
}


if($margs['feed_from']=='price'){

	$margs['type']='slider';

	if($lab=='default'){

		$lab = 'price';
	}
	$lab_sanitized = $lab;


}





// -- generate



if($margs['feed_from']=='ratings'){

	$margs['type']='none';

	if($lab=='default') {
		$lab = 'rating';
	}
	$lab_sanitized = $lab;




	wp_enqueue_script('dzsselector', $this->base_url . 'libs/dzsselector/dzsselector.js');
	wp_enqueue_style('dzsselector', $this->base_url . 'libs/dzsselector/dzsselector.css');


}

$attribute_type = '';


// -- filter custom attribute
if($margs['feed_from']=='custom-attribute'){

//                $margs['type']='multiple';




//            print_rr($margs);


	$tax_name = $margs['custom_attr_name'];

	if($lab_sanitized=='default'){

		$lab_sanitized = $margs['custom_attr_name'];
	}
	$lab = $margs['custom_attr_name'].'[]';



	$tax = get_taxonomy($tax_name);






	$attribute_taxonomies = null;


	if(function_exists('wc_get_attribute_taxonomies')){

		$attribute_taxonomies = wc_get_attribute_taxonomies();
	}




	$attribute_type='text';



	if($attribute_taxonomies){
		foreach ($attribute_taxonomies as $atax){
			if('pa_'.$atax->attribute_name==$lab_sanitized){

				$attribute_type = $atax->attribute_type;
			}
		}
	}





	$args = array(
		'hide_empty' => false,
	);


	if($margs['parent']){
		$args['parent'] = $margs['parent'];
	}


	$categories = get_terms( $tax_name, $args );








	if(isset($this->sanitized_get) && is_array($this->sanitized_get) && count($this->sanitized_get)>0){


		if(isset($this->sanitized_get[$lab_sanitized])){

			$cats = $this->sanitized_get[$lab_sanitized];
			if(strpos($this->sanitized_get[$lab_sanitized],'%252C')!==false){

				$cats=str_replace('%252C', ',', $this->sanitized_get[$lab_sanitized]);


			}

			if(strpos($this->sanitized_get[$lab_sanitized],'%2C')!==false){

				$cats=str_replace('%2C', ',', $this->sanitized_get[$lab_sanitized]);

			}
			$cats=explode(',',$cats);
			$seekval=$cats;
		}
	}






	// -- custom taxonomy
	foreach( $categories as $cat ) {


		$aux = array(
			'label'=>$cat->name,
			'value'=>$cat->slug,
			'term_id'=>$cat->term_id,
		);

//		echo ' cat - '; print_rr($cat);

		$aux['count'] = $cat->count;



		if($attribute_type=='color'){
//                        print_r($cat);

			$aux['meta_color'] = get_term_meta($cat->term_id,'color',true);
		}

//		print_rr($cat);

		array_push($options, $aux);
	}

}



if($margs['feed_from']=='custom-taxonomy'){

//                $margs['type']='multiple';




	$tax_name = $margs['custom_taxonomy_name'];
	$lab_sanitized = 'customtax_'.$margs['custom_taxonomy_name'];
	$lab = 'customtax_'.$margs['custom_taxonomy_name'].'[]';



	$tax = get_taxonomy($tax_name);





//                print_rr($tax);


	$categories = get_terms( $tax_name, array(
		'hide_empty' => false,
	) );









	if(isset($_GET) && is_array($_GET) && count($_GET)>0){


		if(isset($_GET[$lab_sanitized])){

			$cats = $_GET[$lab_sanitized];
			if(strpos($_GET[$lab_sanitized],'%252C')!==false){

				$cats=str_replace('%252C', ',', $_GET[$lab_sanitized]);


			}

			if(strpos($_GET[$lab_sanitized],'%2C')!==false){

				$cats=str_replace('%2C', ',', $_GET[$lab_sanitized]);

			}
			$cats=explode(',',$cats);
			$seekval=$cats;


		}
	}

//            echo 'seekval - '.$seekval;
//            echo '$lab_sanitized - '.$lab_sanitized;






	// -- custom taxonomy
	foreach( $categories as $cat ) {


		$aux = array(
			'label'=>$cat->name,
			'value'=>$cat->slug,
			'term_id'=>$cat->term_id,
		);

//		echo ' cat - '; print_rr($cat);

		$aux['count'] = $cat->count;
		if($attribute_type=='color'){
//                        print_r($cat);

			$aux['meta_color'] = get_term_meta($cat->term_id,'color',true);
		}


		array_push($options, $aux);
	}

}

if($margs['feed_from']=='custom-meta'){

//                $margs['type']='multiple';


//                $fout.=print_rrr($margs);

	$tax_name = $margs['custom_meta_name'];




	$lab = 'meta_value_'.$margs['custom_meta_name'];
	$lab_sanitized = $lab;
//                        $iout.=print_rrr(get_post_meta_all($po->ID));


//                        $tax_name = 'pa_color';
	$meta_name = $margs['custom_meta_name'];



	$attr_data_str = $margs['custom_meta_values'];





	$tax = get_taxonomy($tax_name);






	if(isset($_GET) && is_array($_GET) && count($_GET)>0){


		$val = $_GET[$lab_sanitized];


		if(isset($_GET[$lab_sanitized])){

			$cats = $_GET[$lab_sanitized];
			if(strpos($_GET[$lab_sanitized],'%252C')!==false){

				$cats=str_replace('%252C', ',', $_GET[$lab_sanitized]);


			}

			if(strpos($_GET[$lab_sanitized],'%2C')!==false){

				$cats=str_replace('%2C', ',', $_GET[$lab_sanitized]);

			}
			$cats=explode(',',$cats);
			$seekval=$cats;
		}
	}





	$categories = explode(',',$margs['custom_meta_values']);


	// -- custom meta
	if(is_array($categories) && count($categories)){

		foreach( $categories as $cat ) {


//			echo ' cat - '; print_rr($cat);
			$aux = array(
				'label'=>$cat,
				'value'=>$cat,
			);

			array_push($options, $aux);
		}
	}

}






if($margs['type']!='single-with-image') {

	// -- y do we need  form ?

}



// -- we start to display the shortcode

if($margs['type']=='' || $margs['type']=='detect'){
	$margs['type'] = 'multiple';
}

//echo 'margs - '; print_rr($margs);
if($margs['type']=='slider' ){


//	print_rr($margs);
	// -- if it's slider we force product attribute to meta
	if(strpos($lab,'pa_')===0){
		$lab = 'meta_value_metapa_'.$lab;
	}


	if(strpos($lab_sanitized,'pa_')===0){
		$lab_sanitized = 'meta_value_metapa_'.$lab_sanitized;
	}


//	print_rr($margs);



	// -- why we need [] on slider ?
	$lab = str_replace('[]','',$lab);
	$lab_sanitized = str_replace('[]','',$lab_sanitized);
}



// -- finish labs




// -- start to generate $fout



$fout.='<div class="dzs-woo-filter';


if($margs['type']=='select'){

	$fout.=' select-style-'.$margs['type_select_style'];
}
if($margs['type']=='multiple'){

	$fout.=' multiple-style-'.$margs['type_multiple_style'];
}

if($margs['flex_align']){
	$fout.=' flex-align-'.$margs['flex_align'];
}
if($margs['flex_prop']){
	$fout.=' flex-prop-'.$margs['flex_prop'];
}

if($margs['extra_classes']){
	$fout.=' '.$margs['extra_classes'];
}
//print_rr($margs);

$fout.='"';


  if($margs['custom_taxonomy_name']){
	$fout.=' data-lab-sanitized="'.$lab_sanitized.'"';
}

$fout.=' style="';




$fout.=$this->generate_style_for_flex($margs);



$fout.='">';


if($margs['feed_from']=='ratings'){
	$fout.='<select class="dzs-style-me dzs-woo-table-filter-input  opener-listbuttons option-display-block skin-checkbox do-not-trigger-change-on-init do-not-trigger-change-on-reinit" name="'.$lab_sanitized.'">
                            <option value="">no rating</option>
                            <option value="5">5</option>
                            <option value="4">4</option>
                            <option value="3">3</option>
                            <option value="2">2</option>
                            <option value="1">1 star</option>
                        </select>
                        <ul class="dzs-style-me-feeder">

                            <li class="bigoption">
                                <span class="option-con" style="  padding-top: 5px;  padding-bottom: 5px;">
                                    &nbsp;&nbsp;<strong>'.__("All ratings").'</strong>

                                </span>
                            </li>

                            <li class="bigoption">

                                <span class="option-con">
                                    <span class="star-rating-con">
                                        <span class="rating-bg"><span class="rating-inner">{{starssvg}}</span></span>
                                    <span class="rating-prog" style="width: 100%;"><span class="rating-inner">{{starssvg}}</span>
                                    </span>
                                    </span>

                                </span>
                            </li>

                            <li class="bigoption">

                                <span class="option-con">
                                    <span class="star-rating-con">
                                        <span class="rating-bg"><span class="rating-inner">{{starssvg}}</span></span>
                                    <span class="rating-prog" style="width: 80%;"><span class="rating-inner">{{starssvg}}</span>
                                    </span>
                                    </span>

                                </span>
                            </li>

                            <li class="bigoption">

                                <span class="option-con">
                                    <span class="star-rating-con">
                                        <span class="rating-bg"><span class="rating-inner">{{starssvg}}</span></span>
                                    <span class="rating-prog" style="width: 60%;"><span class="rating-inner">{{starssvg}}</span>
                                    </span>
                                    </span>

                                </span>
                            </li>

                            <li class="bigoption">

                                <span class="option-con">
                                    <span class="star-rating-con">
                                        <span class="rating-bg"><span class="rating-inner">{{starssvg}}</span></span>
                                    <span class="rating-prog" style="width: 40%;"><span class="rating-inner">{{starssvg}}</span>
                                    </span>
                                    </span>

                                </span>
                            </li>

                            <li class="bigoption">
                                <span class="option-con">
                                    <span class="star-rating-con">
                                        <span class="rating-bg"><span class="rating-inner">{{starssvg}}</span></span>
                                    <span class="rating-prog" style="width: 20%;"><span class="rating-inner">{{starssvg}}</span></span>
                                    </span>

                                </span>
                            </li>
                        </ul>';
}


;




wp_enqueue_script('dzsselector', $this->base_url . 'libs/dzsselector/dzsselector.js');
wp_enqueue_style('dzsselector', $this->base_url . 'libs/dzsselector/dzsselector.css');







// -- here we have the woo-feed filter

$fout.= '<div class="dzs-woo-feed dzs-woo-feed-filter-from';




$fout.='" data-dzs-woo-feed-lab="'.$lab_sanitized.'" data-dzs-woo-feed-type="'.$margs['type'].'" data-dzs-woo-term-parent="'.$margs['term_parent'];




        $fout.='" ></div>';

if($margs['left_label'] && $left_label_set==false){

	$fout.='<span class="woo-filter-slider--label">';
	$fout.=$margs['left_label'];
	$fout.='</span>';

	$left_label_set = true;
}


if($margs['type']=='single-with-image'){




//			print_rr($margs);
	foreach ($options as $opt){


		$classes = '';



		$fout.= '<div class="dzs-woo-table-filter-for-click';



		if(isset($_GET) && is_array($_GET) && count($_GET)>0){


//				    print_rr($_GET);
//				    print_rr($lab_sanitized);
			if(isset($_GET[$lab_sanitized])){


//					    echo 'ceva'.$_GET[$lab_sanitized].' - '.$opt['value'].'|||';
				if($_GET[$lab_sanitized]==$opt['value']){

					$fout.= ' active';
				}
			}
		}



		$fout.='" data-term-slug="'.$opt['value'].'">';




		$term_id = $opt['value'];




		$term_id = '';


		if(is_numeric($opt['value'])){
			$term_id = $opt['value'];
		}else{

			$term = get_term_by('slug',$opt['value'],'product_cat');

//			print_rr($term);
			$term_id = $term->term_id;
		}


		$term_meta_all = get_term_meta($term_id);

//		echo 'term meta for '.$term_id.' - '; print_rr($term_meta_all);



		$thumb_id = get_term_meta($term_id, 'thumbnail_id',true);

		if($thumb_id==''){

			$thumb_id = get_term_meta($term_id, 'product_cat_thumbnail',true);
		}
		if($thumb_id==''){

			$thumb_id = get_term_meta($term_id, 'image',true);
		}

		if($thumb_id){

			$thumb_src = $this->sanitize_id_to_src($thumb_id);
			$fout.= '<span class="dzs-woo-table-filter-for-click--image divimage" style="background-image: url('.$thumb_src.'); ">';

			$fout.= '</span>';
		}



		$fout.= '<span class="dzs-woo-table-filter-for-click--label">';
		$fout.= $opt['label'];
		$fout.= '</span>';


		$fout.= '</div>';

	}

}




if($margs['type']=='multiple'){


	// -- multiple type




	if($margs['type_multiple_style']=='checkbox-search'){
$fout.='<div class="dzs-style-me type-checkbox skin-beige opener-list opener-list-absolute">';


		// -- multiple label all

//		print_rr($this->all_checks);
//		print_rr($margs);
//		echo '$lab - '.$lab;
//		echo '$lab_sanitized - '.$lab_sanitized;
		if($margs['show_curr_selected']=='on'){

			$fout.='<div class="feed-dzswtl label--multiple label-curr-selected" hidden aria-hidden="true" style="">';

			if(isset($this->all_checks[$lab_sanitized])){
				$fout.=$this->all_checks[$lab_sanitized];
			}

			$fout.='</div>';
		}
		$fout.='<div class="feed-dzswtl label--multiple label-all" style="display:none;">'.$margs['label_all'].'</div>';
		$fout.='<div class="feed-dzswtl label--multiple label-auto-empty" hidden aria-hidden="true">'.$margs['label_auto_empty'].'</div>';


$fout.='
<div class="dzs-style-me-feeder">';
	}


	if($attribute_type=='color'){

//                        print_r($opt);


		$fout.='<div class="dzs-checkbox-selector skin-colornova">';
	}



	foreach ($options as $opt){


		$classes = '';

//		print_rr($opt);


		$count = '';


		if(isset( $opt['count'] ) && $opt['count'] !== ''){
			$count = $opt['count'];
		}

		// -- TODO: maybe conver color to multiple type someday ?
		if($attribute_type!='color') {
			$fout .= '<div class="multiple-option';






			if(isset($this->all_checks[$lab_sanitized])){
				if($opt['value'] == $this->all_checks[$lab_sanitized]){
					$fout.=' active';
				}
			}


			$fout.='" ';

//			print_rr($opt);
			if(isset($opt['value']) && $opt['value']){
				$fout.=' data-term_slug="'.$opt['value'].'"';
			}
			if(isset($opt['term_id']) && $opt['term_id']){
				$fout.=' data-term_id="'.$opt['term_id'].'"';
			}
			if($count!==''){
				$fout.=' data-count="'.$count.'"';
			}

			$fout.='>';
		}
		$fout.= '<label ';


		if(isset($opt['value']) && $opt['value']){
			$fout.=' data-term_slug="'.$opt['value'].'"';
		}
		if(isset($opt['term_id']) && $opt['term_id']){
			$fout.=' data-term_id="'.$opt['term_id'].'"';
		}
		if($count!==''){
			$fout.=' data-count="'.$count.'"';
		}

		$fout.='>';

		$args =array(
			'input_type'=>'checkbox',
			'val'=>$opt['value'],
			'class'=>'dzs-woo-table-filter-input '.$classes,
		);


		$args['seekval']=$seekval;

		$fout.= DZSHelpers::generate_input_checkbox($lab, $args);

		$fout.=' ';



		if($attribute_type!='color') {

			// -- the label in multiple
			$fout .= '<span class="the-label"><span class="the-label--name">' . $opt['label'].'</span>';


			if ( $margs['include_count']=='on' &&$count!=='' ) {

				$fout .= ' <span class="the-count">(<span class="the-actual-count" data-original-count="'.$opt['count'].'">' . $opt['count'] . '</span>)</span>';
			}

			$fout .= '</span>';
			// -- end .the-label
		}

		if($attribute_type=='color'){
			$fout.='<span class="color-option" style="background-color: '.$opt['meta_color'].'"></span>';
		}



		$fout .= '</label>';
		if($attribute_type!='color') {
			$fout .= '</div>';
		}
	}



	if($attribute_type=='color'){

//                        print_r($opt);


		$fout.='</div>';
	}



	if($margs['type_multiple_style']=='checkbox-search'){
		$fout.='</div></div>';
	}


}


//print_rr($margs);

if($margs['type']=='slider' ){


	$input_name = $lab;




	$value0 = $margs['slider_min'];
	$value1 = $margs['slider_max'];
	$step = $margs['slider_step'];


//                $fout.=' lab_sanitized - '.$lab_sanitized;
//                $fout.=' $_GET[$lab_sanitized] - '.$_GET[$lab_sanitized];


	if(isset($_GET[$lab_sanitized]) && $_GET[$lab_sanitized]) {



		$price_range = explode('wtn-wtn',$_GET[$lab_sanitized]);



		if(is_array($price_range)&&count($price_range)>1){

			$value0 =  $price_range[0];

			$value1 = $price_range[1];

		}


	}


	$fout.='<div class="woo-filter-slider-con">';

	if($margs['left_label'] && $left_label_set==false){

		$fout.='<div class="woo-filter-slider--label">';
		$fout.=$margs['left_label'];
		$fout.='</div>';

		$left_label_set = true;
	}
	$fout.='
 
<input class="dzs-woo-table-filter-input for-slider" name="'.$input_name.'" type="text"  style="border:0; color:#f6931f; font-weight:bold;">
<div id="slider-range'.$index_filter.'"><div class="dzs-woo-slider-handle ui-slider-handle handle-min"></div><div class="dzs-woo-slider-handle ui-slider-handle handle-max"></div></div>';

	$fout.='<script>';
	$fout.='jQuery(document).ready(function($){';


//	print_rr($margs);

	if($value1=='infinite'){
		$value1 = $margs['slider_max'];
	}

	$fout.='var _c = $( "#slider-range'.$index_filter.'" );';

	$fout.= '
        var handle1 = _c.find(".handle-min");
        handle1.html( \'<div class="center-text">\'+'.$value0.'+\'</div>\' );
        
        var handle2 = _c.find(".handle-max");
        handle2.html( \'<div class="center-text">\'+'.$value1.'+\'</div>\' );';
	$fout.='_c.slider({
      range: true,
      min: '.$margs['slider_min'].',
      max: '.$margs['slider_max'].',
      step: '.$step.',
      values: [ '.$value0.', '.$value1.' ],
      slide: function( e, ui ) {
      //console.info(e,ui);
      
      var _t = $(e.target);
      
        _t.prev().val( ui.values[ 0 ] + "wtn-wtn" + ui.values[ 1 ] );
        
        console.info("_t.prev()", _t.prev(), _t.prev().val());
        
        var handle1 = _t.find(".handle-min");
        handle1.html( \'<div class="center-text">\'+ui.values[ 0 ]+\'</div>\' );
        
        var handle2 = _t.find(".handle-max");
        handle2.html( \'<div class="center-text">\'+ui.values[ 1 ]+\'</div>\' );
        
        if(window.trigger_change_on_target_inter){
        clearTimeout(window.trigger_change_on_target_inter);
        }
        window.trigger_change_on_target_inter = setTimeout(function(){
        window.trigger_change_on_target(_t.prev());
        },300);
      }
    });
    try{
    jQuery( \'input[name="'.$lab.'"\' ).val( $( "#slider-range'.$index_filter.'" ).slider( "values", 0 ) +
      "wtn-wtn" + $( "#slider-range'.$index_filter.'" ).slider( "values", 1 ) );
      }catch(e){ console.info(e); }';

	$fout.='});';

	$fout.='</script>';
	$fout.='</div>';


	wp_enqueue_script('jquery-ui-core');
//            wp_enqueue_script('jquery-ui-sortable');
//            wp_enqueue_script('jquery-ui-mouse');
	wp_enqueue_script('jquery-ui-slider');
	wp_enqueue_style('jquery-ui','https://code.jquery.com/ui/1.12.1/themes/'.$this->db_mainoptions['jquery_ui_theme'].'/jquery-ui.css');




}


// -- select type
if($margs['type']=='select'){

	// -- select type START

	$fout.='<div class="feed-dzswtl label-all" style="display:none;">'.$margs['label_all'].'</div>';
	$fout.='<div class="feed-dzswtl label-auto-empty" hidden aria-hidden="true">'.$margs['label_auto_empty'].'</div>';


	array_unshift($options,array(
		'label'=>($margs['label_all']),
		'value'=>'',
	));

	$args = array(
		'options'=>$options,
		'class'=>'dzs-woo-table-filter-input filter-type-select feed-from-'.$margs['feed_from'].' dzs-style-me skin-beige do-not-trigger-change-on-init do-not-trigger-change-on-reinit  ', // -- dzs-woo-table-filter-input
	);

	$lab = $lab_sanitized;

	if(is_array($seekval) && count($seekval)==1){
		$seekval = $seekval[0];
	}

	$args['seekval'] = $seekval;





	if($margs['type_select_style']=='default'){

		$fout.= DZSHelpers::generate_select($lab, $args);
	}

	if($margs['type_select_style']=='coronae' || $margs['type_select_style']=='forseen' || $margs['type_select_style']=='tabs-menu'){

//		$fout.='dada';


		$args['class'] = 'dzs-style-me opener-listbuttons dzs-woo-table-filter-input filter-type-select feed-from-'.$margs['feed_from'].' do-not-trigger-change-on-init do-not-trigger-change-on-reinit ';
		$fout.= DZSHelpers::generate_select($lab, $args);


		$fout.='<ul class="dzs-style-me-feeder">';


		foreach ($args['options'] as $lab=>$val){
//			print_rr($val);

			$fout.=' <li ><span class="">'.$val['label'].'</span></li>';
		}

                        $fout.='</ul>';
	}



//                foreach ($options as $opt){
//
//                    $fout.= '<div>';
//                    $fout.= '<label>';
//
//                    $args =array(
//                        'input_type'=>'checkbox',
//                        'val'=>$opt['value'],
//                        'class'=>'dzs-woo-table-filter-input',
//                    );
//
//
//                    $args['seekval']=$seekval;
//
//
//                    $fout.=' ';
//
//                    $fout.= $opt['label'];
//                    $fout.= '</label>';
//                    $fout.= '</div>';
//                }

}


// -- select type
if($margs['type']=='input'){




	array_unshift($options,array(
		'label'=>($margs['label_all']),
		'value'=>'',
	));


	$class = 'dzs-woo-table-filter-input filter-type-input feed-from-'.$margs['feed_from'].' ';
	$lab = $lab_sanitized;


	if(is_array($seekval) && count($seekval)==1){
		$seekval = $seekval[0];
	}

	$args['seekval'] = $seekval;
	$args['class'] = $class;



	$args['extraattr']=' placeholder="'.$margs['label_auto_empty'].'"';

	$fout.= DZSHelpers::generate_input_text($lab, $args);






}
//            $fout.= '</div>';




//            $fout.='<button>submit test</button>';
if($margs['type']!='single-with-image') {
//	$fout .= '</form>';
}
$fout.= '</div>';

$this->index_filter++;


wp_enqueue_style('dzswtl', $this->base_url . "libs/dzswootable/dzswootable.css");
wp_enqueue_script('dzswtl', $this->base_url . "libs/dzswootable/dzswootable.js");
