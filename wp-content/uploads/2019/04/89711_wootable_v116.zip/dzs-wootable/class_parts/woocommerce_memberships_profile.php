<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 17/09/2018
 * Time: 00:40
 */


//echo '23ceva';
//add_action('woocommerce_account_test', function(){
//  echo '23ceva';
//});
add_filter('woocommerce_membership_subscription_support', function($bool){
//  echo 'bool - '.$bool;

  return true;
});
add_action('woocommerce_account_content', function(){
//  echo '23ceva';


  $current_user = wp_get_current_user();

  $fout = '';
  if($current_user){
    global $dzswtl;


    $package_slug = 'free-membership';
    $package = __("Free",'dzswtl');


    $package = $dzswtl->rpwcm_get_package()['package'];
    $package_slug = $dzswtl->rpwcm_get_package()['package_slug'];


    echo '<div class="user-bought">You have <strong>'.$package.'</strong> package. ';




    $the_slug = $dzswtl->db_mainoptions['rpwcm_membership_page'];



    $args = array(
      'name'        => $the_slug,
      'post_type'   => 'page',
      'post_status' => 'publish',
      'numberposts' => 1
    );
    $my_posts = get_posts($args);
    if( $my_posts &&$my_posts[0] && $my_posts[0]->ID){


      echo '<a href="'.get_permalink($my_posts[0]->ID).'">'.__("Upgrade",'dzswtl').'?</a>';
    }

    echo '</div>';



//    echo '$package_slug - '. $package_slug;


    $nr_downloads_downloads = $dzswtl->rpwcm_get_nr_downloads($package_slug);
    $nr_downloads_downloads = ($nr_downloads_downloads?$nr_downloads_downloads:"0") ;

    echo '<div class="user-bought">You have <strong>'.($nr_downloads_downloads).'</strong> downloaded tracks. ';
    echo '</div>';


    $nr_downloads_remaining = $dzswtl->rpwcm_get_nr_downloads_remaining();
    $nr_downloads_remaining = ($nr_downloads_remaining?$nr_downloads_remaining:"0") ;

    echo '<div class="user-bought">You have <strong>'.($nr_downloads_remaining).'</strong> downloads remaining. ';
    echo '</div>';


}
});
add_action('woocommerce_membership_subscription_membership_ids', function(){
  echo '23ceva';
});