<?php





$margs = array(

	'style_float'=>'', // -- not recommended float.. use flex ;)
	'flex_align'=>"",
	'flex_width'=>"",
	'options'=>"newest-to-oldest,oldest-to-newest,cheap-to-expensive,expensive-to-cheap",


);





if(is_array($pargs)){

	$margs = array_merge($margs, $pargs);
}


$fout = '';

$lab = 'woo_sort';


$fout.='<div class="woo-table-sorter';


// -- you can cover
if($margs['flex_width']){
	$fout.=' flex-width-'.$margs['flex_width'];
}

if($margs['flex_align']){
	$fout.=' flex-align-'.$margs['flex_align'];
}

$fout.='" style="';


if($margs['style_float']){
	$fout.=' float: '.$margs['style_float'].';';
}


$fout.=$this->generate_style_for_flex($margs);

$fout.='"">';



$opts = array();

$seekval = '';

$options_string_arr = explode(',',$margs['options']);

foreach ($options_string_arr as $opt){
	$label = $opt;
	$val = $opt;

	if($opt=='newest-to-oldest'){
		$label =esc_html__("Newest to oldest",'dzswtl');



		if(isset($_GET['orderby']) && $_GET['orderby']=='date' && isset($_GET['order']) && $_GET['order']=='desc'){

			$seekval = $val;
		}
	}
	if($opt=='oldest-to-newest'){
		$label =esc_html__("Oldest to newest",'dzswtl');



		if(isset($_GET['orderby']) && $_GET['orderby']=='date' && isset($_GET['order']) && $_GET['order']=='asc'){

			$seekval = $val;
		}
	}
	if($opt=='cheap-to-expensive'){
		$label =esc_html__("Low Price to High Price",'dzswtl');
	}
	if($opt=='expensive-to-cheap'){
		$label =esc_html__("High Price to Low Price",'dzswtl');


		if(isset($_GET['orderby']) && $_GET['orderby']=='price' && isset($_GET['order']) && $_GET['order']=='desc'){

			$seekval = $val;
		}
	}


	if(strpos($opt,'pa_')===0){


		$taxonomy_name = preg_replace("/{.*?}/", "", $opt);;

		$tax = get_taxonomy($taxonomy_name);

		$label = $tax->label;

//		print_rr($term);




//		echo '$_GET[\'orderby\'] - '.$_GET['orderby'];
//		echo '$taxonomy_name - '.$taxonomy_name;


		preg_match("/{.*?}/", $opt, $output_array);


		if(isset($output_array[0])){
			if($output_array[0]=='{asc}'){
				$label.= ' '.esc_html__("ascending",'dzswtl');


				if(isset($_GET['orderby']) && $_GET['orderby']==$taxonomy_name) {
					if ( isset( $_GET['order'] ) && $_GET['order'] == 'asc' ) {

						$seekval = $val;
					}
				}
			}
			if($output_array[0]=='{desc}'){
				$label.= ' '.esc_html__("descending",'dzswtl');


				if(isset($_GET['orderby']) && $_GET['orderby']==$taxonomy_name){
				if(isset($_GET['order']) && $_GET['order']=='desc'){

					$seekval = $val;
				}
				}
			}
		}



//		$opt = preg_replace("/{.*?}/", "", $opt);;


	}

	$aux = array(
		'label'=>$label,
		'value'=>$val,
	);

	array_push($opts,$aux);




}




//echo '$seekval - '.$seekval.'<br>';
$fout.=DZSHelpers::generate_select($lab, array(
	'class'=>'dzs-style-me skin-beige do-not-trigger-change-on-init do-not-trigger-change-on-reinit',
	'options'=>$opts,
	'seekval'=>$seekval,
));

$fout.='</div>';


wp_enqueue_script('dzsselector', $this->base_url . 'libs/dzsselector/dzsselector.js');
wp_enqueue_style('dzsselector', $this->base_url . 'libs/dzsselector/dzsselector.css');

