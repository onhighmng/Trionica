<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 17/09/2018
 * Time: 00:40
 */


//echo '23ceva';
//add_action('woocommerce_account_test', function(){
//  echo '23ceva';
//});
add_filter('woocommerce_membership_subscription_support', function($bool){
//  echo 'bool - '.$bool;

  return true;
});
add_action('woocommerce_account_content', function(){
//  echo '23ceva';


  $current_user = wp_get_current_user();

  $fout = '';
  if($current_user){


    $package = __("Free",'dzswtl');



    $arr = array(
      'silver-membership',
      'gold-membership',
    );

    foreach ($arr as $lab=>$val){

      $the_slug = $val;

      $args = array(
        'name'        => $the_slug,
        'post_type'   => 'product',
        'post_status' => 'publish',
        'numberposts' => 1
      );
      $my_posts = get_posts($args);
      if( $my_posts &&$my_posts[0] && $my_posts[0]->ID){

        $po_id = $my_posts[0]->ID;
        if ( wc_customer_bought_product( $current_user->user_email, $current_user->ID, $po_id ) ) {

          $package = $my_posts[0]->post_title;
        }
      }
    }

    echo '<div class="user-bought">You have <strong>'.$package.'</strong> package. ';


    $the_slug = $val;

    $args = array(
      'name'        => $the_slug,
      'post_type'   => 'product',
      'post_status' => 'publish',
      'numberposts' => 1
    );
    $my_posts = get_posts($args);
    if( $my_posts &&$my_posts[0] && $my_posts[0]->ID){


      echo '<a href="'.get_permalink($my_posts[0]->ID).'">'.__("Upgrade",'dzswtl').'?</a>';
    }

    echo '</div>';





}
});
add_action('woocommerce_membership_subscription_membership_ids', function(){
  echo '23ceva';
});