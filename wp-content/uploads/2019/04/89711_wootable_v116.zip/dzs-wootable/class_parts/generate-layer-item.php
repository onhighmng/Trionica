<?php

//print_r($this->mainoptions);
function dzswtl_generate_layer_item($pargs = array()) {

//        include_once("class_parts/generate-layer-item.php");









	global $dzswtl;






    $margs = array(
        'position_type' => 'relative',
        'display_type' => '',
        'index' => '0',
        'width' => 'default',
        'max_width' => '',
        'height' => 'default',
        'top' => 'auto',
        'left' => 'auto',
        'right' => 'auto',
        'bottom' => 'auto',


        'margin_top' => '',
        'margin_right' => '',
        'margin_bottom' => '',
        'margin_left' => '',

        'padding_top' => '0',
        'padding_right' => '0',
        'padding_bottom' => '0',
        'padding_left' => '0',
        'border_radius' => '0',
        'border_width' => '0',
        'feed_from' => 'title',
        'table_header_title' => '',
        'border_color' => 'transparent',

        'color' => '',
        'background_color' => '',
        'background_image' => '',
        'type' => 'element', // element or container
        'animation_brake' => '',
        'font_size' => '',

        'text_align' => 'left',
        'font_weight' => '',
        'opacity' => '',
        'text' => '',
        'custom_meta_name' => '',
        'custom_attr_name' => '',



        'extra_classes' => '',
        'extra_attr' => '',
        'extra_html' => '',
        'custom_acf_name' => '',
        'feed_from_price_style' => '',
        'feed_from_ratings_style' => '',
        'flex_mode' => '',
        'flex_stretch' => '',
        'overflow' => '',
        'desc_count' => '',
        'thumbnail_height' => '',
        'show_sort_button' => 'default',


        'zoomsounds_mode' => 'full-player',
        'zoomsounds_play_in_footer' => '',
        'zoomsounds_vpconfig' => '',


        'button_type' => 'add-to-cart',
        'button_style' => 'default',
        'button_functionality' => 'default',
        'button_custom_text' => '',

    );

    $default_margs = $dzswtl->generate_layout_item_default_margs;



    $margs = array_merge($margs, $pargs);


    if($margs['width']=='default'){

        if($margs['type']=='circ'){
            $margs['width']='100%';
        }
        if($margs['type']=='rect'){
            $margs['width']='{{perc}}';
        }
    }
    if($margs['width']=='default') {
        $margs['width'] = 'auto';
    }
    if($margs['height']=='default') {
        if($margs['type']=='container'){
            $margs['height']='auto';
        }
        if($margs['type']=='rect'){
            $margs['height']='40';
        }
    }

    $struct_item = '';


    $title = '';

    $title = '';
    if($margs['type']=='rect'){

        $title = '<i class="fa fa-stop color-icon" aria-hidden="true"></i>&nbsp;&nbsp; '.__("Rectangle");
    }

    if($margs['type']=='circ'){

        $title = '<i class="fa fa-circle color-icon" aria-hidden="true"></i>&nbsp;&nbsp; '.__("Circle");
    }

    if($margs['type']=='text'){

        $title = '<i class="fa fa-font color-icon" aria-hidden="true"></i>&nbsp;&nbsp; '.__("Text");
    }
    if($margs['type']=='element'){

        $title = ''.__("Element");
    }
    if($margs['type']=='container'){

        $title = ' '.__("Container");
    }


    $struct_item = '<li class="dd-item builder-layer dd3-item dzstooltip-con3 ';

    if($margs['type']=='container'){
        $struct_item.=' dd-container';
    }

    $struct_item.=' dd3-item ';

    if($margs['type']!='container'){
        $struct_item .=' builder-layer';
    }else{
        $struct_item .=' builder-layer builder-container';

    }

    $struct_item.=' type-'.$margs['type'].'">
        <div class="builder-layer--head "><i class="outline-outer"></i><i class="outline-outer--inner"></i>'
        . '<input type="hidden" name="bars['.$margs['index'].'][type]" value="'.$margs['type'].'"  />'
        . '<span class="the-title" data-type="'.$margs['type'].'">'.$title.'<span class="feed-from"> ( <span class="feed-from-val">'.$margs['feed_from'].'</span> )</span></span>'
        . '<span class="sortable-handle-con dd-handle dd3-handle"><span class="sortable-handle fa fa-bars"></span></span></div>';

    // dd-content dd3-content

    $struct_item.='<div class="builder-layer--inside dzstooltip  arrow-left talign-start style-default color-light-dark" style="width: 500px; top: -3px;">';
    $struct_item.='<div class="dzstooltip--inner" style="padding: 15px; background-color: #444;">';


    if($margs['type']=='text'){
        $struct_item.='<div class="setting type-text">
<textarea class="text-input builder-field with-tinymce" data-input-label="'.$lab.'" name="bars['.$margs['index'].'][text]">'.$margs['text'].'</textarea>
<div class="sidenote">'.__("Edit font size from the appearence tab").'
</div>
</div>';

    }

    $struct_item.= '<div class="dzs-tabs skin-box init-layer">';





    $struct_item.='
        
            <div class="dzs-tab-tobe">
                <div class="tab-menu with-tooltip">
                <i class="fa fa-external-link"></i> <span class="the-label">'.__("Feed").'</span>
                </div>
                <div class="tab-content">
                
                ';




    $arr_opts = array(
        array('label' => __('Title'), 'value' => 'title',),
        array('label' => __('Short Description'), 'value' => 'short-description',),
        array('label' => __('Full Description'), 'value' => 'full-description',),
        array('label' => __('Button'), 'value' => 'button',),
        array('label' => __('Rating Stars'), 'value' => 'ratings',),
        array('label' => __('ID'), 'value' => 'id',),
        array('label' => __('Author Name'), 'value' => 'author-name',),
        array('label' => __('Price'), 'value' => 'price',),
        array('label' => __('Sale Percent'), 'value' => 'sale-percent',),
        array('label' => __('Number'), 'value' => 'number',),
        array('label' => __('Categories'), 'value' => 'categories',),
        array('label' => __('Custom Attribute'), 'value' => 'custom-attribute',),
        array('label' => __('Custom Meta'), 'value' => 'custom-meta',),
        array('label' => __('Product Image'), 'value' => 'product-image',),
        array('label' => __('Stock'), 'value' => 'stock',),

    );


    if(defined('DZSAP_VERSION')){
        array_push($arr_opts, array(
            'label'=>__("ZoomSounds Player"),
            'value'=>'zoomsounds-player',
        ));
    }




    if($dzswtl->is_plugin_active('advanced-custom-fields/acf.php')){

        array_push($arr_opts, array(
            'label'=>__("Advanced Custom Field"),
            'value'=>'acf',
        ));
    }

//    echo 'hmm - '.$dzswtl->is_plugin_active('advanced-custom-fields/acf.php');


    $lab = 'feed_from';

    $struct_item .= '
                
                <div class="setting ">
            <div class="setting-label">' . __('Feed From') . '</div>';
    $struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array('options' => $arr_opts,
            'class' => 'feed-from-main dzs-style-me skin-beige builder-field dzs-dependency-field',
            'seekval' => $margs[$lab],
            'extraattr' => ' data-label="'.$lab.'"',
        )
    );

    $struct_item .= '</div>';



    $lab = 'table_header_title';

    $struct_item .= '
                
                <div class="setting ">
            <div class="setting-label">' . __('Table Header Title') . '</div>';
    $struct_item .= DZSHelpers::generate_input_text('bars[' . $margs['index'] . '][' . $lab . ']', array('class' => ' text-input builder-field',
        'seekval' => $margs[$lab],

        'extraattr' => ' data-label="'.$lab.'"',
    ));

    $struct_item .= '</div>';




	$dependency = array(
		array(
			'element' => 'feed_from',
			'value' => array('short-description','title'),
		),
	);



	$lab = 'desc_count';

	$val = '';


	if(isset($margs[$lab])){
		$val = $margs[$lab];
	}


	$struct_item .= '
                
                <div class="setting check-label check-parent1" data-dependency=\''.json_encode($dependency).'\'>
            <div class="setting-label">' . esc_html__('Description character count','dzswtl') . '</div>';
	$struct_item .= DZSHelpers::generate_input_text('bars[' . $margs['index'] . '][' . $lab . ']', array(

		'class' => ' text-input  builder-field',
		'seekval' => $val,
		'extraattr' => ' data-label="'.$lab.'"',
	));

	$struct_item .= '</div>';







    $dependency = array(
        array(
            'element' => 'feed_from',
            'value' => array('title','ratings','price','custom-attribute'),
        ),
    );



    $lab = 'show_sort_button';

    $struct_item .= '
                
                <div class="setting check-label check-parent1 setting-sort-button" data-dependency=\''.json_encode($dependency).'\'>
            <div class="setting-label">' . __('Sort Button') . '</div>';
    $struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array('options' => array(
        array('label' => __('Default'), 'value' => 'default',),
        array('label' => __('Disable'), 'value' => 'off',),
        array('label' => __('Enable'), 'value' => 'on',),

    ), 'class' => 'dzs-style-me skin-beige builder-field',
        'seekval' => $margs[$lab],
        'extraattr' => ' data-label="'.$lab.'"',
    ));

    $struct_item .= '</div>';









    $dependency = array(
        array(
            'element' => 'feed_from',
            'value' => array('price'),
        ),
    );



    $lab = 'feed_from_price_style';

    $struct_item .= '
                
                <div class="setting check-label check-parent1" data-dependency=\''.json_encode($dependency).'\'>
            <div class="setting-label">' . __('Price Style') . '</div>';
    $struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array('options' => array(
        array('label' => __('Unstyled'), 'value' => '',),
        array('label' => __('Default'), 'value' => 'default',),
        array('label' => esc_html__('Cosmo','dzswtl'), 'value' => 'cosmo',),
        array('label' => __('Show only true'), 'value' => 'show-only-true',),

    ), 'class' => 'dzs-style-me skin-beige builder-field',
        'seekval' => $margs[$lab],
        'extraattr' => ' data-label="'.$lab.'"',
    ));

    $struct_item .= '</div>';








    $dependency = array(
        array(
            'element' => 'feed_from',
            'value' => array('ratings'),
        ),
    );



    $lab = 'feed_from_ratings_style';

    $struct_item .= '
                
                <div class="setting check-label check-parent1" data-dependency=\''.json_encode($dependency).'\'>
            <div class="setting-label">' . __('Rating Style') . '</div>';
    $struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array('options' => array(
        array('label' => __('Default'), 'value' => 'default',),
        array('label' => __('WooTable Stars'), 'value' => 'wootable-stars',),

    ), 'class' => 'dzs-style-me skin-beige builder-field',
        'seekval' => $margs[$lab],
        'extraattr' => ' data-label="'.$lab.'"',
    ));

    $struct_item .= '</div>';











    $dependency = array(
        array(
            'element' => 'feed_from',
            'value' => array('custom-meta'),
        ),
    );



    $lab = 'custom_meta_name';

    $struct_item .= '
                
                <div class="setting check-label check-parent1" data-dependency=\''.json_encode($dependency).'\'>
            <div class="setting-label">' . __('Meta Name') . '</div>';
    $struct_item .= DZSHelpers::generate_input_text('bars[' . $margs['index'] . '][' . $lab . ']', array(

        'class' => ' text-input  builder-field',
        'seekval' => $margs[$lab],
        'extraattr' => '  data-label="'.$lab.'"',
    ));

    $struct_item .= '</div>';







	$dependency = array(
		array(
			'element' => 'feed_from',
			'value' => array('title','product-image'),
		),
	);




	$lab = 'link_to';


	$val = '';

	if(isset($margs[$lab])){
		$val = $margs[$lab];
	}

	$struct_item .= '  <div class="setting check-label check-parent1" data-dependency=\'' . json_encode($dependency) . '\'>
            <div class="setting-label">' . esc_html__('Link to...','dzswtl') . '</div>';
	$struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array(
		'options' => array(
			array(
				'label' => esc_html__('Default','dzswtl'),
				'value' => '',
			),
			array(
				'label' => esc_html__('Item','dzswtl'),
				'value' => 'item',
			),
			array(
				'label' => esc_html__('Nothing','dzswtl'),
				'value' => 'none',
			),


		),
		'class' => 'dzs-style-me skin-beige builder-field',
		'seekval' => $val,
		'extraattr' => ' data-label="'.$lab.'" ',
	));


	$struct_item .= '</div>';








    $dependency = array(
        array(
            'element' => 'feed_from',
            'value' => array('custom-attribute'),
        ),
    );



    $lab = 'custom_attr_name';

    $struct_item .= '
                
                <div class="setting check-label check-parent1" data-dependency=\''.json_encode($dependency).'\'>
            <div class="setting-label">' . __('Attribute Name') . '</div>';
    $struct_item .= DZSHelpers::generate_input_text('bars[' . $margs['index'] . '][' . $lab . ']', array(

        'class' => ' text-input  builder-field',
        'seekval' => $margs[$lab],
        'extraattr' => '  data-label="'.$lab.'"',
    ));

    $struct_item .= '</div>';





	// -- lab style
	$lab = 'attr_style';


	$val = '';

	if(isset($margs[$lab])){
		$val = $margs[$lab];
	}

	$struct_item .= '  <div class="setting check-label check-parent1" data-dependency=\'' . json_encode($dependency) . '\'>
            <div class="setting-label">' . __('Style') . '</div>';
	$struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array(
		'options' => array(
			array(
				'label' => esc_html__('Default','dzswtl'),
				'value' => '',
			),
			array(
				'label' => esc_html__('Cosco','dzswtl'),
				'value' => 'cosco',
			),
			array(
				'label' => esc_html__('Minimali','dzswtl'),
				'value' => 'minimali',
			),


		),
		'class' => 'dzs-style-me skin-beige builder-field',
		'seekval' => $val,
		'extraattr' => '  data-label="'.$lab.'"',
	));


	$struct_item .= '</div>';




	$dependency = array(
		array(
			'element' => 'feed_from',
			'value' => array('custom-attribute','categories'),
		),
	);

	$lab = 'attr_link_to';


	$val = '';

	if(isset($margs[$lab])){
		$val = $margs[$lab];
	}

	$struct_item .= '  <div class="setting check-label check-parent1" data-dependency=\'' . json_encode($dependency) . '\'>
            <div class="setting-label">' . esc_html__('Link to...','dzswtl') . '</div>';
	$struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array(
		'options' => array(
			array(
				'label' => esc_html__('Nothing','dzswtl'),
				'value' => '',
			),
			array(
				'label' => esc_html__('Link to filter','dzswtl'),
				'value' => 'filter',
			),


		),
		'class' => 'dzs-style-me skin-beige builder-field',
		'seekval' => $val,
		'extraattr' => '  data-label="'.$lab.'"',
	));


	$struct_item .= '</div>';













    $dependency = array(
        array(
            'element' => 'feed_from',
            'value' => array('acf'),
        ),
    );



    $lab = 'custom_acf_name';

    $struct_item .= '
                
                <div class="setting check-label check-parent1" data-dependency=\''.json_encode($dependency).'\'>
            <div class="setting-label">' . __('Field Name') . '</div>';
    $struct_item .= DZSHelpers::generate_input_text('bars[' . $margs['index'] . '][' . $lab . ']', array(

        'class' => ' text-input  builder-field',
        'seekval' => $margs[$lab],
        'extraattr' => '  data-label="'.$lab.'"',
    ));

    $struct_item .= '</div>';








    $dependency = array(
        array(
            'element' => 'feed_from',
            'value' => array(
                'product-image',

            ),
        ),
    );


    $lab = 'thumbnail_height';


    $val = '';

    if(isset($margs[$lab])){
        $val = $margs[$lab];
    }

    $struct_item .= '
                
                <div class="setting check-label check-parent1" data-dependency=\'' . json_encode($dependency) . '\'>
            <div class="setting-label">' . __('Thumbnail Height') . '</div>';
    $struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array(
        'options' => array(
            array(
                'label' => __('Full Height'),
                'value' => '1',
            ),
            array(
                'label' => __('Height 0.5x Width'),
                'value' => '0.5',
            ),
            array(
                'label' => __('Height 0.75x Width'),
                'value' => '0.75',
            ),
            array(
	            'label' => __('Height 1.2x Width'),
	            'value' => '1.2',
            ),
            array(
	            'label' => __('Height 1.5x Width'),
	            'value' => '1.5',
            ),

        ),
        'class' => 'dzs-style-me skin-beige builder-field',
        'seekval' => $val,
        'extraattr' => '  data-label="'.$lab.'"',
    ));

    $struct_item .= '</div>';


    $lab = 'thumbnail_size';


    $val = '';

    if(isset($margs[$lab])){
        $val = $margs[$lab];
    }

    $struct_item .= '
                
                <div class="setting check-label check-parent1" data-dependency=\'' . json_encode($dependency) . '\'>
            <div class="setting-label">' . esc_html__('Thumbnail Size','dzswtl') . '</div>';
    $struct_item .= DZSHelpers::generate_input_text('bars[' . $margs['index'] . '][' . $lab . ']', array(
        'options' => '',
        'class' => ' builder-field',
        'seekval' => $val,
        'extraattr' => ' data-label="'.$lab.'"',
    ));

    $struct_item.='<div class="sidenote">' . sprintf(esc_html__('Input %s for example for %s pixels width and %s pixels height or leave blank for default','dzswtl'),'<strong>150,100</strong>','150','100') . '</div>';
    $struct_item .= '</div>';









    if(defined('DZSAP_VERSION')) {

        $dependency = array(
            array(
                'element' => 'feed_from',
                'value' => array(
                    'zoomsounds-player',

                ),
            ),
        );


        $lab = 'zoomsounds_mode';

        $struct_item .= '
                <div class="setting check-label check-parent1" data-dependency=\'' . json_encode($dependency) . '\'>
            <div class="setting-label">' . esc_html__('ZoomSounds Player Mode','dzsap') . '</div>';
        $struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array(
            'options' => array(
                array(
                    'label' => __('Full Player'),
                    'value' => 'full-player',
                ),
                array(
                    'label' => __('Just play button'),
                    'value' => 'just-play-button',
                ),
                array(
                    'label' => __('Just Waveform'),
                    'value' => 'just-waveform',
                ),

            ),
            'class' => 'dzs-style-me skin-beige builder-field',
            'seekval' => $margs[$lab],
            'extraattr' => '  data-label="'.$lab.'"',
        ));

        $struct_item .= '</div>';
        // -- end .setting



	    $dependency = array(
		    array(
			    'element' => 'feed_from',
			    'value' => array(
				    'zoomsounds-player',

			    ),
		    ),
		    array(
			    'element' => 'zoomsounds_mode',
			    'value' => array(
				    array('full-player','just-play-button'),

			    ),
		    ),
	    );








	    $vpconfigs_arr = array(
		    array('lab'=>__("Default"), 'val'=>'')
	    );

	    $i23=0;

	    global $dzsap;
	    foreach ($dzsap->mainitems_configs as $vpconfig) {
		    //print_r($vpconfig);


		    $auxa = array(
			    'label'=>$vpconfig['settings']['id'],
			    'value'=>$vpconfig['settings']['id'],
			    'extraattr'=>'data-sliderlink="'.$i23.'"',
		    );

		    array_push($vpconfigs_arr, $auxa);

		    $i23++;
	    }


        $lab = 'zoomsounds_vpconfig';



	    $val = '';


	    if(isset($margs[$lab])){
		    $val = $margs[$lab];
	    }


        $struct_item .= '
                <div class="setting check-label check-parent1" data-dependency=\'' . json_encode($dependency) . '\'>
            <div class="setting-label">' . esc_html__('Player configuration','dzsap') . '</div>';
        $struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array(
            'options' => $vpconfigs_arr,

            'class' => 'dzs-style-me skin-beige builder-field',
            'seekval' => $val,
            'extraattr' => '  data-label="'.$lab.'"',
        ));

        $struct_item .= '</div>';
        // -- end .setting



//   array(
//	    array(
//		    'label' => __('Reflect'),
//		    'value' => 'reflecto',
//	    ),
//                array(
//	                'label' => __('Normal'),
//	                'value' => 'normal',
//                ),
//
//            ),





	    $lab = 'zoomsounds_play_in_footer';

	    $struct_item .= '
                <div class="setting check-label check-parent1" data-dependency=\'' . json_encode($dependency) . '\'>
            <div class="setting-label">' . esc_html__('Play in footer if available','dzsap') . '</div>';
	    $struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array(
		    'options' => array(
			    array(
				    'label' => esc_html__('Default','dzsap'),
				    'value' => '',
			    ),
			    array(
				    'label' => esc_html__('Play normal','dzsap'),
				    'value' => 'off',
			    ),
			    array(
				    'label' => esc_html__('Play in footer if available','dzsap'),
				    'value' => 'on',
			    ),

		    ),
		    'class' => 'dzs-style-me skin-beige builder-field',
		    'seekval' => $margs[$lab],
		    'extraattr' => '  data-label="'.$lab.'"',
	    ));

	    $struct_item .= '</div>';
	    // -- end .setting






    }




    $dependency = array(
        array(
            'element' => 'feed_from',
            'value' => array(
                'button',

            ),
        ),
    );




	$lab = 'button_type';


	$val = 'add-to-cart';


	if(isset($margs[$lab])){
		$val = $margs[$lab];
	}


	$struct_item .= '
                
                <div class="setting check-label check-parent1" data-dependency=\'' . json_encode($dependency) . '\'>
            <div class="setting-label">' . __('Type') . '</div>';
	$struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array(
		'options' => array(
			array(
				'label' => __('Add to cart'),
				'value' => 'add-to-cart',
			),

			array(
				'label' => __('Wishlist'),
				'value' => 'wishlist',
			),

			array(
				'label' => __('Custom'),
				'value' => 'custom',
			),

		),
		'class' => 'dzs-style-me skin-beige builder-field dzs-dependency-field',
		'seekval' => $val,
		'extraattr' => ' data-label="'.$lab.'"',
	));

	$struct_item .= '</div>';






    $lab = 'button_style';

	$val = 'default';


	if(isset($margs[$lab])){
		$val = $margs[$lab];
	}

    $struct_item .= '
                
                <div class="setting check-label check-parent1" data-dependency=\'' . json_encode($dependency) . '\'>
            <div class="setting-label">' . __('Style') . '</div>';
    $struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array(
        'options' => array(
            array(
                'label' => __('Default Button'),
                'value' => 'default',
            ),

            array(
                'label' => __('Just Icon'),
                'value' => 'just-icon',
            ),
            array(
	            'label' => __('Cosco Button'),
	            'value' => 'cosco',
            ),
            array(
	            'label' => esc_html__('Gamma','dzswtl'),
	            'value' => 'gamma',
            ),

        ),
        'class' => 'dzs-style-me skin-beige builder-field',
        'seekval' => $val,
        'extraattr' => ' data-label="'.$lab.'"',
    ));

    $struct_item .= '</div>';






    $lab = 'button_functionality';


    $val = 'default';


    if(isset($margs[$lab])){
        $val = $margs[$lab];
    }


    $struct_item .= '
                
                <div class="setting check-label check-parent1" data-dependency=\'' . json_encode($dependency) . '\'>
            <div class="setting-label">' . __('Functionality') . '</div>';
    $struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array(
        'options' => array(
            array(
                'label' => esc_html__('Default','dzswtl'),
                'value' => 'default',
            ),

            array(
                'label' => esc_html__('Add to cart link','dzswtl'),
                'value' => 'link',
            ),

            array(
                'label' => esc_html__('Nothing','dzswtl'),
                'value' => 'none',
            ),
            array(
                'label' => esc_html__('Product link','dzswtl'),
                'value' => 'direct_link',
            ),
            array(
                'label' => esc_html__('Purchase lightbox','dzswtl'),
                'value' => 'purchase_lightbox',
            ),

        ),
        'class' => 'dzs-style-me skin-beige builder-field',
        'seekval' => $val,
        'extraattr' => ' data-label="'.$lab.'"',
    ));

    $struct_item .= '</div>';







	$dependency = array(
		array(
			'element' => 'button_type',
			'value' => array(
				'custom',
			),
		),
	);



	$lab = 'button_custom_text';

	$struct_item .= '
                
                <div class="setting check-label check-parent1" data-dependency=\''.json_encode($dependency).'\'>
            <div class="setting-label">' . __('Custom html') . '</div>';
	$struct_item .= DZSHelpers::generate_input_textarea('bars[' . $margs['index'] . '][' . $lab . ']', array(

		'class' => ' text-input  builder-field',
		'seekval' => $margs[$lab],
		'extraattr' => ' data-label="'.$lab.'"',
	));

	$struct_item .= '</div>';
























	$struct_item.='
</div>
</div>
                ';



    // -- start tab POSITION

    $struct_item.='<div class="dzs-tab-tobe">
            <div class="tab-menu with-tooltip">
            <i class="fa fa-arrows"></i> <span class="the-label">'.__("Position").'</span>
            </div>
            <div class="tab-content">';



    if($margs['type']=='container') {

        $lab = 'flex_mode';

        $struct_item .= '
                
                <div class="setting ">
            <div class="setting-label">' . __('Flex inside') . '</div>';
        $struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array('options' => array(
            array('label' => __('Default'), 'value' => 'none',),
            array('label' => __('Flex Mode'), 'value' => 'flex',),

        ), 'class' => 'dzs-style-me skin-beige builder-field',

        'extraattr' => '  data-default-val="'.$default_margs[$lab].'"',
        'seekval' => $margs[$lab],
	        )

        );

        $struct_item .= '</div>';
    }else{


    }






	$lab = 'flex_stretch';

	$struct_item .= '
                
                <div class="setting ">
            <div class="setting-label">' . __('Stretch') . '</div>';
	$struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array('options' => array(
		array('label' => __('Default'), 'value' => '',),
		array('label' => __('No change'), 'value' => 'none',),
		array('label' => __('Cover Minimum Space'), 'value' => '0 0 auto',),
		array('label' => __('Cover Maximum Space'), 'value' => '1000',),
	), 'class' => 'dzs-style-me skin-beige builder-field', 'seekval' => $margs[$lab]));

	$struct_item .= '</div>';




    $struct_item.='

            <hr>
            
            
            
            
            
            
            
            <div class="dzstoggle">
            <div class="toggle-title">
            '.esc_html__("Dimensions",'dzswtl').'
            </div>
            <div class="toggle-content">
            
           
            ';




    $struct_item.='<div class="setting">
            <div class="setting-label">'.esc_html__("Position type",'dzswtl').'</div>';
    $lab = 'position_type';



    $args = array('options' => array('relative','absolute'), 'class' => 'dzs-style-me skin-beige builder-field', 'extraattr' => ' data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }

    $struct_item.=DZSHelpers::generate_select('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='</div>';




    $struct_item.='<div class="setting">
            <div class="setting-label">'.esc_html__("Display type",'dzswtl').'</div>';
    $lab = 'display_type';



    $args = array(
    	'options' => array(
		    array('label' => esc_html__('Default','dzswtl'), 'value' => '',),
		    array('label' => esc_html__('Inline','dzswtl'), 'value' => 'inline-block',),

    ),
                  'class' => 'dzs-style-me skin-beige builder-field',
                  'extraattr' => ' data-label="'.$lab.'"',
                  'seekval' => $margs[$lab]
    );

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }

    $struct_item.=DZSHelpers::generate_select('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='</div>';





$struct_item.='<div class="flex-con">
            <div class="one-third">
            <div class="setting">
            <div class="setting-label">'.__("Width").'</div>';




//            print_r($margs);

    $lab = 'width';
    $args = array('class' => 'text-input builder-field', 'extraattr' => ' data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
            
                </div>
                </div>
                
                
            <div class="one-third">
            <div class="setting">
            <div class="setting-label">'.__("Max").' '.__("Width").'</div>
            
            ';


//            print_r($margs);

    $lab = 'max_width';
    $args = array(
    	'class' => 'text-input builder-field',
                  'extraattr' => '  data-label="'.$lab.'"',
	    'seekval' => $margs[$lab]
    );

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
            
                </div>
                </div>
                
                
                
                
            <div class="one-third">
            <div class="setting">
            <div class="setting-label">'.__("Height").'</div>
             ';


//            print_r($margs);

    $lab = 'height';
    $args = array('class' => 'text-input builder-field', 'extraattr' => 'data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
                </div>
                </div>
                </div>
    <div class="clear"></div>


            <hr>
            
<div class="flex-con">
            <div class="one-half" style="float:none; margin: 0 auto;">
            <div class="setting">
            <div class="setting-label">'.__("Top").'</div>
             ';


//            print_r($margs);

    $lab = 'top';
    $args = array('class' => 'text-input builder-field', 'extraattr' => 'data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
                </div>
                </div>
                </div>

<div class="flex-con">
            <div class="one-half">
            <div class="setting">
            <div class="setting-label">'.__("Left").'</div>
             ';


//            print_r($margs);

    $lab = 'left';
    $args = array('class' => 'text-input builder-field', 'extraattr' => 'data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
                </div>
                </div>
            <div class="one-half">
            <div class="setting">
            <div class="setting-label">'.__("Right").'</div>
             ';


//            print_r($margs);

    $lab = 'right';
    $args = array('class' => 'text-input builder-field', 'extraattr' => 'data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
                </div>
                </div>
                </div>

<div class="flex-con">
            <div class="one-half" style="float:none; margin: 0 auto;">
            <div class="setting">
            <div class="setting-label">'.__("Bottom").'</div>
             ';


//            print_r($margs);

    $lab = 'bottom';
    $args = array('class' => 'text-input builder-field', 'extraattr' => 'data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
                </div>
                </div>
                </div>
            
            
            
            
            
            </div>
            </div>
            
            
            
            
            <div class="dzstoggle">
            <div class="toggle-title">
            '.__("Margins").'
            </div>
            <div class="toggle-content">
<div class="flex-con">
            <div class="one-half" style="float:none; margin: 0 auto;">
            <div class="setting">
            <div class="setting-label">'.__("Margin").' '.__("Top").'</div>
            ';


//            print_r($margs);

    $lab = 'margin_top';
    $args = array('class' => 'text-input builder-field', 'extraattr' => 'data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
                </div>
                </div>
                </div>
<div class="flex-con">
            <div class="one-half">
            <div class="setting">
            <div class="setting-label">'.__("Margin").' '.__("Left").'</div>
            ';


//            print_r($margs);

    $lab = 'margin_left';
    $args = array('class' => 'text-input builder-field', 'extraattr' => 'data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
                </div>
                </div>
            <div class="one-half">
            <div class="setting">
            <div class="setting-label">'.__("Margin").' '.__("Right").'</div>
            ';


//            print_r($margs);

    $lab = 'margin_right';
    $args = array('class' => 'text-input builder-field', 'extraattr' => 'data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
                </div>
                </div>
                </div>  

<div class="flex-con">
            <div class="one-half" style="float:none; margin: 0 auto;">
            <div class="setting">
            <div class="setting-label">'.__("Margin").' '.__("Bottom").'</div>
            ';


//            print_r($margs);

    $lab = 'margin_bottom';
    $args = array('class' => 'text-input builder-field', 'extraattr' => 'data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
                </div>
                </div>
                </div>
    
    
    
            </div>
            </div>
            
            
            <div class="dzstoggle">
            <div class="toggle-title">
            '.__("Paddings").'
            </div>
            <div class="toggle-content">
            
<div class="flex-con">
            <div class="one-half" style="float:none; margin: 0 auto;">
            <div class="setting">
            <div class="setting-label">'.__("Padding").' '.__("Top").'</div>
            ';


//            print_r($margs);

    $lab = 'padding_top';
    $args = array('class' => 'text-input builder-field', 'extraattr' => 'data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
                </div>
                </div>
                </div>
<div class="flex-con">
            <div class="one-half">
            <div class="setting">
            <div class="setting-label">'.__("Padding").' '.__("Left").'</div>
            ';


//            print_r($margs);

    $lab = 'padding_left';
    $args = array('class' => 'text-input builder-field', 'extraattr' => ' data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
                </div>
                </div>
            <div class="one-half">
            <div class="setting">
            <div class="setting-label">'.__("Padding").' '.__("Right").'</div>
            ';


//            print_r($margs);

    $lab = 'padding_right';
    $args = array('class' => 'text-input builder-field', 'extraattr' => ' data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
                </div>
                </div>
                </div>

<div class="flex-con">
            <div class="one-half" style="float:none; margin: 0 auto;">
            <div class="setting">
            <div class="setting-label">'.__("Padding").' '.__("Bottom").'</div>
            ';


//            print_r($margs);

    $lab = 'padding_bottom';
    $args = array('class' => 'text-input builder-field', 'extraattr' => ' data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

    if(isset($default_margs[$lab])){
        $args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
    }
    $struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

    $struct_item.='
                </div>
                </div>
                </div>
    
    
    
            </div>
            </div>
            
            
            
            
            <div class="dzstoggle only-for-type-container">
            <div class="toggle-title">
            '.__("Flex Position").'
            </div>
            <div class="toggle-content">
            
            
            
            
            ';







    $struct_item.='
    
    
    
            </div>
            </div>
            
            
            
            
            
            
            
            
            

            </div>


        </div>

            <div class="dzs-tab-tobe">
                <div class="tab-menu with-tooltip">
                <i class="fa fa-paint-brush"></i> <span class="the-label">'.__("Styling").'</span>
                </div>
                <div class="tab-content">
                
                
                ';


	$lab = 'background_color';
                $struct_item.='<div class="setting ">
            <div class="setting-label">'.__("Background").' '.__("Color").'</div>
            <div class="flex-with-colorpicker">
            <input class="text-input builder-field with-colorpicker spectrum-me spectrum-input-visible" type="text" name="bars[' . $margs['index'] . ']['.$lab.']" data-label="'.$lab.'" value="'.$margs[$lab].'">
            </div>
                </div>';



	$struct_item.=' <div class="dzstoggle">
            <div class="toggle-title">
            '.__("Text").'
            </div>
            <div class="toggle-content">';



	$lab = 'color';


	$struct_item.='<div class="setting ">
            <div class="setting-label">'.__("Color").'</div>
            <div class="flex-with-colorpicker">
            <input class="text-input builder-field with-colorpicker  spectrum-me spectrum-input-visible" type="text" name="bars[' . $margs['index'] . ']['.$lab.']" data-label="'.$lab.'" value="'.$margs[$lab].'"><span class="picker-con picker-left"><span class="the-icon"></span><span class="picker"></span></span>
            </div>
</div>';





	$lab = 'font_size';
	$struct_item.='   <div class="setting">
            <div class="setting-label">'.__("Font size").'</div>
            ';


//            print_r($margs);

	$args = array('class' => 'builder-field', 'extraattr' => ' data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

	if(isset($default_margs[$lab])){
		$args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
	}
	$struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

	$struct_item.=' </div>';






	$lab = 'text_align';

	$struct_item .= '
                
                <div class="setting ">
            <div class="setting-label">' . __('Align') . '</div>';
	$struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array('options' => array(
		array('label' => esc_html__('Default','dzswtl'), 'value' => '',),
		array('label' => esc_html__('Center','dzswtl'), 'value' => 'center',),
		array('label' => esc_html__('Right','dzswtl'), 'value' => 'right',),
	), 'class' => 'dzs-style-me skin-beige builder-field', 'seekval' => $margs[$lab]));

	$struct_item .= '</div>';



	$lab = 'font_weight';

	$struct_item .= '
                
                <div class="setting ">
            <div class="setting-label">' . __('Weight') . '</div>';
	$struct_item .= DZSHelpers::generate_select('bars[' . $margs['index'] . '][' . $lab . ']', array('options' => array(
		array('label' => esc_html__('Default','dzswtl'), 'value' => '',),
		array('label' => esc_html__('Slim','dzswtl'), 'value' => '300',),
		array('label' => esc_html__('Bold','dzswtl'), 'value' => '700',),
	), 'class' => 'dzs-style-me skin-beige builder-field', 'seekval' => $margs[$lab]));

	$struct_item .= '</div>';



	$struct_item.='</div>
</div>'; // -- end toggle







	$lab = 'opacity';
	$struct_item.='   <div class="setting">
            <div class="setting-label">'.__("Opacity").'</div>
            ';


//            print_r($margs);

	$args = array('class' => 'builder-field', 'extraattr' => ' data-label="'.$lab.'"', 'seekval' => $margs[$lab]);

	if(isset($default_margs[$lab])){
		$args['extraattr'].=' data-default-val="'.$default_margs[$lab].'"';
	}
	$struct_item.=DZSHelpers::generate_input_text('bars['.$margs['index'].']['.$lab.']', $args);

	$struct_item.=' </div>';


    if($margs['type']=='container'){

        $lab = 'overflow';


        $arr_overflow = array(
            array(
                'label'=>__("Show Overflow"),
                'value'=>'auto',
            ),
            array(
                'label'=>__("Hide Overflow"),
                'value'=>'hidden',
            ),
        );

        $struct_item.='   <div class="setting">
            <div class="setting-label">'.__("Overflow").'</div>';
        $struct_item.=DZSHelpers::generate_select('bars['.$margs['index'].']['.$lab.']', array('options' => $arr_overflow, 'class' => 'dzs-style-me skin-beige builder-field', 'seekval' => $margs[$lab]));

        $struct_item.='</div>
        ';
    }

    $struct_item.='  <div class="setting ">
                    <div class="setting-label">'.__("Extra").' '.__("Classes").'</div>
                    <input class="text-input builder-field" type="text" name="bars[' . $margs['index'] . '][extra_classes]" data-label="'.$lab.'" value="'.$margs['extra_classes'].'">
                </div>';

    $struct_item.='  <div class="setting ">
                    <div class="setting-label">'.__("Extra").' '.__("Attributes").'</div>
                    <input class="text-input builder-field" type="text" name="bars[' . $margs['index'] . '][extra_attr]" data-label="'.$lab.'" value="'.$margs['extra_attr'].'">
                </div>';





	$lab = 'extra_html_before';

	$val = '';

	if(isset($margs[$lab])){
		$val = $margs[$lab];
	}
	$struct_item.='  <div class="setting ">
                    <div class="setting-label">'.__("Extra").' '.("HTML").' '.("before").'</div>
                    <textarea class="text-input builder-field" type="text" name="bars[' . $margs['index'] . ']['.$lab.']" data-label="'.$lab.'" value="" style="width: 100%; ">'.$val.'</textarea>
                </div>';



    $lab = 'extra_html';
    $struct_item.='  <div class="setting ">
                    <div class="setting-label">'.__("Extra").' '.("HTML").'</div>
                    <textarea class="text-input builder-field" type="text" name="bars[' . $margs['index'] . ']['.$lab.']" data-label="'.$lab.'" value="" style="width: 100%; ">'.$margs[$lab].'</textarea>
                </div>';




    $struct_item.='
                </div>
            </div>';







    $struct_item.='</div>';



    $struct_item.='<a href="#" class="builder-layer--btn-delete">'.__("Delete").' '.__("Item").'</a>';
    $struct_item.='</div>';
    $struct_item.='</div>';



    $sw_has_item = false;
    for($i=0;$i<10;$i++){

        if(isset($margs[$i]) && is_array($margs[$i])){

            $sw_has_item=true;

            if(isset($margs[$i][0]) && count($margs[$i][0])==1){
                $margs[$i] = $margs[$i][0];
            }
        }
    }
    if($sw_has_item){

        $struct_item.='<ol class="dd-list">';


        for($i=0;$i<10;$i++){

            if(isset($margs[$i]) && is_array($margs[$i])){

                $struct_item.=dzswtl_generate_layer_item($margs[$i]);
            }
        }

        $struct_item.='</ol>';
    }

    $struct_item.='</li>';
    return $struct_item;
























}
