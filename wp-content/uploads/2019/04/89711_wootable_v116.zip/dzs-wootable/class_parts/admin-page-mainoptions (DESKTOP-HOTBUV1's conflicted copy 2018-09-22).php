<?php

//print_r($this->mainoptions);




wp_enqueue_style( 'wp-color-picker' );
wp_enqueue_script( 'wp-color-picker' );
wp_enqueue_script( 'jquery-ui-core' );
wp_enqueue_script( 'jquery-ui-sortable' );




if (isset($_GET['dzswtl_filter_generator']) && $_GET['dzswtl_filter_generator'] == 'on') {
    include_once dirname(dirname(__FILE__)).'/shortcodegenerator/filter-generator.php';
	dzswtl_shortcode_generator();
}elseif (isset($_GET['dzswtl_con_shortcode_generator']) && $_GET['dzswtl_con_shortcode_generator'] == 'on'){

	include_once dirname(dirname(__FILE__)).'/shortcodegenerator/filter-con-generator.php';
	dzswtl_con_shortcode_generator();
}elseif (isset($_GET['dzswtl_shortcode_generator']) && $_GET['dzswtl_shortcode_generator'] == 'on'){

	include_once dirname(dirname(__FILE__)).'/shortcodegenerator/shortcode-generator.php';
	dzswtl_shortcode_generator();
}elseif (isset($_GET['dzswtl_shortcode_preview']) && $_GET['dzswtl_shortcode_preview'] == 'on'){

	include_once dirname(dirname(__FILE__)).'/shortcodegenerator/shortcode-preview.php';
	dzswtl_shortcode_preview();
}else {


//        print_r($this->mainoptions);
	?>

    <div class="wrap">
        <h2><?php echo __( 'WooTable Settings', 'dzswtl' ); ?></h2>
        <br/>

        <form class="mainsettings">

            <a class="ultibox-item button-secondary" href="<?php echo $this->thepath; ?>readme/index.html"
               data-bigwidth="1100" data-scaling="fill"
               data-bigheight="700"><?php echo __( "Documentation" ); ?></a>



            <a href="<?php echo admin_url( 'admin.php?page=dzswtl_menu&dzswtl_filter_generator=on' ); ?>" target="_blank"
               class="button-secondary action"><?php _e( 'Filter generator', 'dzswtl' ); ?></a>


            <a href="<?php echo admin_url( 'admin.php?page=dzswtl_menu&dzswtl_shortcode_generator=on' ); ?>" target="_blank"
               class="button-secondary action"><?php _e( 'Shortcode generator', 'dzswtl' ); ?></a>


            <!--



        <a href="<?php echo admin_url( 'admin.php?page=dzswtl-mo&dzswtl_shortcode_builder=on' ); ?>" target="_blank"
           class="button-secondary action"><?php _e( ' Gallery Shortcode Generator', 'dzswtl' ); ?></a>

-->


			<?php
			do_action( 'dzswtl_mainoptions_before_tabs' );
			?>

            <h3><?php echo __( "Admin Options" ); ?></h3>

            <div class="dzs-tabs auto-init" data-options="{ 'design_tabsposition' : 'top'
,design_transition: 'fade'
,design_tabswidth: 'default'
,toggle_breakpoint : '400'
,toggle_type: 'accordion'
,toggle_type: 'accordion'
,settings_enable_linking : 'on'
,settings_appendWholeContent: true
,refresh_tab_height: '1000'
}">

                <div class="dzs-tab-tobe">
                    <div class="tab-menu with-tooltip">
                        <i class="fa fa-tachometer"></i> <?php echo __( "Settings" ); ?>
                    </div>
                    <div class="tab-content">

						<?php
						if ( defined( "DZSAP_VERSION" ) ) {
							?>


                            <div class="setting">

								<?php
								$lab = 'zoomsounds_play_in_footer';
								echo DZSHelpers::generate_input_text( $lab, array( 'id'         => $lab,
								                                                   'val'        => 'off',
								                                                   'input_type' => 'hidden'
								) );
								?>
                                <h4 class="setting-label"><?php echo __( 'Play zoomsounds player in footer player ? ', 'dzswtl' ); ?></h4>
                                <div class="dzscheckbox skin-nova">
									<?php
									echo DZSHelpers::generate_input_checkbox( $lab, array( 'id'      => $lab,
									                                                       'val'     => 'on',
									                                                       'seekval' => $this->db_mainoptions[ $lab ]
									) ); ?>
                                    <label for="<?php echo $lab; ?>"></label>
                                </div>
                                <div
                                        class="sidenote"><?php echo __( 'make sure footer sticky player is enabled on that page', 'dzswtl' ); ?></div>
                            </div>

							<?php

						}
						?>



                        <div class="setting">

		                    <?php
		                    $lab = 'style_widget';
		                    echo DZSHelpers::generate_input_text( $lab, array( 'id'         => $lab,
		                                                                       'val'        => 'off',
		                                                                       'input_type' => 'hidden'
		                    ) );
		                    ?>
                            <h4 class="setting-label"><?php echo __( 'Style widget in sidebar', 'dzswtl' ); ?></h4>
                            <div class="dzscheckbox skin-nova">
			                    <?php
			                    echo DZSHelpers::generate_input_checkbox( $lab, array( 'id'      => $lab,
			                                                                           'val'     => 'on',
			                                                                           'seekval' => $this->db_mainoptions[ $lab ]
			                    ) ); ?>
                                <label for="<?php echo $lab; ?>"></label>
                            </div>
                            <div
                                    class="sidenote"><?php echo __( 'make sure footer sticky player is enabled on that page', 'dzswtl' ); ?></div>
                        </div>



                        <div class="setting">

		                    <?php
		                    $lab = 'filter_check_availability';
		                    echo DZSHelpers::generate_input_text( $lab, array( 'id'         => $lab,
		                                                                       'val'        => 'off',
		                                                                       'input_type' => 'hidden'
		                    ) );
		                    ?>
                            <h4 class="setting-label"><?php echo __( 'Check filter availability on each page', 'dzswtl' ); ?></h4>
                            <div class="dzscheckbox skin-nova">
			                    <?php
			                    echo DZSHelpers::generate_input_checkbox( $lab, array( 'id'      => $lab,
			                                                                           'val'     => 'on',
			                                                                           'seekval' => $this->db_mainoptions[ $lab ]
			                    ) ); ?>
                                <label for="<?php echo $lab; ?>"></label>
                            </div>
                            <div
                                    class="sidenote"><?php echo __( 'on each page refresh check the filter availability', 'dzswtl' ); ?></div>
                        </div>

                        <div class="setting">

		                    <?php
		                    $lab = 'filter_check_availability_recalculate_count';
		                    echo DZSHelpers::generate_input_text( $lab, array( 'id'         => $lab,
		                                                                       'val'        => 'off',
		                                                                       'input_type' => 'hidden'
		                    ) );
		                    ?>
                            <h4 class="setting-label"><?php echo __( 'Check filter availability on each page - recalculate count', 'dzswtl' ); ?></h4>
                            <div class="dzscheckbox skin-nova">
			                    <?php
			                    echo DZSHelpers::generate_input_checkbox( $lab, array( 'id'      => $lab,
			                                                                           'val'     => 'on',
			                                                                           'seekval' => $this->db_mainoptions[ $lab ]
			                    ) ); ?>
                                <label for="<?php echo $lab; ?>"></label>
                            </div>
                            <div
                                    class="sidenote"><?php echo __( 'on each page refresh check the filter availability - recalculate count', 'dzswtl' ); ?></div>
                        </div>

                        <div class="setting">


                            <h4 class="setting-label">jQuery-ui <?php echo __( 'theme', 'dzswtl' ); ?></h4>
			                    <?php

                                $lab = 'jquery_ui_theme';
                                $val = 'base';

                                if($this->db_mainoptions[$lab]){
                                    $val = $this->db_mainoptions[$lab];
                                }

                                $arr_opts = array(
                                        array(
                                                'label'=>esc_html__("Base",'dzswtl'),
                                                'value'=>'base',
                                        ),
                                        array(
                                                'label'=>esc_html__("Lightness",'dzswtl'),
                                                'value'=>'ui-lightness',
                                        ),
                                );

			                    echo DZSHelpers::generate_select( $lab,
				                    array(
				                            'id'      => $lab,
				                           'val'     => 'on',
				                           'class'     => 'dzs-style-me skin-beige',
				                           'options' => $arr_opts,
				                           'seekval' => $val,
				                    ) ); ?>
                            <div
                                    class="sidenote"><?php echo __( 'make sure footer sticky player is enabled on that page', 'dzswtl' ); ?></div>
                        </div>



                        <div class="setting">


                            <h4 class="setting-label"><?php echo __( 'Convert search field from theme', 'dzswtl' ); ?></h4>
			                    <?php

                                $lab = 'convert_search_field_from_theme';
                                $val = '';

                                if($this->db_mainoptions[$lab]){
                                    $val = $this->db_mainoptions[$lab];
                                }


			                    echo DZSHelpers::generate_input_text( $lab,
				                    array(
				                            'id'      => $lab,
				                           'val'     => '',
				                           'class'     => ' ',

				                           'seekval' => $val,
				                    ) ); ?>
                            <div
                                    class="sidenote"><?php echo __( 'convert a theme search field to wootable search field.', 'dzswtl' ); ?> ( jQuery selector )</div>
                        </div>

                        <div class="setting">


                            <h4 class="setting-label"><?php echo __( 'Replace woocommerce category page', 'dzswtl' ); ?></h4>
			                    <?php

                                $lab = 'replace_woocommerce_category_page_shortcode';
                                $val = '';

                                if($this->db_mainoptions[$lab]){
                                    $val = $this->db_mainoptions[$lab];
                                }


			                    echo DZSHelpers::generate_input_textarea( $lab,
				                    array(
				                            'id'      => $lab,
				                           'val'     => '',
				                           'class'     => ' ',

				                           'seekval' => $val,
				                    ) ); ?>
                            <div
                                    class="sidenote"><?php echo __( 'Replace woocommerce category page with this shortcode', 'dzswtl' ); ?> ( jQuery selector )</div>
                        </div>
                    </div>
                </div>

                <div class="dzs-tab-tobe tab-disabled">
                    <div class="tab-menu ">
                        &nbsp;&nbsp;
                    </div>
                    <div class="tab-content">


                    </div>
                </div>


                <div class="dzs-tab-tobe">
                    <div class="tab-menu with-tooltip">
                        <i class="fa fa-tag"></i> <?php echo esc_html__( "Attributes", 'dzswtl' ); ?>
                    </div>
                    <div class="tab-content">

						<?php

						$taxonomies = get_taxonomies( array(), 'objects' );


						$atts = array();
						foreach ( $taxonomies as $taxonomy ) {
							if ( strpos( $taxonomy->name, 'pa_' ) === 0 ){
								array_push( $atts, $taxonomy );
							}
						}
						foreach ( $atts as $att ) {


							?>
                            <div class="generate-attribute-sort-con"><span
                                    class="the-label"><?php echo $att->label; ?></span>
                            <button class="button-secondary btn-generate-attribute-sort"
                                    data-pa-slug="<?php echo $att->name; ?>"><?php echo esc_html__( "Generate", 'dzswtl' ); ?></button>
                            </div>
							<?php
						}

						print_rr( $atts );
						?>
                    </div>
                </div>


				<?php

				?>


                <!-- system check END --><?php

				do_action( 'dzswtl_db_mainoptions_extra_in_tab' );

				?>

            </div><!-- end .dzs-tabs -->


			<?php

			//        wp_enqueue_style('dzstoggle', $this->thepath . 'dzstoggle/dzstoggle.css');
			//        wp_enqueue_script('dzstoggle', $this->thepath . 'dzstoggle/dzstoggle.js');

			do_action( 'dzswtl_db_mainoptions_extra' );
			?>
            <br/>
            <a href='#'
               class="button-primary dzswtl-mo-save-mainoptions"><?php echo __( 'Save Options', 'dzswtl' ); ?></a>
        </form>

        <br>
        <br>
        <br>
        <div class="dzstoggle">
            <div class="toggle-title"><?php echo __( "Generate attribute data" ); ?></div>
            <div class="toggle-content">
                <div class="sidenote"><?php echo __( "Generate sort data for sorting attributes" ); ?></div>
                <button class="button-secondary"><?php echo __( "Generate" ); ?></button>
                <br>
                <br>
            </div>
        </div>
        <br/><br/>
        <div class="dzstoggle">
            <div class="toggle-title"><?php echo __( "Plugin Data" ); ?></div>
            <div class="toggle-content">
                <div class="sidenote"><?php echo __( "delete some plugin data" ); ?></div>
                <form action="" method="post">
                    <button name="dzswtl_action" value="delete_sample_data"
                            class="button-secondary"><?php echo __( "Delete sample data" ); ?></button>
                </form>

                <br>
                <br>
            </div>
        </div>
        <br/><br/>

        <br/>

        <div class="saveconfirmer" style=""><img alt="" style="" id="save-ajax-loading2"
                                                 src="<?php echo site_url(); ?>/wp-admin/images/wpspin_light.gif"/>
        </div>
    </div>
    <div class="clear"></div><br/>
	<?php
}