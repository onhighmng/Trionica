<?php
/*
  Plugin Name: WooCommerce shop builder - Create any shop grid / table with advanced filters
  Plugin URI: http://digitalzoomstudio.net/
  Description: The best plugin for creating custom woocommerce shop page.
  Version: 1.16
  Author: Digital Zoom Studio
  Author URI: http://digitalzoomstudio.net/
 */
include_once(dirname(__FILE__).'/dzs_functions.php');
if(!class_exists('DZSPreviewEmulator')){
    include_once(dirname(__FILE__).'/class-dzswtl.php');
}

define('DZSWTL_VERSION', '1.16');

$dzswtl = new DZSWooTable();

$dzswtl->is_preview = false;




if(function_exists('dzswtl_handle_activated_plugin')==false){
    function dzswtl_handle_activated_plugin($plugin=''){
        $redirect = false;
        if( $plugin == plugin_basename( __FILE__ ) ) {

            if (get_option('dzswtl_shown_intro')) {

            } else {

                $redirect = true;
            }

        }
        if(DZSWTL_PREVIEW=='YES'){

            $redirect = true;
        }


        if ($redirect){


//                $dzswtl->redirect_to_intro_page = true;
//                header("Location: ".admin_url( 'admin.php?page=dzswtl-about' )."");
//            exit( wp_redirect( admin_url( 'admin.php?page=dzswtl-about' ) ) );
        }
//        error_log("TRY TO SHOW");
    }
}

add_action('activated_plugin', 'dzswtl_handle_activated_plugin');
register_activation_hook(__FILE__, array($dzswtl, 'handle_plugin_activate'));