var coll_buffer=0;
var func_output='';



window.window_name = 'filter_con_generator';

function htmlEncode(arg){
    return jQuery('<div/>').text(arg).html();
}

function htmlDecode(value){
    return jQuery('<div/>').html(arg).text();
}

function get_shortcode_attr(arg, argtext){

    var regex_aattr = new RegExp(arg+'="(.*?)"');

    //console.log(regex_aattr, argtext);

    var aux = regex_aattr.exec(argtext);

    if(aux){
        var foutobj = {'full' : aux[0], 'val' : aux[1]};
        return foutobj;
    }



    return false;
}


// -- tbc

var dzswtl_arr_params_mode_video_gallery = []
var dzswtl_arr_params = []

//,'desc_count',
var dzswtl_standard_options = [];



jQuery(document).ready(function($) {


    var startinit = '';

    if (dzswtl_settings && dzswtl_settings.startSetup) {
        window.dzswtl_startinit = dzswtl_settings.startSetup;
    }


    var final_shortcode = '';

    startinit = window.dzswtl_startinit;

    console.info('startinit is ' + startinit);


    startinit = '[dzs_woo_filter feed_from="categories" type="select" flex_prop="" margin_left="" margin_right=""][dzs_woo_filter feed_from="categories" type="multiple" flex_prop="" margin_left="" margin_right=""][dzs_woo_filter feed_from="categories" type="select" flex_prop="" margin_left="" margin_right=""]';

    var coll_buffer = 0;
    var fout = '';


    $('.shortcode-field:not(.fake-input)').each(function () {
        var _t = $(this);

        window.dzswtl_standard_options.push(_t.attr('name'));
    })


    // console.warn(top.dzswtl_startinit);
    // ---- some custom code for initing the generator ( previous values )
    if (startinit) {


        var arr_settings = [];

        // console.warn(arr_settings);
        arr_settings = arr_settings.concat(dzswtl_standard_options);
        // console.warn(arr_settings);

        $('.dzswtl-admin').append('<div class="misc-initSetup"><h5>Start Setup</h5></h5><p>' + htmlEncode(startinit) + '</p></div>');


        var res;
        var lab = '';

        console.warn(arr_settings);
        for (var key in arr_settings) {

            // console.info(key);
            lab = arr_settings[key];
            res = get_shortcode_attr(lab, startinit);
            // console.info(res, lab, top.dzsp_startinit);
            if (res) {
                if (lab == 'id') {
                    lab = 'dzswtl_selectid';
                }
                if (lab == 'db') {
                    lab = 'dzswtl_selectdb';
                }
                if (lab == 'cat') {


                } else {

                    // console.info(lab);

                    var _c = $('*[name="' + lab + '"]');
                    if (lab == 'type' || lab == 'term_id') {
                        console.warn('changing now', lab, res, _c);
                    }

                    _c.val(res['val']);
                    _c.trigger('change');
                }
            }
        }

        final_shortcode = startinit;
    }


    var _feedbacker = $('.feedbacker');

    var _pShortcodeCon = $('.preview-shortcode-con').eq(0);
    var _tooltipForShortcodeEditor = $('.dzstooltip-for-shortcode-editor').eq(0);
    var _wysiwygBar = $('.wysiwyg-bar > .woo-filter-con').eq(0);

    var active_filter_ind = 0;

    var active_str_shortcode = ''
        ,startind = 0
        ,endind=0
    ;

    _feedbacker.fadeOut("slow");



    $(document).on('click','.import-sample, .hide-notice, .btn-add-filter,.dzs-woo-filter,.btn-shortcode-customizer, #insert_tests',  handle_mouse);

    // $(document).delegate('', 'change', handle_submit);



    var st = 0;





    // console.info(window.generator_settings.sample_data);

    var sample_data_arr = [];

    if (window.generator_settings && window.generator_settings.sample_data) {
        sample_data_arr = JSON.parse(window.generator_settings.sample_data);

        // console.warn(sample_data_arr);
    }


    var val = $("input[name=cat_slug]");

    var vals = String(val.val()).split(',');


    var _activeFilter = null;

    // console.warn(vals);


    var opts = $("select[name=cat_slug_select]").children('option');

    opts.each(function () {
        var _t3 = $(this);

        // console.info(_t3);

        for (var i = 0; i < vals.length; i++) {

            console.info('_t3.get(0).value -> ', _t3.get(0).value, vals[i]);
            if (_t3.get(0).value == vals[i]) {

                _t3.prop('selected', true);
            }
        }

    })

    setTimeout(function () {

        var _c = $("select[name=cat_slug_select]").get(0);

        if (_c && _c.api_recheck_value_from_input) {

            _c.api_recheck_value_from_input();
        }
    }, 1000);


    $('select[name=mode],select[name=type],select[name=linking_type]').trigger('change');


    _pShortcodeCon.html(final_shortcode);
    get_preview();


    $(window).on('scroll',handle_scroll);

    function handle_scroll(){


        st = $(window).scrollTop();

        console.info('st - ',st);


        position_tooltip();
    }

    function position_tooltip(){

        if(_activeFilter){

            _tooltipForShortcodeEditor.css({
                'top': _activeFilter.offset().top + _activeFilter.outerHeight() - st
                ,'left': _activeFilter.offset().left + 40
            })
        }
    }

    function get_preview(){


        var data = {
            action: 'dzswtl_con_generator_preview_shortcode'
            ,postdata: final_shortcode
        };


        jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: data,
            success: function(response) {
                if(typeof window.console != "undefined" ){ console.log('Ajax - submit view - ' + response); }






                _wysiwygBar.html(response);



                setTimeout(function(){
                    init_selectors()
                },500);

                if(_activeFilter){


                    _activeFilter = null;


                    _tooltipForShortcodeEditor.removeClass('active');
                }



            },
            error:function(arg){
                if(typeof window.console != "undefined" ){ console.warn('Got this from the server: ' + arg); };
            }
        });
    }

    function init_selectors(){

        dzssel_init('select.dzs-style-me', {init_each: true});
    }
    String.prototype.insertAt=function(index, string) {
        return this.substr(0, index) + string + this.substr(index);
    }

    window.replace_with_updated_shortcode = function(arg){


        // console.info('replace_with_updated_shortcode arg - ',arg);
        // console.info('startind - ',startind, endind);
        // console.info('final_shortcode - ',final_shortcode);


        var aux = final_shortcode;


        // final_shortcode = String(final_shortcode).slice(0,startind-1) + String(final_shortcode).slice(endind+2,final_shortcode.length-1);
        // console.warn('String(final_shortcode).slice(0,startind) - ',String(final_shortcode).slice(0,startind));
        // console.warn('String(final_shortcode).slice(endind,final_shortcode.length) - ',String(final_shortcode).slice(endind,final_shortcode.length));

        final_shortcode = String(aux).slice(0,startind) + String(aux).slice(endind,final_shortcode.length);


        final_shortcode = String(final_shortcode).insertAt(startind, arg);

        // console.warn('final_shortcode - ',final_shortcode);

        _pShortcodeCon.html(final_shortcode);
        get_preview();



    }
    function handle_mouse(e) {
        var _t = $(this);

        if (e.type == 'click') {
            console.info(_t);

            if (_t.attr('id')=='insert_tests') {

                click_insert_tests();

                return false;
            }
            if (_t.hasClass('btn-shortcode-customizer')) {



                var parsel = '';

                parsel+='&sel=' + encodeURIComponent(active_str_shortcode);

                window.open_ultibox(null,{

                    type: 'iframe'
                    ,source: dzswtl_settings.shortcode_generator_url + parsel
                    ,scaling: 'fill' // -- this is the under description
                    ,suggested_width: 800 // -- this is the under description
                    ,suggested_height: 600 // -- this is the under description
                    ,item: null // -- we can pass the items from here too

                });


                _pShortcodeCon.html(final_shortcode);

                return false;
            }
            if (_t.hasClass('dzs-woo-filter')) {



                if(_t.hasClass('active-selected')==false){

                    _t.parent().children().removeClass('active-selected');
                    _t.addClass('active-selected');

                    var ind = _t.parent().children().index(_t);

                    // console.info('ind - ',ind);

                    var regex = /\[dzs_woo_filter.*?\]/g;



                    var matches = [];
                    var aux = null;
                    while(aux = regex.exec(final_shortcode)){


                        matches.push(aux);
                    }

                    startind = matches[ind].index;
                    endind = startind + matches[ind][0].length;


                    active_str_shortcode = final_shortcode.substr(startind,endind)
                    console.info('matches - ',matches,'startind - ',startind,endind);
                    console.info('str - ',active_str_shortcode);


                    _activeFilter = _t;


                    _tooltipForShortcodeEditor.addClass('active');

                    console.info('_activeFilter.offset().top - ',_activeFilter.offset().top, _activeFilter);

                    _tooltipForShortcodeEditor.css({
                        'top': _activeFilter.offset().top + _activeFilter.outerHeight() - st
                        ,'left': _activeFilter.offset().left + 40
                    })

                }else{

                    _t.removeClass('active-selected');

                    _activeFilter = null;

                    _tooltipForShortcodeEditor.removeClass('active');

                    active_str_shortcode = '';
                }
            }
            if (_t.hasClass('btn-add-filter')) {


                final_shortcode+='[dzs_woo_filter feed_from="categories" type="select" flex_prop="" margin_left="" margin_right=""]';

                _pShortcodeCon.html(final_shortcode);


                get_preview();

                return false;
            }
            if (_t.hasClass('import-sample')) {

                var fout = '';
                if (_t.hasClass('import-sample-1')) {

                    if (sample_data_arr) {


                    }
                }
                tinymce_add_content(fout);
                return false;
            }


        }
    }


    function handle_submit(e){
        var _t = $(this);

        if(e.type=='change'){
            // console.info(_t);
            if(_t.attr('name')=='post_type'){
                // console.info("ceva");


                var data = {
                    action: 'dzswtl_get_term_cats'
                    ,post_type: _t.val()
                };


                jQuery.ajax({
                    type: "POST",
                    url: ajaxurl,
                    data: data,
                    success: function(response) {
                        if(typeof window.console != "undefined" ){ console.log('Ajax - submit view - ' + response); }

                        try{
                            response =JSON.parse(response);
                            // console.info(response);

                            $('select[name=cat_slug]').eq(0).val('');
                            $('select[name=cat_slug_select]').eq(0).val('');



                            var __c = $("select[name=cat_slug_select]").get(0);

                            if(__c && __c.api_recheck_value_from_input){

                                __c.api_recheck_value_from_input();
                            }

                            var _c = $('select[name=cat_slug_select]').eq(0);

                            _c.html('');
                            var aux_html = '<option value="">All categories</option>';
                            var aux_html_without_all = '';
                            for(var lab in response){
                                var cat = response[lab];





                                aux_html_without_all+='<option value="'+cat.value+'">'+cat.label+'</option>';


                            }
                            aux_html+=aux_html_without_all;

                            // console.warn('aux_html - ',aux_html);
                            _c.html(aux_html);


                            if(__c && __c.api_recheck_value_from_input){

                                __c.api_recheck_value_from_input();
                            }






                        }catch (e){

                        }





                    },
                    error:function(arg){
                        if(typeof window.console != "undefined" ){ console.warn('Got this from the server: ' + arg); };
                    }
                });



            }
            if(_t.attr('name')=='category_multiplication'){
                if(_t.val()=='multiple'){
                    $("select[name=cat_slug_select]").parent().hide();
                }else{

                    $("select[name=cat_slug_select]").parent().show();
                }
            }
        }
        if(e.type=='submit'){
            // console.info(_t);

            if(_t.hasClass('install-sample-data')){

                return false;
            }

            if(_t.hasClass('remove-sample-data')){

                var data = {
                    action: 'dzswtl_remove_sample_data'
                    ,postdata: _t.serialize()
                };


                jQuery.ajax({
                    type: "POST",
                    url: ajaxurl,
                    data: data,
                    success: function(response) {
                        if(typeof window.console != "undefined" ){ console.log('Ajax - submit view - ' + response); }

                        //console.info(response);
                        show_notice(response);


                        setTimeout(function(){
                            window.location.reload();
                        },100);

                    },
                    error:function(arg){
                        if(typeof window.console != "undefined" ){ console.warn('Got this from the server: ' + arg); };
                    }
                });

                return false;
            }
        }
    }




    function prepare_fout(){



        if(final_shortcode.indexOf('dzs_woo_filter_con')==-1){

            final_shortcode= '[dzs_woo_filter_con extra_classes="flex-it display-flex"]'+final_shortcode+'[/dzs_woo_filter_con]';
        }

    }


    function tinymce_add_content(arg){
        //console.log('tinymce_add_content()', arg);
        if(top==window){

            jQuery('.shortcode-output').text(arg);
        }else{


            if(top.dzswtl_widget_target_input){
                top.dzswtl_widget_target_input.val(arg);

                top.dzswtl_widget_target_input = null;


            }else{


                if(typeof(parent.dzswtl_receiver)=='function'){
                    parent.dzswtl_receiver(arg);
                }
            }

        }

    }

    function click_insert_tests(e){

        console.info('click_insert_tests');
        //console.log(jQuery('#mainsettings').serialize());
        prepare_fout();
        tinymce_add_content(final_shortcode);
        return false;
    }
})
