var coll_buffer=0;
var func_output='';



function htmlEncode(arg){
    return jQuery('<div/>').text(arg).html();
}

function htmlDecode(value){
    return jQuery('<div/>').html(arg).text();
}

function get_shortcode_attr(arg, argtext){

    var regex_aattr = new RegExp(arg+'="(.*?)"');

    //console.log(regex_aattr, argtext);

    var aux = regex_aattr.exec(argtext);

    if(aux){
        var foutobj = {'full' : aux[0], 'val' : aux[1]};
        return foutobj;
    }



    return false;
}


// -- tbc

var dzswtl_arr_params_mode_video_gallery = []
var dzswtl_arr_params = []

//,'desc_count',
var dzswtl_standard_options = [];



jQuery(document).ready(function($){




    var startinit = '';

    if(dzswtl_settings && dzswtl_settings.startSetup){
        window.dzswtl_startinit = dzswtl_settings.startSetup;
    }

    startinit = window.dzswtl_startinit;

    console.info('startinit is '+startinit);

    var coll_buffer=0;
    var fout='';




    $('.shortcode-field:not(.fake-input)').each(function(){
        var _t = $(this);

        window.dzswtl_standard_options.push(_t.attr('name'));
    })


    // console.warn(top.dzswtl_startinit);
    // ---- some custom code for initing the generator ( previous values )
    if(startinit){


        var arr_settings = [];

        // console.warn(arr_settings);
        arr_settings = arr_settings.concat(dzswtl_standard_options);
        // console.warn(arr_settings);

        $('.dzswtl-admin').append('<div class="misc-initSetup"><h5>Start Setup</h5></h5><p>'+htmlEncode(startinit)+'</p></div>');


        var res;
        var lab='';

        console.warn(arr_settings);
        for(var key in arr_settings){

            // console.info(key);
            lab = arr_settings[key];
            res = get_shortcode_attr(lab, startinit);
           // console.info(res, lab, top.dzsp_startinit);
            if(res){
                if(lab=='id'){
                    lab = 'dzswtl_selectid';
                }
                if(lab=='db'){
                    lab = 'dzswtl_selectdb';
                }
                if(lab=='cat'){




                }else{

                    // console.info(lab);

                    var _c = $('*[name="'+lab+'"]');
                    if(lab=='type' || lab=='term_id'){
                        console.warn('changing now', lab, res, _c);
                    }

                    _c.val(res['val']);
                    _c.trigger('change');
                }
            }
        }
    }



    var _feedbacker = $('.feedbacker');

    _feedbacker.fadeOut("slow");
    $('#insert_tests').unbind('click');
    $('#insert_tests').bind('click', click_insert_tests);

    $(document).delegate('.import-sample, .hide-notice', 'click', handle_mouse);
    $(document).delegate('select[name=mode],select[name=type],select[name=linking_type]', 'change', handle_submit);
    // $(document).delegate('', 'change', handle_submit);

    $(document).on('change.dzsdep','.dzs-dependency-field', handle_change_dependency);
    $(document).on('submit','form.install-sample-data, form.remove-sample-data', handle_submit);


    setTimeout(function(){

        $(document).on('change','select[name=category_multiplication]', handle_submit);
    },50);
    setTimeout(function(){

        $(document).on('change','*[name=post_type]', handle_submit);
    },5000);


    // console.info(window.generator_settings.sample_data);

    var sample_data_arr = [];

    if(window.generator_settings && window.generator_settings.sample_data){
        sample_data_arr = JSON.parse(window.generator_settings.sample_data);

        // console.warn(sample_data_arr);
    }










    var val = $("input[name=cat_slug]");

    var vals = String(val.val()).split(',');

    // console.warn(vals);







    var opts = $("select[name=cat_slug_select]").children('option');

    opts.each(function(){
        var _t3 = $(this);

        // console.info(_t3);

        for(var i=0;i<vals.length;i++){

            console.info('_t3.get(0).value -> ',_t3.get(0).value, vals[i]);
            if(_t3.get(0).value == vals[i]){

                _t3.prop('selected',true);
            }
        }

    })

    setTimeout(function(){

        var _c = $("select[name=cat_slug_select]").get(0);

        if(_c && _c.api_recheck_value_from_input){

            _c.api_recheck_value_from_input();
        }
    },1000);










    $('select[name=mode],select[name=type],select[name=linking_type]').trigger('change');






    function handle_mouse(e){
        var _t = $(this);

        if(e.type=='click'){
            console.info(_t);

            if(_t.hasClass('import-sample')){

                var fout = '';
                if(_t.hasClass('import-sample-1')){

                    if(sample_data_arr){


                    }
                }
                tinymce_add_content(fout);
                return false;
            }



            if(_t.hasClass('hide-notice')){


                var data = {
                    action: 'dzswtl_ajax_hide_notice'
                    ,postdata: _t.attr('data-notice')
                };


                $.post(ajaxurl, data, function(response) {
                    if(window.console !=undefined ){
                        console.log('Got this from the server: ' + response);
                    }
                });

                _t.parent().parent().parent().removeClass('active');
                _t.parent().remove();


                return false;
            }



        }
    }

    function check_dependency_settings(){
        $('*[data-dependency]').each(function(){
            var _t = $(this);


            // console.info(_t);
            var dep_arr = {};




            try{
                JSON.parse(_t.attr('data-dependency'));


                if(dep_arr[0]){
                    var _c = $('*[name="'+dep_arr[0].lab+'"]').eq(0);

                    // console.info(_c, dep_arr[0].val);

                    var sw_show = false;

                    for(var i3 in dep_arr[0].val){
                        if(_c.val() == dep_arr[0].val[i3]){
                            sw_show=true;
                            break;

                        }
                    }

                    if(sw_show){
                        _t.show();
                    }else{
                        _t.hide();
                    }


                }
            }catch(err){
                console.error('not json - ', _t.attr('data-dependency'))
            }

            // console.warn(dep_arr);

        })
    }

    function handle_change_dependency(e){

        var _t = $(this);

        if(e.type=='change'){

            if(_t.hasClass('dzs-dependency-field')){
                // console.info("ceva");
                check_dependency_settings();
            }
        }
    }
    function handle_submit(e){
        var _t = $(this);

        if(e.type=='change'){
            // console.info(_t);
            if(_t.attr('name')=='post_type'){
                // console.info("ceva");


                var data = {
                    action: 'dzswtl_get_term_cats'
                    ,post_type: _t.val()
                };


                jQuery.ajax({
                    type: "POST",
                    url: ajaxurl,
                    data: data,
                    success: function(response) {
                        if(typeof window.console != "undefined" ){ console.log('Ajax - submit view - ' + response); }

                        try{
                            response =JSON.parse(response);
                            // console.info(response);

                            $('select[name=cat_slug]').eq(0).val('');
                            $('select[name=cat_slug_select]').eq(0).val('');



                            var __c = $("select[name=cat_slug_select]").get(0);

                            if(__c && __c.api_recheck_value_from_input){

                                __c.api_recheck_value_from_input();
                            }

                            var _c = $('select[name=cat_slug_select]').eq(0);

                            _c.html('');
                            var aux_html = '<option value="">All categories</option>';
                            var aux_html_without_all = '';
                            for(var lab in response){
                                var cat = response[lab];





                                aux_html_without_all+='<option value="'+cat.value+'">'+cat.label+'</option>';


                            }
                            aux_html+=aux_html_without_all;

                            // console.warn('aux_html - ',aux_html);
                            _c.html(aux_html);


                            if(__c && __c.api_recheck_value_from_input){

                                __c.api_recheck_value_from_input();
                            }






                        }catch (e){

                        }





                    },
                    error:function(arg){
                        if(typeof window.console != "undefined" ){ console.warn('Got this from the server: ' + arg); };
                    }
                });



            }
            if(_t.attr('name')=='category_multiplication'){
                if(_t.val()=='multiple'){
                    $("select[name=cat_slug_select]").parent().hide();
                }else{

                    $("select[name=cat_slug_select]").parent().show();
                }
            }
        }



        var dzsap_players = document.querySelectorAll(".audio");

        dzsap_players.forEach(function(_c3) { _c3.api_handleResize(); });
        document.addEventListener("DOMContentLoaded", function(e) {

            jQuery(document).on('click', '.wpProQuiz_QuestionButton', function (e) {

                function hide_all_but_visible(_c3) {
                    if ($(_c3).is(":hidden")) {
                        _c3.classList.add('not-real-inited');
                        _c3.classList.remove('real-inited');
                    } else {
                        _c3.classList.remove('not-real-inited');
                        _c3.classList.add('real-inited');
                    }

                }


                var dzsap_players = document.querySelectorAll(".audioplayer");
                setTimeout(function () {

                    dzsap_players.forEach(hide_all_but_visible);
                }, 1500);


                dzsap_players.forEach(hide_all_but_visible);

            })
        })






        if(e.type=='submit'){
            // console.info(_t);

            if(_t.hasClass('install-sample-data')){

                var data = {
                    action: 'dzswtl_install_sample_data'
                    ,postdata: _t.serialize()
                };


                jQuery.ajax({
                    type: "POST",
                    url: ajaxurl,
                    data: data,
                    success: function(response) {
                        if(typeof window.console != "undefined" ){ console.log('Ajax - submit view - ' + response); }

                        //console.info(response);
                        show_notice(response);


                        setTimeout(function(){
                            window.location.reload();
                        },100);

                    },
                    error:function(arg){
                        if(typeof window.console != "undefined" ){ console.warn('Got this from the server: ' + arg); };
                    }
                });

                return false;
            }

            if(_t.hasClass('remove-sample-data')){

                var data = {
                    action: 'dzswtl_remove_sample_data'
                    ,postdata: _t.serialize()
                };


                jQuery.ajax({
                    type: "POST",
                    url: ajaxurl,
                    data: data,
                    success: function(response) {
                        if(typeof window.console != "undefined" ){ console.log('Ajax - submit view - ' + response); }

                        //console.info(response);
                        show_notice(response);


                        setTimeout(function(){
                            window.location.reload();
                        },100);

                    },
                    error:function(arg){
                        if(typeof window.console != "undefined" ){ console.warn('Got this from the server: ' + arg); };
                    }
                });

                return false;
            }
        }
    }



    function show_notice(response){


        if(response.indexOf('error -')==0){
            _feedbacker.addClass('is-error');
            _feedbacker.html(response.substr(7));
            _feedbacker.fadeIn('fast');

            setTimeout(function(){

                _feedbacker.fadeOut('slow');
            },1500)
        }
        if(response.indexOf('success -')==0){
            _feedbacker.removeClass('is-error');
            _feedbacker.html(response.substr(9));
            _feedbacker.fadeIn('fast');

            setTimeout(function(){

                _feedbacker.fadeOut('slow');
            },1500)
        }
    }
});
function change_selectdb(e){
    var _t = jQuery(this);

    //console.info(_t.val());



    jQuery('#save-ajax-loading').css('opacity', '1');
    var mainarray = _t.val();
    var data = {
        action: 'dzswtl_get_db_gals',
        postdata: mainarray
    };
    jQuery('.saveconfirmer').html('Options saved.');
    jQuery('.saveconfirmer').fadeIn('fast').delay(2000).fadeOut('fast');
    jQuery.post(ajaxurl, data, function(response) {
        if(window.console !=undefined ){  console.log('Got this from the server: ' + response); }
        jQuery('#save-ajax-loading').css('opacity', '0');

        var aux = '';
        var auxa = response.split(';');
        for(i=0;i<auxa.length;i++){
            aux+='<option>'+auxa[i]+'</option>'
        }
        $('select[name=dzswtl_selectid]').html(aux);
        $('select[name=dzswtl_selectid]').trigger('change');

    });

    return false;

}


function tinymce_add_content(arg){
    //console.log('tinymce_add_content()', arg);
    if(top==window){

        jQuery('.shortcode-output').text(arg);
    }else{


        if(top.dzswtl_widget_shortcode){
            top.dzswtl_widget_shortcode.val(arg);

            top.dzswtl_widget_shortcode = null;

            console.info(top.close_zoombox2);
            if(top.close_zoombox2){
                top.close_zoombox2();
            }
        }else{

            console.info(top.dzswtl_receiver);
            if(typeof(top.dzswtl_receiver)=='function'){
                top.dzswtl_receiver(arg);
            }
        }

    }

}

function click_insert_tests(e){

    //console.info('click_insert_tests');
    //console.log(jQuery('#mainsettings').serialize());
    prepare_fout();
    tinymce_add_content(fout);
    return false;
}

function add_attribute_to_shortcode(lab){
    var $ = jQuery;

    var _c = $('*[name='+lab+']');
    var fout2 = '';
    if(_c.val()){
        fout2+=' '+lab+'="' + _c.val() + '"';
    }

    return fout2;
}

var fout='';
function prepare_fout(){
    var $ = jQuery;
    fout='[dzs_woo_filter';
    var _c
        ,_c2
        ,lab=''
        ,val=''
        ;



    /*
     _c = $('input[name=settings_width]');
     if(_c.val()!=''){
     fout+=' width=' + _c.val() + '';
     }
     _c = $('input[name=settings_height]');
     if(_c.val()!=''){
     fout+=' height=' + _c.val() + '';
     }
     */

        
    lab = 'item_skin';
    _c = $('select[name='+lab+']');
    val = _c.val();
    if(val){
        fout+=' '+lab+'="' + val + '"';

  }


    for(var key in dzswtl_standard_options){

        lab = dzswtl_standard_options[key];



        if(lab!='mode' && lab!='item_skin'){
            _c = $('*[name='+lab+']');


            // console.info(_c, _c.parent().hasClass('setting'), _c.parent().css('display')=='none');


            var _con = null;


            if( _c.parent().hasClass('setting') ){

                _con = _c.parent()
            }

            if( _c.parent().parent().hasClass('setting') ){

                _con = _c.parent().parent();
            }

            if( ( _con && _con.css('display')=='none') == false  ){

                if(_c.val()){
                    fout+=' '+lab+'="' + _c.val() + '"';
                }
            }

        }

    }


    lab = 'vpconfig';
    _c = $('*[name='+lab+']');
    if(_c.val()){
        fout+=' '+lab+'="' + _c.val() + '"';
    }


    // if($('select[name=dzswtl_settings_separation_mode]').val()!='normal'){
    //     _c = $('select[name=dzswtl_settings_separation_mode]');
    //     if(_c.val()!=''){
    //         fout+=' settings_separation_mode="' + _c.val() + '"';
    //     }
    //     _c = $('input[name=dzswtl_settings_separation_pages_number]');
    //     if(_c.val()!=''){
    //         fout+=' settings_separation_pages_number="' + _c.val() + '"';
    //     }
    // }

    fout+=']';
}

