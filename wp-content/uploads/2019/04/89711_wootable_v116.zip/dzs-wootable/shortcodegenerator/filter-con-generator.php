<?php


//echo 'ceva';

function dzswtl_con_shortcode_generator(){

    global $dzswtl;


    $startinit = '';



	wp_enqueue_style('dzswtl_shortcode_builder', $dzswtl->base_url . 'shortcodegenerator/filter-generator.css');
	wp_enqueue_script('dzswtl_shortcode_builder', $dzswtl->base_url . 'shortcodegenerator/filter-con-generator.js');


	wp_enqueue_style('dzswtl', $dzswtl->base_url . "libs/dzswootable/dzswootable.css");
	wp_enqueue_script('dzswtl', $dzswtl->base_url . "libs/dzswootable/dzswootable.js");
	wp_enqueue_script('dzsselector', $dzswtl->base_url . 'libs/dzsselector/dzsselector.js');
	wp_enqueue_style('dzsselector', $dzswtl->base_url . 'libs/dzsselector/dzsselector.css');


	wp_enqueue_style('dzstooltip', $dzswtl->base_url . 'libs/dzstooltip/dzstooltip.css');

    if(isset($_GET['sel'])){
        $startinit = stripslashes($_GET['sel']);
    }

    $url_admin = get_admin_url();
//<script src="<?php echo site_url(); "></script>


    ?>
    <script>

        window.dzswtl_startinit = '<?php
                        echo $startinit;

             ?>';

    </script>

<div class="sc-con sc-con-for-filters-con">
    <div class="sc-menu">

        <h1><?php echo esc_html__("Container builder",'dzswtl'); ?></h1>

        <br>


        <h4><?php echo esc_html__("Shortcode",'dzswtl'); ?></h4>
        <pre class="preview-shortcode-con" style="white-space: pre-line;"></pre>

        <h4><?php echo esc_html__("Build",'dzswtl'); ?></h4>
        <div class="wysiwyg-bar">
<div class="woo-filter-con"></div>
        </div>
        <div class="buttons-con">
            <button class="button-secondary btn-add-filter"><?php echo esc_html__("Add filter",'dzswtl'); ?></button>
        </div>





        <div>
            <div class="dzstooltip dzstooltip-for-shortcode-editor arrow-top talign-start style-default color-dark-light  " style="width: auto; ; position: fixed; top:0; left:0;">

                <div class="dzstooltip--inner">

                    <button class="button-secondary btn-shortcode-customizer"><?php echo esc_html__("Customize shortcode",'dzswtl'); ?></button>
                </div>
            </div>
        </div>




        <div class="clear"></div>
        <br/>
        <br/>
        <button id="insert_tests" class="button-primary insert-tests"><?php echo esc_html__("Insert Shortcode",'dzswtl'); ?></button>
        <div class="shortcode-output"></div>
    </div>
    <div class="feedbacker"><i class="fa fa-circle-o-notch fa-spin"></i><?php echo __(" Loading... "); ?></div>










</div><?php
}