<?php


//echo 'ceva';

function dzswtl_shortcode_generator(){

    global $dzswtl;


    $startinit = '';

	wp_enqueue_script('dzsselector', $dzswtl->base_url . 'libs/dzsselector/dzsselector.js');
	wp_enqueue_style('dzsselector', $dzswtl->base_url . 'libs/dzsselector/dzsselector.css');


	wp_enqueue_style('dzswtl_shortcode_builder', $dzswtl->base_url . 'shortcodegenerator/shortcode-generator.css');
	wp_enqueue_script('dzswtl_shortcode_builder', $dzswtl->base_url . 'shortcodegenerator/shortcode-generator.js');


	wp_enqueue_style('dzstoggle', $dzswtl->base_url . 'libs/dzstoggle/dzstoggle.css');
	wp_enqueue_script('dzstoggle', $dzswtl->base_url . "libs/dzstoggle/dzstoggle.js");

    if(isset($_GET['sel'])){
        $startinit = stripslashes($_GET['sel']);
    }

    $url_admin = get_admin_url();
//<script src="<?php echo site_url(); "></script>


    ?>
    <script>

        window.dzswtl_startinit = '<?php
                        echo $startinit;

             ?>';

    </script>

<div class="sc-con sc-con-for-showcase-builder">
    <div class="sc-menu">






	<?php
	$lab = 'layout';
	?>
    <?php


    $wpqargs = array(
	    'post_type'=>'dzswtl_list_layout',
	    'posts_per_page'=>'-1',
    );

    $query = new WP_Query($wpqargs);

    $pos = $query->posts;

//    print_rr($query);
//    print_rr($query->posts);
    ?>
        <div class="setting  mode-any" >
            <h4><?php echo __("Layout"); ?></h4>

    <select class="dzs-style-me  opener-listbuttons  shortcode-field" name="<?php echo $lab; ?>">
        <?php
        foreach ($pos as $po){
            echo '<option value="'.$po->post_name.'">'.$po->post_name.'</option>';
        }
        ?>
    </select>
    <ul class="dzs-style-me-feeder">

        <?php

        foreach ($pos as $po){
	        echo '<div class="bigoption bigoption-half-w">
            <div class="option-con">';


//	        echo '<iframe width="100%" height="100%" src="'.admin_url('admin.php?page='.$dzswtl->adminpagename_mainoptions.'&dzswtl_shortcode_preview=on&layout='.$po->post_name.'').'"></iframe>';



	        $layout = $po->post_name;


	        echo $dzswtl->shortcode_woo_table(array(
		        'layout'=>$layout,
		        'get_preview_data'=>'on',
	        ));


	        echo '<span class="option-label">'.$po->post_title.'</span></div>
        </div>';
        }
        ?>

    </ul>
        </div>






	<?php
	$lab = 'posts_per_page';
	?>

    <div class="setting mode-any  " >
        <h4><?php echo esc_html__("Posts per page",'dzswtl');?></h4>

		<?php




		?>
        <input class="shortcode-field regular-text" name="<?php echo $lab; ?>" value="5"/>
    </div>



	<?php
	$lab = 'show_filtered_by';
	?>

    <div class="setting  mode-any" >
        <h4><?php echo __("Show filtered by"); ?></h4>
		<?php




		$arr_opts = array(
			array(
				'value'=>'on',
				'label'=>__("Default"),
			),
			array(
				'value'=>'off',
				'label'=>__("Disable"),
			),


		);


		echo DZSHelpers::generate_select($lab, array(
			'options'=>$arr_opts,
			'class'=>'dzs-style-me skin-beige  shortcode-field',
			'seekval'=>'',
		));
		?>

    </div>









    <div class="clear"></div>
        <br/>
        <br/>
        <button id="insert_tests" class="button-primary insert-tests"><?php echo __("Insert Shortcode"); ?></button>
        <div class="shortcode-output"></div>
    </div>
    <div class="feedbacker"><i class="fa fa-circle-o-notch fa-spin"></i><?php echo __(" Loading... "); ?></div>











</div><?php
}