<?php


//echo 'ceva';

function dzswtl_shortcode_preview(){

    global $dzswtl;


    $startinit = '';



	wp_enqueue_style('dzswtl_shortcode_builder', $dzswtl->base_url . 'shortcodegenerator/shortcode-generator.css');
	wp_enqueue_script('dzswtl_shortcode_builder', $dzswtl->base_url . 'shortcodegenerator/shortcode-generator.js');



	wp_enqueue_style('dzswtl', $dzswtl->base_url . "libs/dzswootable/dzswootable.css");
	wp_enqueue_script('dzswtl', $dzswtl->base_url . "libs/dzswootable/dzswootable.js");
//	wp_enqueue_style('dzstoggle', $dzswtl->base_url . 'libs/dzstoggle/dzstoggle.css');
//	wp_enqueue_script('dzstoggle', $dzswtl->base_url . "libs/dzstoggle/dzstoggle.js");

    if(isset($_GET['sel'])){
        $startinit = stripslashes($_GET['sel']);
    }

    $url_admin = get_admin_url();
//<script src="<?php echo site_url(); "></script>


    ?>
    <script>

        window.dzswtl_startinit = '<?php
                        echo $startinit;

             ?>';

    </script>
<div class="sc-con sc-con-for-shortcode-preview">
    <?php

    $layout = 'default';

    if(isset($_GET['layout'])){
	    $layout = $_GET['layout'];
    }

    echo $dzswtl->shortcode_woo_table(array(
	    'layout'=>$layout,
	    'get_preview_data'=>'on',
    ));

    ?>
</div><?php
}