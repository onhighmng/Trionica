// console.log('ceva alceva');

window.htmleditor_sel = 'notset';
window.mceeditor_sel = 'notset';
window.dzswtl_widget_shortcode = null;

jQuery(document).ready(function($){
    if(typeof(dzswtl_settings)=='undefined'){
        if(window.console){ console.log('dzswtl_settings not defined'); };
        return;
    }




    // <circle cx="256" cy="256" r="253.44"/>


    $('#wp-content-media-buttons').append('<button type="button" id="dzswtl-shortcode-generator" class="dzswtl-shortcode-btn dzs-shortcode-button button " data-editor="content"><span class="the-icon"><svg enable-background="new 0 0 26 26" id="Слой_1" version="1.1" viewBox="0 0 26 26" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M22.6835938,7.1357422c-0.0253906-0.3955078-0.3525391-0.703125-0.7490234-0.703125h-3.9697266V5.2597656  C17.9648438,2.9111328,15.7373047,1,13,1S8.0351563,2.9111328,8.0351563,5.2597656v1.1728516H4.0654297  c-0.3964844,0-0.7236328,0.3076172-0.7490234,0.703125L2.2509766,24.203125  c-0.0126953,0.2070313,0.0605469,0.4091797,0.2021484,0.5605469C2.5947266,24.9140625,2.7929688,25,3,25h20  c0.2070313,0,0.4052734-0.0859375,0.546875-0.2363281c0.1416016-0.1513672,0.2148438-0.3535156,0.2021484-0.5605469  L22.6835938,7.1357422z M9.5351563,5.2597656C9.5351563,3.7382813,11.0898438,2.5,13,2.5s3.4648438,1.2382813,3.4648438,2.7597656  v1.1728516H9.5351563V5.2597656z M8.0351563,7.9326172v1.6289063c0,0.4140625,0.3359375,0.75,0.75,0.75s0.75-0.3359375,0.75-0.75  V7.9326172h6.9296875v1.6289063c0,0.4140625,0.3359375,0.75,0.75,0.75s0.75-0.3359375,0.75-0.75V7.9326172h3.2646484  l0.6498413,10.4003906H4.1206665L4.7705078,7.9326172H8.0351563z M3.7978516,23.5l0.260376-4.1669922h17.8835449L22.2021484,23.5  H3.7978516z" fill="#1D1D1B"/></svg></span> <span class="the-label"> '+dzswtl_settings.translate_add_shortcode+'</span></button>');


    $('#wp-content-media-buttons').append('<button type="button" id="dzswtl-filter-generator" class="dzswtl-shortcode-btn dzs-shortcode-button button " data-editor="content"><span class="the-icon" style=""><svg style="margin-top: 1px; margin-left:1px; position:relative;" height="32px" version="1.1" viewBox="0 0 32 32" width="32px" xmlns="http://www.w3.org/2000/svg" xmlns:sketch="http://www.bohemiancoding.com/sketch/ns" xmlns:xlink="http://www.w3.org/1999/xlink"><title/><desc/><defs/><g fill="none" fill-rule="evenodd" id="Page-1" stroke="none" stroke-width="1"><g fill="#929292" id="icon-146-tag"><path d="M12,4 L3.99961498,4 C2.89525812,4 2,4.88743329 2,5.99961498 L2,14 L15.3809027,27.3809027 C16.1646418,28.1646418 17.433119,28.1668566 18.2115341,27.3884415 L25.3884415,20.2115341 C26.168017,19.4319586 26.1640508,18.1640508 25.3809027,17.3809027 L12,4 L12,4 Z M7.5,11 C8.32842717,11 9,10.3284272 9,9.5 C9,8.67157283 8.32842717,8 7.5,8 C6.67157283,8 6,8.67157283 6,9.5 C6,10.3284272 6.67157283,11 7.5,11 L7.5,11 Z" id="tag"/></g></g></svg></span> <span class="the-label"> '+dzswtl_settings.translate_add_filter+'</span></button>');





    $('#dzswtl-filter-generator').bind('click', function(){
        //tb_show('ZSVG Shortcodes', dzswtl_settings.thepath + 'tinymce/popupiframe.php?width=630&height=800');


        var parsel = '';
        if(jQuery('#wp-content-wrap').hasClass('tmce-active') && window.tinyMCE ){

            //console.log(window.tinyMCE.activeEditor);
            var ed = window.tinyMCE.activeEditor;
            var sel=ed.selection.getContent();

            if(sel!=''){
                parsel+='&sel=' + encodeURIComponent(sel);
                window.mceeditor_sel = sel;
            }else{
                window.mceeditor_sel = '';
            }
            //console.log(aux);


            window.htmleditor_sel = 'notset';


        }else{




            var textarea = document.getElementById("content");
            var start = textarea.selectionStart;
            var end = textarea.selectionEnd;
            var sel = textarea.value.substring(start, end);

            //console.log(sel);

            //textarea.value = 'ceva';
            if(sel!=''){
                parsel+='&sel=' + encodeURIComponent(sel);
                window.htmleditor_sel = sel;
            }else{
                window.htmleditor_sel = '';
            }

            window.mceeditor_sel = 'notset';
        }

        window.open_ultibox(null,{

            type: 'iframe'
            ,source: dzswtl_settings.filter_generator_url + parsel
            ,scaling: 'fill' // -- this is the under description
            ,suggested_width: 800 // -- this is the under description
            ,suggested_height: 600 // -- this is the under description
            ,item: null // -- we can pass the items from here too

        })



        return false;
    })

    $('#dzswtl-shortcode-generator').bind('click', function(){
        //tb_show('ZSVG Shortcodes', dzswtl_settings.thepath + 'tinymce/popupiframe.php?width=630&height=800');


        var parsel = '';
        if(jQuery('#wp-content-wrap').hasClass('tmce-active') && window.tinyMCE ){

            //console.log(window.tinyMCE.activeEditor);
            var ed = window.tinyMCE.activeEditor;
            var sel=ed.selection.getContent();

            if(sel!=''){
                parsel+='&sel=' + encodeURIComponent(sel);
                window.mceeditor_sel = sel;
            }else{
                window.mceeditor_sel = '';
            }
            //console.log(aux);


            window.htmleditor_sel = 'notset';


        }else{




            var textarea = document.getElementById("content");
            var start = textarea.selectionStart;
            var end = textarea.selectionEnd;
            var sel = textarea.value.substring(start, end);

            //console.log(sel);

            //textarea.value = 'ceva';
            if(sel!=''){
                parsel+='&sel=' + encodeURIComponent(sel);
                window.htmleditor_sel = sel;
            }else{
                window.htmleditor_sel = '';
            }

            window.mceeditor_sel = 'notset';
        }

        window.open_ultibox(null,{

            type: 'iframe'
            ,source: dzswtl_settings.shortcode_generator_url + parsel
            ,scaling: 'fill' // -- this is the under description
            ,suggested_width: 1000 // -- this is the under description
            ,suggested_height: 600 // -- this is the under description
            ,item: null // -- we can pass the items from here too

        })



        return false;
    })





})