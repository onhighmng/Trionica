<?php


//echo 'ceva';

function dzswtl_shortcode_generator(){

    global $dzswtl;


    $startinit = '';



	wp_enqueue_style('dzswtl_shortcode_builder', $dzswtl->base_url . 'shortcodegenerator/filter-generator.css');
	wp_enqueue_script('dzswtl_shortcode_builder', $dzswtl->base_url . 'shortcodegenerator/filter-generator.js');


	wp_enqueue_style('dzstoggle', $dzswtl->base_url . 'libs/dzstoggle/dzstoggle.css');
	wp_enqueue_script('dzstoggle', $dzswtl->base_url . "libs/dzstoggle/dzstoggle.js");

    if(isset($_GET['sel'])){
        $startinit = stripslashes($_GET['sel']);
    }

    $url_admin = get_admin_url();
//<script src="<?php echo site_url(); "></script>


    ?>
    <script>

        window.dzswtl_startinit = '<?php
                        echo $startinit;

             ?>';

    </script>

<div class="sc-con sc-con-for-showcase-builder">
    <div class="sc-menu">





        <div class="setting  mode-any">
            <h3><?php echo __("Feed from"); ?></h3>
		    <?php


		    $lab = "feed_from";


		    $arr_opts = array(
			    array(
				    'value'=>'categories',
				    'label'=>esc_html__("Categories",'dzswtl'),
			    ),
			    array(
				    'value'=>'price',
				    'label'=>esc_html__("Price",'dzswtl'),
			    ),
			    array(
				    'value'=>'ratings',
				    'label'=>esc_html__("Ratings",'dzswtl'),
			    ),
			    array(
				    'value'=>'custom-attribute',
				    'label'=>esc_html__("Custom attribute",'dzswtl'),
			    ),
			    array(
				    'value'=>'custom-taxonomy',
				    'label'=>esc_html__("Custom taxonomy",'dzswtl'),
			    ),
			    array(
				    'value'=>'custom-meta',
				    'label'=>esc_html__("Custom meta",'dzswtl'),
			    ),

		    );


		    echo DZSHelpers::generate_select($lab, array(
			    'options'=>$arr_opts,
			    'class'=>'dzs-style-me skin-beige  dzs-dependency-field shortcode-field',
			    'seekval'=>'',
		    ));
		    ?>
            <div class="sidenote" style=";"><?php echo sprintf(__('choose a property on which to filter', 'dzswtl')); ?></div>
        </div>


        <div class="setting  mode-any">
            <h3><?php echo __("Filter type"); ?></h3>
		    <?php


		    $lab = "type";


		    $arr_opts = array(
			    array(
				    'value'=>'select',
				    'label'=>__("Select single"),
			    ),
			    array(
				    'value'=>'single-with-image',
				    'label'=>__("Single with image"),
			    ),
			    array(
				    'value'=>'multiple',
				    'label'=>__("Multiple"),
			    ),
			    array(
				    'value'=>'slider',
				    'label'=>__("Slider"),
			    ),

		    );


		    echo DZSHelpers::generate_select($lab, array(
			    'options'=>$arr_opts,
			    'class'=>'dzs-style-me skin-beige  dzs-dependency-field shortcode-field',
			    'seekval'=>'',
		    ));
		    ?>
            <div class="sidenote" style=";"><?php echo sprintf(__('%sSelect single%s - select a single value.  %s%sMultiple%s - select multiple options in a checkbox. %s%sSlider%s - drag price slider or number value.', 'dzswtl'),
                    '<strong>','</strong>','<br>',
                    '<strong>','</strong>','<br>',
                    '<strong>','</strong>'); ?></div>
        </div>








	    <?php

	    $dependency = array(

		    array(
			    'element'=>'type',
			    'value'=>array('select'),
		    ),
	    )
	    ;

	    $aux = json_encode($dependency);

	    ?>



        <div class="setting  mode-any" data-dependency='<?php echo $aux;?>'>
            <h3><?php echo __("Single style"); ?></h3>
		    <?php


		    $lab = "type_select_style";


		    $arr_opts = array(
			    array(
				    'value'=>'default',
				    'label'=>__("Default"),
			    ),
			    array(
				    'value'=>'coronae',
				    'label'=>__("Coronae"),
			    ),
			    array(
				    'value'=>'forseen',
				    'label'=>__("Forseen"),
			    ),
			    array(
				    'value'=>'tabs-menu',
				    'label'=>__("Tabs header"),
			    ),


		    );


		    echo DZSHelpers::generate_select($lab, array(
			    'options'=>$arr_opts,
			    'class'=>'dzs-style-me skin-beige  dzs-dependency-field shortcode-field',
			    'seekval'=>'',
		    ));
		    ?>

        </div>





	    <?php

	    $dependency = array(

		    array(
			    'element'=>'type',
			    'value'=>array('multiple'),
		    ),
	    )
	    ;

	    $aux = json_encode($dependency);

	    ?>



        <div class="setting  mode-any" data-dependency='<?php echo $aux;?>'>
            <h3><?php echo __("Multiple style"); ?></h3>
		    <?php


		    $lab = "type_multiple_style";


		    $arr_opts = array(
			    array(
				    'value'=>'default',
				    'label'=>__("Default"),
			    ),
			    array(
				    'value'=>'checkbox-search',
				    'label'=>__("Search"),
			    ),


		    );


		    echo DZSHelpers::generate_select($lab, array(
			    'options'=>$arr_opts,
			    'class'=>'dzs-style-me skin-beige  dzs-dependency-field shortcode-field',
			    'seekval'=>'',
		    ));
		    ?>

        </div>




<?php

        $dependency = array(

        array(
        'element'=>'type',
        'value'=>array('slider'),
        ),
        )
        ;

        $aux = json_encode($dependency);

        ?>




        <div class="setting mode-any  " data-dependency='<?php echo $aux;?>'>
            <h4><?php echo esc_html__("Slider",'dzswtl');?> <?php echo esc_html__("minimum",'dzswtl');?></h4>
            <input class="shortcode-field regular-text" name="slider_min" value=""/>
        </div>




        <div class="setting mode-any  " data-dependency='<?php echo $aux;?>'>
            <h4><?php echo esc_html__("Slider",'dzswtl');?> <?php echo esc_html__("maximum",'dzswtl');?></h4>
            <input class="shortcode-field regular-text" name="slider_max" value=""/>
        </div>



	    <?php

	    $dependency = array(

		    array(
			    'element'=>'feed_from',
			    'value'=>array('custom-attribute'),
		    ),
	    )
	    ;

	    $aux = json_encode($dependency);

	    ?>

        <?php
        $lab = 'custom_attr_name';
        ?>

        <div class="setting mode-any  " data-dependency='<?php echo $aux;?>'>
            <h4><?php echo esc_html__("Custom attribute name",'dzswtl');?></h4>

            <?php



//            $lab = "mode_zfolio_layout";


            $arr_opts = array(
	            array(
		            'value'=>'',
		            'label'=>__("Custom name"),
	            ),

            );





            $taxonomies = get_taxonomies( array(), 'objects' );



            foreach ( $taxonomies as $taxonomy ) {
	            if ( strpos( $taxonomy->name, 'pa_' ) === 0 ){



//	                print_rr($taxonomy);
	                $aux = array(
	                        'value'=>$taxonomy->name,
	                        'label'=>$taxonomy->label,
                    );
		            array_push( $arr_opts, $aux );
	            }
            }











            echo DZSHelpers::generate_select($lab, array(
	            'options'=>$arr_opts,
	            'class'=>'dzs-style-me skin-beige  dzs-dependency-field shortcode-field',
	            'seekval'=>'',
            ));
            /*
             *
             *
            <input class="shortcode-field regular-text" name="<?php echo $lab; ?>" value=""/>
             *
             */

            ?>
        </div>





	    <?php

	    $dependency = array(

		    array(
			    'element'=>'feed_from',
			    'value'=>array('custom-meta'),
		    ),
	    )
	    ;

	    $aux = json_encode($dependency);

	    ?>




	    <?php
	    $lab = 'custom_meta_name';
	    ?>

        <div class="setting mode-any  " data-dependency='<?php echo $aux;?>'>
            <h4><?php echo esc_html__("Custom meta name",'dzswtl');?></h4>

		    <?php




		    ?>
            <input class="shortcode-field regular-text" name="<?php echo $lab; ?>" value=""/>
        </div>





	    <?php

	    $dependency = array(

		    array(
			    'element'=>'feed_from',
			    'value'=>array('custom-taxonomy'),
		    ),
	    )
	    ;

	    $aux = json_encode($dependency);

	    ?>




	    <?php
	    $lab = 'custom_taxonomy_name';
	    ?>

        <div class="setting mode-any  " data-dependency='<?php echo $aux;?>'>
            <h4><?php echo esc_html__("Custom taxonomy name",'dzswtl');?></h4>

		    <?php



		    //            $lab = "mode_zfolio_layout";


		    $arr_opts = array(
			    array(
				    'value'=>'',
				    'label'=>esc_html__("Select taxonomy",'dzswtl'),
			    ),

		    );





		    $taxonomies = get_taxonomies( array(), 'objects' );



		    foreach ( $taxonomies as $taxonomy ) {




//	                print_rr($taxonomy);
				    $aux = array(
					    'value'=>$taxonomy->name,
					    'label'=>$taxonomy->label,
				    );
				    array_push( $arr_opts, $aux );

		    }











		    echo DZSHelpers::generate_select($lab, array(
			    'options'=>$arr_opts,
			    'class'=>'dzs-style-me skin-beige  dzs-dependency-field shortcode-field',
			    'seekval'=>'',
		    ));
		    /*
			 *
			 *
			<input class="shortcode-field regular-text" name="<?php echo $lab; ?>" value=""/>
			 *
			 */

		    ?>
        </div>









	    <?php
	    $lab = 'left_label';
	    ?>

        <div class="setting mode-any  " >
            <h4><?php echo esc_html__("Left label",'dzswtl');?></h4>
            <input class="shortcode-field regular-text" name="<?php echo $lab; ?>" value=""/>
            <div class="sidenote" style=";"><?php echo esc_html__('choose a property on which to filter', 'dzswtl'); ?></div>

        </div>



	    <?php
	    $lab = 'extra_classes';
	    ?>

        <div class="setting mode-any  " >
            <h4><?php echo esc_html__("Extra classes",'dzswtl');?></h4>
            <input class="shortcode-field regular-text" name="<?php echo $lab; ?>" value=""/>
            <div class="sidenote" style=";"><?php echo esc_html__('extra classes to style via css', 'dzswtl'); ?></div>

        </div>

        <?php




        ?>


        <div class="dzstoggle">

            <div class="toggle-title"><?php echo esc_html__('Aligment', 'dzswtl'); ?></div>
            <div class="toggle-content">
                <div class="sidenote">
	                <?php echo esc_html__('choose aligment properties, if this filter is inside a container', 'dzswtl'); ?>
                </div>

                <div class="setting ">

                    <?php
                    $lab = 'margin_left';
                    ?>

                    <h4 class="setting-label"><?php echo esc_html__('Margin left', 'dzswtl'); ?></h4>

                    <select class="dzs-style-me skin-beige shortcode-field" name="<?php echo $lab; ?>">
                        <option value=""><?php echo esc_html__('Default', 'dzswtl'); ?></option>
                        <option value="10px"><?php echo esc_html__('10px', 'dzswtl'); ?></option>
                        <option value="auto"><?php echo esc_html__('Space auto', 'dzswtl'); ?></option>
                    </select>
                    <div class="sidenote">
		                <?php echo esc_html__('space auto will move the filter to the right', 'dzswtl'); ?>
                    </div>

                </div>

                <div class="setting">

	                <?php
	                $lab = 'margin_right';
	                ?>

                    <h4 class="setting-label"><?php echo esc_html__('Margin right', 'dzswtl'); ?></h4>

                    <select class="dzs-style-me skin-beige shortcode-field" name="<?php echo $lab; ?>">
                        <option value=""><?php echo esc_html__('Default', 'dzswtl'); ?></option>
                        <option value="10px"><?php echo esc_html__('10px', 'dzswtl'); ?></option>
                        <option value="auto"><?php echo esc_html__('Space auto', 'dzswtl'); ?></option>
                    </select>
                    <div class="sidenote">
		                <?php echo esc_html__('space auto will move the filter to the left', 'dzswtl'); ?>
                    </div>

                </div>
                <div class="setting">

	                <?php
	                $lab = 'flex_prop';
	                ?>

                    <h4 class="setting-label"><?php echo esc_html__('Cover space', 'dzswtl'); ?></h4>

                    <select class="dzs-style-me skin-beige shortcode-field" name="<?php echo $lab; ?>">
                        <option value=""><?php echo esc_html__('Default', 'dzswtl'); ?></option>
                        <option value="auto"><?php echo esc_html__('Cover minimum', 'dzswtl'); ?></option>
                        <option value="1000"><?php echo esc_html__('Cover maximum', 'dzswtl'); ?></option>
                    </select>


                </div>
            </div>
        </div>



        <?php

        // -- TODO: post type directory or woocommerce
/*
        <div class="setting  mode-any">
            <h3><?php echo __("Post Type"); ?></h3>
            <?php


            $lab = "post_type";


            $arr_opts = array(
                array(
                    'value'=>'',
                    'label'=>__("Menu Items"),
                ),
                array(
                    'value'=>'product',
                    'label'=>__("WooCommerce Products"),
                ),
            );


            echo DZSHelpers::generate_select($lab, array(
                'options'=>$arr_opts,
                'class'=>'dzs-style-me skin-beige  dzs-dependency-field',
                'seekval'=>'',
            ));
            ?>
        </div>
*/
        ?>

























                    </div>













        <div class="clear"></div>
        <br/>
        <br/>
        <button id="insert_tests" class="button-primary insert-tests"><?php echo __("Insert Shortcode"); ?></button>
        <div class="shortcode-output"></div>
    </div>
    <div class="feedbacker"><i class="fa fa-circle-o-notch fa-spin"></i><?php echo __(" Loading... "); ?></div>








    <div style="display:none">


        <div class="dzs-tab-tobe">
            <div class="tab-menu "><?php echo __("Description Settings"); ?></div>
            <div class="tab-content">

                <div class="sidenote" style="font-size:14px;"><?php echo __('Use these settings to control how many characters get shown from the video content.','dzswtl'); ?></div>

                <div class="setting  mode-any">
                    <h3><?php echo __("Number of Characters");?></h3>
                    <input name="desc_count" value="default"/>

                    <div class="sidenote" style=";"><?php echo __('Leave this to <strong>default</strong> in order for the number of characters to get best displayed based on the Mode.. ','dzswtl'); ?></div>
                </div>

                <br>
                <br>





            </div>
        </div>

        <div class="dzs-tab-tobe ">
            <div class="tab-menu ">
                <?php echo __("Pagination Settings"); ?>
            </div>
            <div class="tab-content">
                <div class="sidenote" style="font-size:14px;"><?php echo __('Useful if you have many videos and you want to separate them somehow.','dzswtl'); ?></div>

                <!--                <div class="setting  mode-any">-->
                <!--                    <h3>--><?php //echo __("Select a Pagination Method"); ?><!--</h3>-->
                <!--                    <select class="styleme" name="dzswtl_settings_separation_mode">-->
                <!--                        <option>normal</option>-->
                <!--                        <option>pages</option>-->
                <!--                        <option>scroll</option>-->
                <!--                        <option>button</option>-->
                <!--                    </select>-->
                <!---->
                <!--                </div>-->
                <div class="setting  mode-any">
                    <h3><?php echo __("Select Number of Items per Page");?></h3>
                    <input name="count" value="5"/>


                </div>
                <br>
                <br>
            </div>
        </div>


    </div>
</div><?php
}